# Team Pulse — Backend API

Team Pulse 看板的数据服务。Node 22 + 内置 `node:sqlite`,**零 npm 依赖**。

## 部署形态

```
        浏览器 ──HTTPS──► 一个 Route host,按 path 分流
                              │
                    /api ─────┼───── /  (其他全部)
                              │
                    ┌─────────▼──────┐   ┌──────────────────┐
                    │ team-pulse-api │   │ team-pulse       │
                    │ replicas: 1    │   │ (前端 SSR)       │
                    │ Recreate       │   └──────────────────┘
                    └───────┬────────┘
                       PVC 1Gi RWO
```

`values-dev.yaml` 里的 `urlName` **故意和前端设成一样的 `team-pulse`**,
两个 Route 因此解析到同一个 host,靠 path 区分。这样浏览器始终同源:
不需要 CORS,也不用把 API 地址烤进前端 bundle。

## 为什么后端只能 1 个副本

SQLite 单写入端,PVC 是 ReadWriteOnce。所以:

- `replicas: 1` —— 不能改
- `strategy: Recreate` —— 不是 RollingUpdate。新 pod 没法在旧 pod 还占着 RWO 卷时挂载,
  滚动更新会直接卡住
- PVC 上有 `harness.io/skip-versioning: "true"` —— **这条不能删**,
  否则 Harness 每次部署都会创建带版本号的新 PVC,数据库会静默清空

这也是后端和前端拆开部署的原因:合在一起会把前端也锁死在单副本。

## 为什么零依赖

用的是 Node 22 内置的 `node:sqlite`,`package.json` 的 `dependencies` 是空的:

- 镜像构建没有 `npm install` 这一步 —— pipeline 里连 `npm_build` 步骤都不需要
- 没有原生模块编译(`better-sqlite3` 在 alpine 上经常出问题)
- 供应链攻击面基本为零

代价:`node:sqlite` 上游标注为 experimental。我们只用 `DatabaseSync`,自 Node 22.5 起 API 稳定,
且从 22.13 起不再需要 `--experimental-sqlite` flag。镜像钉在 `node:22.19-alpine`。

## 本地开发

```bash
node --version        # 需要 >= 22.13
npm run dev           # http://localhost:8080/api,带 --watch
```

首次启动数据库为空时自动灌入种子数据。**之后重启不会覆盖已有数据**
(`seedIfEmpty()` 只在 people 表为空时才写)。

前端 `npm run dev` 已配好 proxy,`/api` 会转发到这里。

## 环境变量

由 `openshift/values-dev.yaml` 的 `env.config` 生成 ConfigMap 注入。

| 变量 | 默认值 | 说明 |
|---|---|---|
| `PORT` | `8080` | 监听端口 |
| `HOST` | `0.0.0.0` | 监听地址 |
| `DB_PATH` | `/data/team-pulse.db` | SQLite 文件,指向 PVC |
| `API_BASE_PATH` | `/api` | 路由前缀 |
| `CORS_ORIGIN` | 空 | 仅本地跨域开发需要;生产同源,留空 |

## API

**所有写操作都返回完整的 `CapacityData` 快照**,前端整体替换 state,不会状态漂移。

| Method | Path | 说明 |
|---|---|---|
| GET | `/api/health` | 探针 |
| GET | `/api/capacity` | 完整快照 |
| PUT | `/api/capacity` | 整体替换(Excel 导入) |
| POST | `/api/capacity/reset` | 重置为种子数据 |
| POST/PATCH/DELETE | `/api/people[/:id]` | 人员 |
| POST/PATCH/DELETE | `/api/projects[/:id]` | 项目 |
| POST/PATCH/DELETE | `/api/allocations[/:id]` | 分配 |

错误统一 `{ "error": "..." }`,状态码 400 / 404 / 405 / 413 / 500。

> Route 上带了 `rewrite-target: /`(和前端一致),所以 `/api/capacity` 到达 pod 时
> 实际是 `/capacity`。`server.mjs` 两种形式都接受,已实测,所以这个注解加不加都能跑。

### 服务端校验

新数据模型里 `Person` 已经**没有 capacity 字段**,所以原来的"超配拦截"规则不复存在。
现在服务端保证的是引用完整性和字段合法性:

- allocation 的 `personId` / `projectId` 必须真实存在(否则 404)
- `employmentType` ∈ {FTE, FTC},`impactLevel` ∈ {High, Medium, Low},`fte > 0`
- 所有写操作包在事务里,校验失败整体回滚

**客户端可以指定 id。** `POST /people` 和 `POST /allocations` 接受 body 里的 `id`,
不传则服务端生成。前端 admin 表单需要"建人之后在同一个事件里立刻给他分配",
所以 id 由客户端先生成;前端同时把写请求串行化,保证 person 先于 allocation 到达。

## Schema 迁移

`db.mjs` 在启动时会自动把旧 schema 迁移到当前版本(`migrate()`),**不会丢数据**:

| 变更 | 处理 |
|---|---|
| `people.capacity` | 删除列 |
| `people.is_floating` | 删除列 |
| `projects.sponsor` | 新增列,已有行填空串 |
| `allocations.kind` | 删除列 |

迁移是幂等的:列已经正确时什么都不做。日志里会打一行
`Schema migrated: ...` 说明做了什么。

> 背景:`CREATE TABLE IF NOT EXISTS` 对已存在的表是空操作,所以 PVC 里
> 建于旧模型时期的数据库会保留旧列,之后每次写入都因约束失败而报
> "Internal server error"。与其让人清空卷(里面是真实数据),不如迁移。

## 数据库

```
meta(key, value)                     -- 存 asOf
people(id, name, role, employment_type)
projects(id, name, sponsor, description, icon, priority, impact_if_delayed, impact_level)
project_role_needs(project_id → projects, role, fte)   PK(project_id, role)
allocations(id, person_id → people, project_id → projects, fte)
```

外键全部 `ON DELETE CASCADE`。CHECK 约束保证枚举值和正数。WAL + `busy_timeout=5000`。

## 首次上线要做的事

1. **把 `backend/` 整个目录放进 `TeamPulse-app` 仓库根目录**(和前端同仓库,
   复用同一个 codebase connector)
2. **把 `.harness/.../pipelines/teampulseapi.yaml` 放到和 `teampulseapp.yaml` 同一个目录**
3. **在 Harness 控制台建一个新 service `teampulseapidev`** ——
   照着现有的 `teampulsedev` 复制,artifact source 指向 `teampulse-api` 镜像仓库
4. **确认 Artifactory 对 `teampulse-api` 这个新路径有推送权限**
5. 跑 pipeline

### pipeline 里我填不出来的一处

`teampulseapi.yaml` 的 manifest `store` 段落里,`paths` / `valuesPaths` 我没法确定 ——
你给我看的 `teampulseapp.yaml` 截图在 `branch:` 那行就截断了。
照抄前端的写法,把路径换成:

```
backend/openshift/deployment.yaml
backend/openshift/values-dev.yaml
```

## 备份

PVC 里就一个 SQLite 文件。最简单可靠的做法是存 API 返回的 JSON:

```bash
curl -s https://<host>/api/capacity > backup-$(date +%F).json
```

恢复就是把这份 JSON `PUT /api/capacity` 发回去。建议做成每日定时任务。

直接拷文件也行,但 WAL 模式下还有 `-wal` / `-shm`,拿一致快照没那么简单。

## 后续

1. **没有认证。** 现在能访问 Route 的人都能改数据。团队容量数据在保险公司算敏感信息,
   正式给团队用之前建议加 `oauth-proxy` sidecar 或接内部 Azure AD 网关。
2. **没有审计日志。** 谁在什么时候把谁从哪个项目挪走了,过两个月一定会有人问。
   加一张 `audit_log` 表成本很低,建议早点加。
3. **换 Postgres 的话** `db.mjs` 是唯一要改的文件,`server.mjs` 的路由和校验不用动。
   届时 `replicas: 1` 和 `Recreate` 的限制也就一并解除了。
