import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { randomUUID } from "node:crypto";

import { SEED_DATA } from "./seed.mjs";

const DB_PATH = process.env.DB_PATH ?? "./data/team-pulse.db";

mkdirSync(dirname(DB_PATH), { recursive: true });

export const db = new DatabaseSync(DB_PATH);

// WAL gives us concurrent readers alongside the single writer; the busy timeout
// stops transient "database is locked" errors under parallel requests.
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");
db.exec("PRAGMA busy_timeout = 5000");

db.exec(`
  CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS people (
    id              TEXT PRIMARY KEY,
    name            TEXT    NOT NULL,
    role            TEXT    NOT NULL,
    employment_type TEXT    NOT NULL CHECK (employment_type IN ('FTE','FTC'))
  );

  CREATE TABLE IF NOT EXISTS projects (
    id                TEXT PRIMARY KEY,
    name              TEXT    NOT NULL,
    sponsor           TEXT    NOT NULL DEFAULT '',
    description       TEXT    NOT NULL DEFAULT '',
    icon              TEXT    NOT NULL DEFAULT 'rocket',
    priority          INTEGER NOT NULL DEFAULT 1,
    impact_if_delayed TEXT    NOT NULL DEFAULT '',
    impact_level      TEXT    NOT NULL DEFAULT 'Medium'
                              CHECK (impact_level IN ('High','Medium','Low'))
  );

  CREATE TABLE IF NOT EXISTS project_role_needs (
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    role       TEXT NOT NULL,
    fte        REAL NOT NULL CHECK (fte >= 0),
    PRIMARY KEY (project_id, role)
  );

  CREATE TABLE IF NOT EXISTS allocations (
    id         TEXT PRIMARY KEY,
    person_id  TEXT NOT NULL REFERENCES people(id)   ON DELETE CASCADE,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    fte        REAL NOT NULL CHECK (fte > 0)
  );

  CREATE INDEX IF NOT EXISTS idx_alloc_person  ON allocations(person_id);
  CREATE INDEX IF NOT EXISTS idx_alloc_project ON allocations(project_id);
`);

/**
 * In-place migration from the earlier schema.
 *
 * `CREATE TABLE IF NOT EXISTS` is a no-op against an existing database, so a
 * volume created before the model changed keeps its old columns and every
 * write fails with an opaque constraint error. Reconcile the columns instead
 * of asking anyone to wipe the volume — the data in there is real.
 *
 * Changes covered:
 *   people.capacity, people.is_floating   -> dropped
 *   projects.sponsor                      -> added
 *   allocations.kind                      -> dropped
 */
function migrate() {
  const columns = (table) =>
    new Set(db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name));

  const applied = [];

  const people = columns("people");
  if (people.has("capacity")) {
    db.exec("ALTER TABLE people DROP COLUMN capacity");
    applied.push("people.capacity dropped");
  }
  if (people.has("is_floating")) {
    db.exec("ALTER TABLE people DROP COLUMN is_floating");
    applied.push("people.is_floating dropped");
  }

  const projects = columns("projects");
  if (projects.size && !projects.has("sponsor")) {
    db.exec("ALTER TABLE projects ADD COLUMN sponsor TEXT NOT NULL DEFAULT ''");
    applied.push("projects.sponsor added");
  }

  const allocations = columns("allocations");
  if (allocations.has("kind")) {
    db.exec("ALTER TABLE allocations DROP COLUMN kind");
    applied.push("allocations.kind dropped");
  }

  if (applied.length) console.log(`Schema migrated: ${applied.join(", ")}`);
}

migrate();

export const newId = () => randomUUID().replaceAll("-", "").slice(0, 12);

/** Run fn inside a transaction; rolls back on throw. */
export function tx(fn) {
  db.exec("BEGIN");
  try {
    const result = fn();
    db.exec("COMMIT");
    return result;
  } catch (err) {
    try {
      db.exec("ROLLBACK");
    } catch {
      /* already rolled back */
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Reads
// ---------------------------------------------------------------------------

export function getAsOf() {
  const row = db.prepare("SELECT value FROM meta WHERE key = 'asOf'").get();
  return row?.value ?? new Date().toISOString().slice(0, 10);
}

export function setAsOf(value) {
  db.prepare(
    "INSERT INTO meta (key, value) VALUES ('asOf', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
  ).run(String(value));
}

/**
 * Full snapshot in exactly the CapacityData shape the frontend expects.
 * Every mutation returns this so the client never drifts out of sync.
 */
export function getCapacity() {
  const people = db
    .prepare("SELECT * FROM people ORDER BY rowid")
    .all()
    .map((r) => ({
      id: r.id,
      name: r.name,
      role: r.role,
      employmentType: r.employment_type,
    }));

  const needsByProject = new Map();
  for (const r of db
    .prepare("SELECT * FROM project_role_needs ORDER BY rowid")
    .all()) {
    if (!needsByProject.has(r.project_id)) needsByProject.set(r.project_id, []);
    needsByProject.get(r.project_id).push({ role: r.role, fte: r.fte });
  }

  const projects = db
    .prepare("SELECT * FROM projects ORDER BY priority, rowid")
    .all()
    .map((r) => ({
      id: r.id,
      name: r.name,
      sponsor: r.sponsor,
      description: r.description,
      icon: r.icon,
      neededByRole: needsByProject.get(r.id) ?? [],
      priority: r.priority,
      impactIfDelayed: r.impact_if_delayed,
      impactLevel: r.impact_level,
    }));

  const allocations = db
    .prepare("SELECT * FROM allocations ORDER BY rowid")
    .all()
    .map((r) => ({
      id: r.id,
      personId: r.person_id,
      projectId: r.project_id,
      fte: r.fte,
    }));

  return { asOf: getAsOf(), people, projects, allocations };
}

/** FTE already committed for a person, optionally ignoring one allocation. */
export function allocatedFor(personId, excludeAllocationId = null) {
  const row = db
    .prepare(
      "SELECT COALESCE(SUM(fte), 0) AS total FROM allocations WHERE person_id = ? AND id IS NOT ?",
    )
    .get(personId, excludeAllocationId);
  return Math.round(row.total * 10) / 10;
}

// ---------------------------------------------------------------------------
// Writes
// ---------------------------------------------------------------------------

export function insertPerson(p) {
  const id = p.id ?? newId();
  db.prepare(
    `INSERT INTO people (id, name, role, employment_type) VALUES (?, ?, ?, ?)`,
  ).run(id, p.name, p.role, p.employmentType);
  return id;
}

export function updatePerson(id, patch) {
  const current = db.prepare("SELECT * FROM people WHERE id = ?").get(id);
  if (!current) return false;
  const next = {
    name: patch.name ?? current.name,
    role: patch.role ?? current.role,
    employmentType: patch.employmentType ?? current.employment_type,
  };
  db.prepare(
    `UPDATE people SET name = ?, role = ?, employment_type = ? WHERE id = ?`,
  ).run(next.name, next.role, next.employmentType, id);
  return true;
}

export function insertProject(p) {
  const id = p.id ?? newId();
  db.prepare(
    `INSERT INTO projects (id, name, sponsor, description, icon, priority, impact_if_delayed, impact_level)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    id,
    p.name,
    p.sponsor ?? "",
    p.description ?? "",
    p.icon ?? "rocket",
    p.priority ?? 1,
    p.impactIfDelayed ?? "",
    p.impactLevel ?? "Medium",
  );
  replaceRoleNeeds(id, p.neededByRole ?? []);
  return id;
}

export function replaceRoleNeeds(projectId, needs) {
  db.prepare("DELETE FROM project_role_needs WHERE project_id = ?").run(projectId);
  const stmt = db.prepare(
    "INSERT INTO project_role_needs (project_id, role, fte) VALUES (?, ?, ?)",
  );
  // Same role listed twice would violate the PK — fold duplicates instead.
  const folded = new Map();
  for (const n of needs) folded.set(n.role, (folded.get(n.role) ?? 0) + Number(n.fte));
  for (const [role, fte] of folded) stmt.run(projectId, role, fte);
}

export function updateProject(id, patch) {
  const current = db.prepare("SELECT * FROM projects WHERE id = ?").get(id);
  if (!current) return false;
  db.prepare(
    `UPDATE projects SET name = ?, sponsor = ?, description = ?, icon = ?, priority = ?,
       impact_if_delayed = ?, impact_level = ? WHERE id = ?`,
  ).run(
    patch.name ?? current.name,
    patch.sponsor ?? current.sponsor,
    patch.description ?? current.description,
    patch.icon ?? current.icon,
    patch.priority ?? current.priority,
    patch.impactIfDelayed ?? current.impact_if_delayed,
    patch.impactLevel ?? current.impact_level,
    id,
  );
  if (patch.neededByRole !== undefined) replaceRoleNeeds(id, patch.neededByRole);
  return true;
}

export function insertAllocation(a) {
  const id = a.id ?? newId();
  db.prepare(
    "INSERT INTO allocations (id, person_id, project_id, fte) VALUES (?, ?, ?, ?)",
  ).run(id, a.personId, a.projectId, a.fte);
  return id;
}

export function updateAllocation(id, patch) {
  const current = db.prepare("SELECT * FROM allocations WHERE id = ?").get(id);
  if (!current) return false;
  db.prepare(
    "UPDATE allocations SET person_id = ?, project_id = ?, fte = ? WHERE id = ?",
  ).run(
    patch.personId ?? current.person_id,
    patch.projectId ?? current.project_id,
    patch.fte ?? current.fte,
    id,
  );
  return true;
}

export function removeRow(table, id) {
  const info = db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
  return info.changes > 0;
}

/** Wipe everything and load a full CapacityData payload. Used by import + reset. */
export function replaceAll(data) {
  return tx(() => {
    db.exec("DELETE FROM allocations");
    db.exec("DELETE FROM project_role_needs");
    db.exec("DELETE FROM projects");
    db.exec("DELETE FROM people");

    setAsOf(data.asOf ?? new Date().toISOString().slice(0, 10));
    for (const p of data.people ?? []) insertPerson(p);
    for (const p of data.projects ?? []) insertProject(p);
    for (const a of data.allocations ?? []) insertAllocation(a);
    return getCapacity();
  });
}

/** First boot only — never overwrites an existing database. */
export function seedIfEmpty() {
  const { count } = db.prepare("SELECT COUNT(*) AS count FROM people").get();
  if (count > 0) return false;
  replaceAll(SEED_DATA);
  return true;
}
