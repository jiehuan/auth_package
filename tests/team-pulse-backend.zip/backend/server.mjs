import { createServer } from "node:http";

import {
  db,
  getCapacity,
  insertAllocation,
  insertPerson,
  insertProject,
  removeRow,
  replaceAll,
  seedIfEmpty,
  tx,
  updateAllocation,
  updatePerson,
  updateProject,
} from "./db.mjs";
import { SEED_DATA } from "./seed.mjs";

const PORT = Number(process.env.PORT ?? 8080);
const HOST = process.env.HOST ?? "0.0.0.0";
const BASE = process.env.API_BASE_PATH ?? "/api";
// Only needed for local dev when Vite runs on a different origin.
// In OpenShift the Route serves both on one host, so leave this unset.
const CORS_ORIGIN = process.env.CORS_ORIGIN ?? "";
const MAX_BODY = 5 * 1024 * 1024; // Excel imports can be chunky

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const bad = (msg) => {
  throw new HttpError(400, msg);
};
const notFound = (msg) => {
  throw new HttpError(404, msg);
};

// ---------------------------------------------------------------------------
// Validation — the client validates too, but never trust it.
// ---------------------------------------------------------------------------

function str(v, field, { required = true, max = 500 } = {}) {
  if (v === undefined || v === null) {
    if (required) bad(`${field} is required`);
    return undefined;
  }
  if (typeof v !== "string") bad(`${field} must be a string`);
  const trimmed = v.trim();
  if (required && !trimmed) bad(`${field} cannot be empty`);
  if (trimmed.length > max) bad(`${field} is too long (max ${max})`);
  return trimmed;
}

function num(v, field, { required = true, min = -Infinity, max = Infinity } = {}) {
  if (v === undefined || v === null) {
    if (required) bad(`${field} is required`);
    return undefined;
  }
  const n = Number(v);
  if (!Number.isFinite(n)) bad(`${field} must be a number`);
  if (n < min) bad(`${field} must be at least ${min}`);
  if (n > max) bad(`${field} must be at most ${max}`);
  return n;
}

function oneOf(v, field, allowed, { required = true } = {}) {
  if (v === undefined || v === null) {
    if (required) bad(`${field} is required`);
    return undefined;
  }
  if (!allowed.includes(v)) bad(`${field} must be one of: ${allowed.join(", ")}`);
  return v;
}

function bool(v, field, { required = true } = {}) {
  if (v === undefined || v === null) {
    if (required) bad(`${field} is required`);
    return undefined;
  }
  if (typeof v !== "boolean") bad(`${field} must be true or false`);
  return v;
}

function roleNeeds(v, { required = true } = {}) {
  if (v === undefined || v === null) {
    if (required) bad("neededByRole is required");
    return undefined;
  }
  if (!Array.isArray(v)) bad("neededByRole must be an array");
  if (v.length > 50) bad("neededByRole has too many entries");
  return v.map((n, i) => ({
    role: str(n?.role, `neededByRole[${i}].role`),
    fte: num(n?.fte, `neededByRole[${i}].fte`, { min: 0, max: 1000 }),
  }));
}

const partial = (v, field, fn) => (v === undefined ? undefined : fn());

/**
 * Over-allocation is permitted by design: `capacity` is a planning baseline,
 * not a hard limit. The point of the dashboard is to show who is stretched
 * past it, which it cannot do if the data is refused at the door.
 *
 * What is still enforced is referential integrity — an allocation must point
 * at a person and a project that exist.
 */
function assertRefsExist(personId, projectId) {
  if (!db.prepare("SELECT 1 FROM people WHERE id = ?").get(personId)) {
    notFound("Person not found");
  }
  if (projectId && !db.prepare("SELECT 1 FROM projects WHERE id = ?").get(projectId)) {
    notFound("Project not found");
  }
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

const routes = [
  {
    method: "GET",
    pattern: /^\/health$/,
    handler: () => ({ status: "ok" }),
  },

  {
    method: "GET",
    pattern: /^\/capacity$/,
    handler: () => getCapacity(),
  },

  // Full replace — used by the Excel import and any bulk edit.
  {
    method: "PUT",
    pattern: /^\/capacity$/,
    handler: (_p, body) => {
      if (!body || typeof body !== "object") bad("Body must be a CapacityData object");
      if (!Array.isArray(body.people)) bad("people must be an array");
      if (!Array.isArray(body.projects)) bad("projects must be an array");
      if (!Array.isArray(body.allocations)) bad("allocations must be an array");
      return replaceAll(body);
    },
  },

  {
    method: "POST",
    pattern: /^\/capacity\/reset$/,
    handler: () => replaceAll(SEED_DATA),
  },

  // -- people ---------------------------------------------------------------
  {
    method: "POST",
    pattern: /^\/people$/,
    handler: (_p, body) =>
      tx(() => {
        insertPerson({
          name: str(body?.name, "name", { max: 120 }),
          role: str(body?.role, "role", { max: 120 }),
          employmentType: oneOf(body?.employmentType, "employmentType", ["FTE", "FTC"]),
          capacity: num(body?.capacity, "capacity", { min: 0.1, max: 10 }),
          isFloating: bool(body?.isFloating, "isFloating"),
        });
        return getCapacity();
      }),
  },
  {
    method: "PATCH",
    pattern: /^\/people\/([\w-]+)$/,
    handler: ([id], body) =>
      tx(() => {
        const patch = {
          name: partial(body?.name, "name", () => str(body.name, "name", { max: 120 })),
          role: partial(body?.role, "role", () => str(body.role, "role", { max: 120 })),
          employmentType: partial(body?.employmentType, "employmentType", () =>
            oneOf(body.employmentType, "employmentType", ["FTE", "FTC"]),
          ),
          capacity: partial(body?.capacity, "capacity", () =>
            num(body.capacity, "capacity", { min: 0.1, max: 10 }),
          ),
          isFloating: partial(body?.isFloating, "isFloating", () =>
            bool(body.isFloating, "isFloating"),
          ),
        };
        if (!updatePerson(id, patch)) notFound("Person not found");
        return getCapacity();
      }),
  },
  {
    method: "DELETE",
    pattern: /^\/people\/([\w-]+)$/,
    handler: ([id]) =>
      tx(() => {
        // ON DELETE CASCADE clears their allocations.
        if (!removeRow("people", id)) notFound("Person not found");
        return getCapacity();
      }),
  },

  // -- projects -------------------------------------------------------------
  {
    method: "POST",
    pattern: /^\/projects$/,
    handler: (_p, body) =>
      tx(() => {
        insertProject({
          name: str(body?.name, "name", { max: 120 }),
          description: str(body?.description, "description", { required: false, max: 1000 }) ?? "",
          icon: str(body?.icon, "icon", { required: false, max: 60 }) ?? "rocket",
          priority: num(body?.priority, "priority", { required: false, min: 1, max: 999 }) ?? 1,
          impactIfDelayed:
            str(body?.impactIfDelayed, "impactIfDelayed", { required: false, max: 1000 }) ?? "",
          impactLevel:
            oneOf(body?.impactLevel, "impactLevel", ["High", "Medium", "Low"], {
              required: false,
            }) ?? "Medium",
          neededByRole: roleNeeds(body?.neededByRole, { required: false }) ?? [],
        });
        return getCapacity();
      }),
  },
  {
    method: "PATCH",
    pattern: /^\/projects\/([\w-]+)$/,
    handler: ([id], body) =>
      tx(() => {
        const patch = {
          name: partial(body?.name, "name", () => str(body.name, "name", { max: 120 })),
          description: partial(body?.description, "description", () =>
            str(body.description, "description", { required: false, max: 1000 }),
          ),
          icon: partial(body?.icon, "icon", () => str(body.icon, "icon", { max: 60 })),
          priority: partial(body?.priority, "priority", () =>
            num(body.priority, "priority", { min: 1, max: 999 }),
          ),
          impactIfDelayed: partial(body?.impactIfDelayed, "impactIfDelayed", () =>
            str(body.impactIfDelayed, "impactIfDelayed", { required: false, max: 1000 }),
          ),
          impactLevel: partial(body?.impactLevel, "impactLevel", () =>
            oneOf(body.impactLevel, "impactLevel", ["High", "Medium", "Low"]),
          ),
          neededByRole: partial(body?.neededByRole, "neededByRole", () =>
            roleNeeds(body.neededByRole),
          ),
        };
        if (!updateProject(id, patch)) notFound("Project not found");
        return getCapacity();
      }),
  },
  {
    method: "DELETE",
    pattern: /^\/projects\/([\w-]+)$/,
    handler: ([id]) =>
      tx(() => {
        if (!removeRow("projects", id)) notFound("Project not found");
        return getCapacity();
      }),
  },

  // -- allocations ----------------------------------------------------------
  {
    method: "POST",
    pattern: /^\/allocations$/,
    handler: (_p, body) =>
      tx(() => {
        const personId = str(body?.personId, "personId", { max: 60 });
        const projectId = str(body?.projectId, "projectId", { max: 60 });
        const fte = num(body?.fte, "fte", { min: 0.01, max: 10 });
        const kind = oneOf(body?.kind, "kind", ["fixed", "floating"]);

        assertRefsExist(personId, projectId);

        insertAllocation({ personId, projectId, fte, kind });
        return getCapacity();
      }),
  },
  {
    method: "PATCH",
    pattern: /^\/allocations\/([\w-]+)$/,
    handler: ([id], body) =>
      tx(() => {
        const current = db.prepare("SELECT * FROM allocations WHERE id = ?").get(id);
        if (!current) notFound("Allocation not found");

        const patch = {
          personId: partial(body?.personId, "personId", () =>
            str(body.personId, "personId", { max: 60 }),
          ),
          projectId: partial(body?.projectId, "projectId", () =>
            str(body.projectId, "projectId", { max: 60 }),
          ),
          fte: partial(body?.fte, "fte", () => num(body.fte, "fte", { min: 0.01, max: 10 })),
          kind: partial(body?.kind, "kind", () => oneOf(body.kind, "kind", ["fixed", "floating"])),
        };

        assertRefsExist(
          patch.personId ?? current.person_id,
          patch.projectId ?? current.project_id,
        );

        updateAllocation(id, patch);
        return getCapacity();
      }),
  },
  {
    method: "DELETE",
    pattern: /^\/allocations\/([\w-]+)$/,
    handler: ([id]) =>
      tx(() => {
        if (!removeRow("allocations", id)) notFound("Allocation not found");
        return getCapacity();
      }),
  },
];

// ---------------------------------------------------------------------------
// HTTP plumbing
// ---------------------------------------------------------------------------

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(new HttpError(413, "Request body too large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve(undefined);
      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new HttpError(400, "Body must be valid JSON"));
      }
    });
    req.on("error", reject);
  });
}

function send(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body),
    "cache-control": "no-store",
  });
  res.end(body);
}

function applyCors(res) {
  if (!CORS_ORIGIN) return;
  res.setHeader("access-control-allow-origin", CORS_ORIGIN);
  res.setHeader("access-control-allow-methods", "GET,POST,PATCH,PUT,DELETE,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type");
  res.setHeader("access-control-max-age", "86400");
}

const server = createServer(async (req, res) => {
  const started = Date.now();
  applyCors(res);

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  let pathname;
  try {
    pathname = new URL(req.url, "http://localhost").pathname;
  } catch {
    return send(res, 400, { error: "Malformed URL" });
  }

  // Probes may hit /health directly; app traffic arrives under /api.
  const path = pathname.startsWith(BASE) ? pathname.slice(BASE.length) || "/" : pathname;

  const route = routes.find((r) => r.method === req.method && r.pattern.test(path));

  if (!route) {
    const pathExists = routes.some((r) => r.pattern.test(path));
    return send(
      res,
      pathExists ? 405 : 404,
      { error: pathExists ? "Method not allowed" : "Not found" },
    );
  }

  try {
    const body = ["POST", "PUT", "PATCH"].includes(req.method)
      ? await readBody(req)
      : undefined;
    const params = route.pattern.exec(path).slice(1);
    send(res, 200, route.handler(params, body));
  } catch (err) {
    if (err instanceof HttpError) {
      send(res, err.status, { error: err.message });
    } else {
      console.error(`[error] ${req.method} ${pathname}`, err);
      send(res, 500, { error: "Internal server error" });
    }
  } finally {
    if (path !== "/health") {
      console.log(`${req.method} ${pathname} ${res.statusCode} ${Date.now() - started}ms`);
    }
  }
});

if (seedIfEmpty()) console.log("Seeded empty database with starter data");

server.listen(PORT, HOST, () => {
  console.log(`Team Pulse API listening on http://${HOST}:${PORT}${BASE}`);
});

// Graceful shutdown so OpenShift rollouts do not cut requests mid-flight.
for (const signal of ["SIGTERM", "SIGINT"]) {
  process.on(signal, () => {
    console.log(`${signal} received, shutting down`);
    server.close(() => {
      try {
        db.close();
      } catch {
        /* already closed */
      }
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 10_000).unref();
  });
}
