import * as XLSX from "xlsx";
import { type Allocation, type CapacityData, type Person, type Project, type RoleNeed } from "./capacity-types";

const encodeRoles = (roles: RoleNeed[]) => roles.map((r) => `${r.role}:${r.fte}`).join("; ");

function decodeRoles(value: unknown): RoleNeed[] {
  if (typeof value !== "string" || !value.trim()) return [];
  return value
    .split(";")
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .map((chunk) => {
      const idx = chunk.lastIndexOf(":");
      const role = idx === -1 ? chunk : chunk.slice(0, idx).trim();
      const fte = idx === -1 ? 0 : Number(chunk.slice(idx + 1).trim());
      return { role, fte: Number.isFinite(fte) ? fte : 0 };
    });
}

/** Detail data only — every total, gap and status is recalculated by the app. */
export function exportToExcel(data: CapacityData) {
  const wb = XLSX.utils.book_new();

  const projects = data.projects.map((p) => ({
    "Project ID": p.id,
    Name: p.name,
    Description: p.description,
    Icon: p.icon,
    Priority: p.priority,
    "Resource Needed By Role": encodeRoles(p.neededByRole),
    "Impact If Delayed": p.impactIfDelayed,
    "Impact Level": p.impactLevel,
  }));

  const people = data.people.map((p) => ({
    "Person ID": p.id,
    Name: p.name,
    Role: p.role,
    "Employment Type": p.employmentType,
    "Capacity (FTE)": p.capacity,
    "Resource Type": p.isFloating ? "Floating" : "Fixed",
  }));

  const allocations = data.allocations.map((a) => ({
    "Allocation ID": a.id,
    "Person ID": a.personId,
    Person: data.people.find((p) => p.id === a.personId)?.name ?? "",
    "Project ID": a.projectId,
    Project: data.projects.find((p) => p.id === a.projectId)?.name ?? "",
    "Allocated FTE": a.fte,
    Kind: a.kind === "fixed" ? "Fixed" : "Floating",
  }));

  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(projects), "Projects");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(people), "People");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(allocations), "Allocations");

  XLSX.writeFile(wb, `team-capacity-${data.asOf}.xlsx`);
}

export interface ImportResult {
  data?: CapacityData;
  errors: string[];
}

const str = (v: unknown) => (v === undefined || v === null ? "" : String(v).trim());
const num = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
};

export async function importFromExcel(file: File): Promise<ImportResult> {
  const errors: string[] = [];
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: "array" });

  for (const sheet of ["Projects", "People", "Allocations"]) {
    if (!wb.SheetNames.includes(sheet)) errors.push(`Missing sheet: ${sheet}`);
  }
  if (errors.length) return { errors };

  const readSheet = (name: string) =>
    XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[name]!, { defval: "" });

  const projects: Project[] = [];
  readSheet("Projects").forEach((row, i) => {
    const name = str(row["Name"]);
    if (!name) {
      errors.push(`Projects row ${i + 2}: Name is required`);
      return;
    }
    const roles = decodeRoles(row["Resource Needed By Role"]);
    if (roles.some((r) => !r.role || !Number.isFinite(r.fte))) {
      errors.push(
        `Projects row ${i + 2}: "Resource Needed By Role" must look like "Data Scientist:2.0; ML Engineer:1.0"`,
      );
      return;
    }
    const level = str(row["Impact Level"]);
    projects.push({
      id: str(row["Project ID"]) || `pr-${i}-${Date.now()}`,
      name,
      description: str(row["Description"]),
      icon: str(row["Icon"]) || "rocket",
      priority: Number.isFinite(num(row["Priority"])) ? num(row["Priority"]) : i + 1,
      neededByRole: roles,
      impactIfDelayed: str(row["Impact If Delayed"]),
      impactLevel: level === "High" || level === "Medium" || level === "Low" ? level : "Medium",
    });
  });

  const people: Person[] = [];
  readSheet("People").forEach((row, i) => {
    const name = str(row["Name"]);
    if (!name) {
      errors.push(`People row ${i + 2}: Name is required`);
      return;
    }
    const capacity = num(row["Capacity (FTE)"]);
    if (!Number.isFinite(capacity) || capacity < 0) {
      errors.push(`People row ${i + 2}: Capacity (FTE) must be a number`);
      return;
    }
    const employment = str(row["Employment Type"]).toUpperCase();
    if (employment !== "FTE" && employment !== "FTC") {
      errors.push(`People row ${i + 2}: Employment Type must be FTE or FTC`);
      return;
    }
    people.push({
      id: str(row["Person ID"]) || `p-${i}-${Date.now()}`,
      name,
      role: str(row["Role"]) || "Unassigned",
      employmentType: employment,
      capacity,
      isFloating: str(row["Resource Type"]).toLowerCase() === "floating",
    });
  });

  const allocations: Allocation[] = [];
  readSheet("Allocations").forEach((row, i) => {
    const personId = str(row["Person ID"]);
    const projectId = str(row["Project ID"]);
    if (!personId && !projectId) return;
    if (!people.some((p) => p.id === personId)) {
      errors.push(`Allocations row ${i + 2}: unknown Person ID "${personId}"`);
      return;
    }
    if (!projects.some((p) => p.id === projectId)) {
      errors.push(`Allocations row ${i + 2}: unknown Project ID "${projectId}"`);
      return;
    }
    const fte = num(row["Allocated FTE"]);
    if (!Number.isFinite(fte) || fte <= 0) {
      errors.push(`Allocations row ${i + 2}: Allocated FTE must be greater than 0`);
      return;
    }
    allocations.push({
      id: str(row["Allocation ID"]) || `a-${i}-${Date.now()}`,
      personId,
      projectId,
      fte,
      kind: str(row["Kind"]).toLowerCase() === "floating" ? "floating" : "fixed",
    });
  });

  // Over-allocation is allowed on purpose: capacity is a planning baseline,
  // not a hard limit, and the dashboard is meant to surface people who are
  // stretched past it rather than refuse to record the situation.

  if (errors.length) return { errors };

  return {
    data: { asOf: new Date().toISOString().slice(0, 10), people, projects, allocations },
    errors: [],
  };
}
