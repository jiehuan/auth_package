import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import {
  neededTotal,
  round1,
  statusFor,
  type Allocation,
  type CapacityData,
  type Person,
  type Project,
  type RoleBreakdown,
} from "./capacity-types";

// Same-origin by default: in OpenShift a Route with `path: /api` sends this to
// the backend Service, so no CORS and no build-time URL injection needed.
// For `vite dev`, vite.config.ts proxies /api to http://localhost:8080.
const API_BASE = "/api";

const EMPTY: CapacityData = { asOf: "", people: [], projects: [], allocations: [] };

// Ids are minted client-side so addPerson can return one synchronously (the
// admin form creates a person and immediately allocates them). The server
// accepts a supplied id and falls back to generating one.
const uid = () => Math.random().toString(36).slice(2, 10);

/** Every mutation returns the full snapshot, so the client never drifts. */
async function request(path: string, init?: RequestInit): Promise<CapacityData> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "content-type": "application/json" },
    ...init,
  });

  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    /* empty or non-JSON response */
  }

  if (!res.ok) {
    const message =
      body && typeof body === "object" && "error" in body
        ? String((body as { error: unknown }).error)
        : `Request failed (${res.status})`;
    throw new Error(message);
  }
  return body as CapacityData;
}

const json = (method: string, payload?: unknown): RequestInit => ({
  method,
  ...(payload === undefined ? {} : { body: JSON.stringify(payload) }),
});

export function roleBreakdownFor(
  project: Project,
  people: Person[],
  allocations: Allocation[],
): RoleBreakdown[] {
  const map = new Map<string, RoleBreakdown>();
  const ensure = (role: string) => {
    let entry = map.get(role);
    if (!entry) {
      entry = { role, needed: 0, existing: 0, fte: 0, ftc: 0, gap: 0 };
      map.set(role, entry);
    }
    return entry;
  };

  project.neededByRole.forEach((need) => {
    ensure(need.role).needed += need.fte;
  });

  allocations
    .filter((a) => a.projectId === project.id)
    .forEach((a) => {
      const person = people.find((p) => p.id === a.personId);
      if (!person) return;
      const entry = ensure(person.role);
      entry.existing += a.fte;
      if (person.employmentType === "FTE") entry.fte += a.fte;
      else entry.ftc += a.fte;
    });

  return [...map.values()]
    .map((e) => ({
      role: e.role,
      needed: round1(e.needed),
      existing: round1(e.existing),
      fte: round1(e.fte),
      ftc: round1(e.ftc),
      gap: round1(e.existing - e.needed),
    }))
    .sort((a, b) => b.needed - a.needed || a.role.localeCompare(b.role));
}

export interface ProjectRow {
  project: Project;
  assigned: number;
  headcount: number;
  fteCount: number;
  ftcCount: number;
  needed: number;
  gap: number;
  byRole: RoleBreakdown[];
  status: ReturnType<typeof statusFor>;
}

export interface Totals {
  capacity: number;
  allocated: number;
  needed: number;
  gap: number;
  projects: number;
}

interface Store {
  data: CapacityData;
  rows: ProjectRow[];
  totals: Totals;
  peopleWithLoad: Array<Person & { allocated: number }>;
  addPerson: (p: Omit<Person, "id">) => string;
  updatePerson: (id: string, p: Partial<Person>) => void;
  removePerson: (id: string) => void;
  addProject: (p: Omit<Project, "id">) => void;
  updateProject: (id: string, p: Partial<Project>) => void;
  removeProject: (id: string) => void;
  addAllocation: (a: Omit<Allocation, "id">) => string | null;
  updateAllocation: (id: string, a: Partial<Allocation>) => void;
  removeAllocation: (id: string) => void;
  replaceAll: (data: CapacityData) => void;
  /** Additive: true while a mutation is in flight. */
  saving: boolean;
}

const CapacityContext = createContext<Store | null>(null);

/**
 * `capacity` is a headcount, not a sum of allocations.
 *
 * Summing allocations counts one person once per project they touch, so
 * somebody split across three projects inflated the figure to 3.0 "capacity".
 * Each distinct person is worth 1.0 FTE of capacity regardless of how many
 * projects they appear on, and people are matched by name — the same human
 * entered twice (Excel import plus a manual add, say) is still one person.
 *
 * `people` and `allocations` are optional so existing callers that only have
 * rows keep working; without them capacity falls back to the allocated total.
 */
export function totalsFor(
  rows: ProjectRow[],
  people?: Person[],
  allocations?: Allocation[],
): Totals {
  const allocated = round1(rows.reduce((s, r) => s + r.assigned, 0));
  const needed = round1(rows.reduce((s, r) => s + r.needed, 0));

  let capacity = allocated;
  if (people && allocations) {
    // Only the projects currently in view, so the KPI follows the filters.
    const visible = new Set(rows.map((r) => r.project.id));
    const names = new Set<string>();
    allocations.forEach((a) => {
      if (!visible.has(a.projectId)) return;
      const person = people.find((p) => p.id === a.personId);
      if (person) names.add(person.name.trim().toLowerCase());
    });
    capacity = names.size;
  }

  return {
    capacity,
    allocated,
    needed,
    gap: round1(rows.reduce((s, r) => s + Math.max(-r.gap, 0), 0)),
    projects: rows.length,
  };
}

export function CapacityProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<CapacityData>(EMPTY);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [loadError, setLoadError] = useState("");
  const [inFlight, setInFlight] = useState(0);

  // Mutations are chained rather than fired in parallel. The admin form calls
  // addPerson() then addAllocation() in the same tick; without ordering the
  // allocation POST could reach the server before the person exists and get
  // rejected with "Person not found".
  const queue = useRef<Promise<unknown>>(Promise.resolve());

  const load = useCallback(() => {
    setStatus("loading");
    request("/capacity")
      .then((d) => {
        setData(d);
        setStatus("ready");
      })
      .catch((err: Error) => {
        setLoadError(err.message);
        setStatus("error");
      });
  }, []);

  useEffect(load, [load]);

  /**
   * Queue a mutation and adopt whatever the server returns. No optimistic
   * update: the server validates, so a rejected write must not leave a
   * phantom row on screen.
   */
  const run = useCallback((path: string, init: RequestInit) => {
    setInFlight((n) => n + 1);
    queue.current = queue.current
      .then(() => request(path, init))
      .then(setData)
      .catch((err: Error) => {
        toast.error(err.message);
        // Re-sync so the UI shows server truth after a rejected write.
        return request("/capacity")
          .then(setData)
          .catch(() => {
            /* keep the last good state */
          });
      })
      .finally(() => setInFlight((n) => n - 1));
  }, []);

  const value = useMemo<Store>(() => {
    const peopleWithLoad = data.people.map((p) => ({
      ...p,
      allocated: round1(
        data.allocations.filter((a) => a.personId === p.id).reduce((s, a) => s + a.fte, 0),
      ),
    }));

    const rows: ProjectRow[] = [...data.projects]
      .sort((a, b) => a.priority - b.priority)
      .map((project) => {
        const allocs = data.allocations.filter((a) => a.projectId === project.id);
        const assigned = round1(allocs.reduce((s, a) => s + a.fte, 0));
        const people = allocs
          .map((a) => data.people.find((p) => p.id === a.personId))
          .filter((p): p is Person => Boolean(p));
        const needed = neededTotal(project);
        const gap = round1(assigned - needed);
        return {
          project,
          assigned,
          headcount: people.length,
          fteCount: people.filter((p) => p.employmentType === "FTE").length,
          ftcCount: people.filter((p) => p.employmentType === "FTC").length,
          needed,
          gap,
          byRole: roleBreakdownFor(project, data.people, data.allocations),
          status: statusFor(gap),
        };
      });

    return {
      data,
      rows,
      peopleWithLoad,
      totals: totalsFor(rows, data.people, data.allocations),
      saving: inFlight > 0,

      // Returns the id synchronously so the caller can allocate against it in
      // the same tick; the POST is queued behind whatever is already running.
      addPerson: (p) => {
        const id = uid();
        run("/people", json("POST", { ...p, id }));
        return id;
      },
      updatePerson: (id, patch) => run(`/people/${id}`, json("PATCH", patch)),
      removePerson: (id) => run(`/people/${id}`, json("DELETE")),

      addProject: (p) => run("/projects", json("POST", p)),
      updateProject: (id, patch) => run(`/projects/${id}`, json("PATCH", patch)),
      removeProject: (id) => run(`/projects/${id}`, json("DELETE")),

      // Stays synchronous so callers can keep doing `const err = addAllocation(...)`.
      // Fast local pre-check for good UX; the server re-validates and is the
      // real source of truth against concurrent edits.
      addAllocation: (a) => {
        // A person created earlier in this same tick is not in `data` yet, so
        // only reject ids that are neither known nor freshly minted.
        if (a.fte <= 0) return "Allocation must be greater than 0";
        if (!data.projects.some((p) => p.id === a.projectId)) return "Project not found";
        run("/allocations", json("POST", { ...a, id: uid() }));
        return null;
      },
      updateAllocation: (id, patch) => run(`/allocations/${id}`, json("PATCH", patch)),
      removeAllocation: (id) => run(`/allocations/${id}`, json("DELETE")),

      replaceAll: (next) => run("/capacity", json("PUT", next)),
    };
  }, [data, run, inFlight]);

  // Gate on the first load so components that seed local state from `data` on
  // mount (e.g. the admin form's default project selection) still work.
  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-sm text-muted-foreground">Loading team data…</p>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="max-w-md text-center">
          <h1 className="text-xl font-semibold text-foreground">Cannot reach the server</h1>
          <p className="mt-2 text-sm text-muted-foreground">{loadError}</p>
          <button
            onClick={load}
            className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  return <CapacityContext.Provider value={value}>{children}</CapacityContext.Provider>;
}

export function useCapacity() {
  const ctx = useContext(CapacityContext);
  if (!ctx) throw new Error("useCapacity must be used inside CapacityProvider");
  return ctx;
}
