import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  CircleDashed,
  Briefcase,
  Users,
  LayoutGrid,
  Settings,
  ChevronDown,
  BarChart3,
} from "lucide-react";
import {
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
} from "recharts";
import { ProjectIcon } from "@/components/capacity/icons";
import { useCapacity, totalsFor, type ProjectRow } from "@/lib/capacity-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI Team Capacity — At a Glance" },
      {
        name: "description",
        content:
          "Executive snapshot of AI team capacity: people allocated, work in progress, role gaps and the impact of delay.",
      },
      { property: "og:title", content: "AI Team Capacity — At a Glance" },
      {
        property: "og:description",
        content: "Executive snapshot of people, work in progress and the capacity gap.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const fmt = (n: number) => n.toFixed(1);

const clampPriority = (p: number) => Math.min(5, Math.max(1, Math.round(p || 5)));

const PRIORITY_COLORS = [
  "var(--color-chart-p1)",
  "var(--color-chart-p2)",
  "var(--color-chart-p3)",
  "var(--color-chart-p4)",
  "var(--color-chart-p5)",
];

function coverageTone(coverage: number) {
  if (coverage < 70) return { color: "var(--color-chart-red)", label: "Critical gap" };
  if (coverage < 80) return { color: "var(--color-chart-amber)", label: "Partly covered" };
  if (coverage >= 100) return { color: "var(--color-chart-green)", label: "Fully covered" };
  return { color: "var(--color-chart-amber)", label: "Partly covered" };
}

function Kpi({
  label,
  value,
  unit,
  caption,
  tone,
  icon: Icon,
}: {
  label: string;
  value: string;
  unit?: string;
  caption: string;
  tone: "info" | "success" | "warning" | "violet";
  icon: typeof Users;
}) {
  const tones = {
    info: "bg-info-soft text-info",
    success: "bg-success-soft text-success",
    warning: "bg-warning-soft text-warning",
    violet: "bg-accent text-accent-foreground",
  } as const;
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-start gap-4">
        <div className={cn("flex size-11 shrink-0 items-center justify-center rounded-xl", tones[tone])}>
          <Icon className="size-5" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground">{label}</p>
          <p className="mt-1 flex items-baseline gap-1.5">
            <span className={cn("font-display text-3xl leading-none", tones[tone].split(" ")[1])}>{value}</span>
            {unit ? <span className="text-sm text-muted-foreground">{unit}</span> : null}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">{caption}</p>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: "On Track" | "At Risk" | "Gap" }) {
  const tone =
    status === "On Track"
      ? "bg-success-soft text-success"
      : status === "At Risk"
        ? "bg-warning-soft text-warning"
        : "bg-danger-soft text-danger";
  return (
    <span className={cn("inline-flex rounded-md px-2.5 py-1 text-xs font-semibold", tone)}>{status}</span>
  );
}

const selectClass =
  "h-9 rounded-md border border-border bg-card px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

function ResourceAnalytics({ rows }: { rows: ProjectRow[] }) {
  const bubbles = rows.map((r) => {
    const coverage = r.needed > 0 ? Math.round((r.assigned / r.needed) * 100) : 100;
    const priority = clampPriority(r.project.priority);
    const priorityBand = priority <= 2 ? 3 : priority === 3 ? 2 : 1;
    return {
      name: r.project.name,
      coverage,
      priorityBand,
      allocated: r.assigned,
      needed: r.needed,
      priority,
      // bubble size = resource needed (FTE)
      size: r.needed,
      ...coverageTone(coverage),
    };
  });

  const maxNeeded = Math.max(1, ...bubbles.map((b) => b.size));


  const byPriority = new Map<number, number>();
  rows.forEach((r) => {
    const p = clampPriority(r.project.priority);
    byPriority.set(p, (byPriority.get(p) ?? 0) + r.assigned);
  });
  const donut = [...byPriority.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([p, value]) => ({ name: String(p), priority: p, value: Math.round(value * 10) / 10 }));
  const donutTotal = donut.reduce((s, d) => s + d.value, 0);

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="rounded-xl border border-border bg-card p-5">
        <p className="text-sm font-semibold text-foreground">Priority × Staffing Coverage</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Bubble size = resource needed · red &lt;70% · amber 70–99% · green 100% covered
        </p>
        <div className="mt-4 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis
                type="number"
                dataKey="coverage"
                name="Staffing coverage"
                unit="%"
                domain={[0, 100]}
                ticks={[0, 20, 40, 60, 80, 100]}
                tick={{ fontSize: 12 }}
              />
              <YAxis
                type="number"
                dataKey="priorityBand"
                name="Priority band"
                domain={[0.5, 3.5]}
                ticks={[1, 2, 3]}
                tickFormatter={(v: number) =>
                  v === 3 ? "High (1-2)" : v === 2 ? "Medium (3)" : "Low (4-5)"
                }
                tick={{ fontSize: 12 }}
              />
              <ZAxis type="number" dataKey="size" name="Resource needed" domain={[0, maxNeeded]} range={[140, 800]} />
              <Tooltip
                cursor={{ strokeDasharray: "3 3" }}
                formatter={(value: number | string, key: string) =>
                  key === "priorityBand"
                    ? [
                        value === 3 ? "High (1-2)" : value === 2 ? "Medium (3)" : "Low (4-5)",
                        "Priority band",
                      ]
                    : [value, key]
                }
                labelFormatter={() => ""}
                content={({ payload }) => {
                  const p = payload?.[0]?.payload as (typeof bubbles)[number] | undefined;
                  if (!p) return null;
                  const band =
                    p.priorityBand === 3 ? "High (1-2)" : p.priorityBand === 2 ? "Medium (3)" : "Low (4-5)";
                  return (
                    <div className="rounded-md border border-border bg-card px-3 py-2 text-xs shadow-sm">
                      <p className="font-semibold text-foreground">{p.name}</p>
                      <p className="text-muted-foreground">Priority {p.priority} · {band}</p>
                      <p className="text-muted-foreground">Coverage {p.coverage}% · {p.label}</p>
                      <p className="text-muted-foreground">Allocated {fmt(p.allocated)} / needed {fmt(p.needed)} FTE</p>
                    </div>
                  );
                }}
              />
              <Scatter data={bubbles} fillOpacity={0.75}>
                {bubbles.map((b) => (
                  <Cell key={b.name} fill={b.color} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <p className="text-sm font-semibold text-foreground">Allocation by Priority</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Total allocated {fmt(donutTotal)} FTE across prioritization 1–5 · priority 1 = highest
        </p>
        <div className="relative mt-4 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={donut} dataKey="value" nameKey="name" innerRadius={70} outerRadius={105} paddingAngle={1}>
                {donut.map((d) => (
                  <Cell key={d.name} fill={PRIORITY_COLORS[d.priority - 1]} stroke="var(--color-card)" />
                ))}
              </Pie>
              <Tooltip formatter={(v: number, n: string) => [`${v} FTE`, `Priority ${n}`]} />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center pb-8">
            <span className="font-display text-2xl font-semibold text-foreground">{fmt(donutTotal)}</span>
            <span className="text-xs text-muted-foreground">FTE</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Dashboard() {
  const { rows, data } = useCapacity();
  const [open, setOpen] = useState(false);
  const [project, setProject] = useState("all");
  const [tier, setTier] = useState("all");
  const [sponsor, setSponsor] = useState("all");

  const sponsors = useMemo(
    () => [...new Set(data.projects.map((p) => p.sponsor).filter(Boolean))].sort(),
    [data.projects],
  );

  const filtered = rows.filter(
    (r) =>
      (project === "all" || r.project.name === project) &&
      (tier === "all" || String(clampPriority(r.project.priority)) === tier) &&
      (sponsor === "all" || r.project.sponsor === sponsor),
  );
  const totals = totalsFor(filtered, data.people, data.allocations);

  const asOf = new Date(`${data.asOf}T00:00:00`).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  return (
    <main className="min-h-screen bg-surface px-4 py-8 md:px-10 md:py-12">
      <div className="mx-auto max-w-7xl">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl tracking-tight text-foreground md:text-4xl">
              AI Team Capacity — At a Glance
            </h1>
            <p className="mt-2 text-muted-foreground">
              Snapshot of people, work in progress, and capacity gap
            </p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">As of {asOf}</span>
            <Link
              to="/admin"
              className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
            >
              <Settings className="size-4" /> Manage data
            </Link>
          </div>
        </header>

        <section className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Kpi
            label="Total Capacity"
            value={fmt(totals.capacity)}
            unit="FTE"
            caption="People allocated to work"
            tone="info"
            icon={Users}
          />
          <Kpi
            label="Currently Allocated"
            value={fmt(totals.allocated)}
            unit="FTE"
            caption="Working on current work"
            tone="success"
            icon={Briefcase}
          />
          <Kpi
            label="Capacity Gap"
            value={fmt(totals.gap)}
            caption="Additional capacity needed"
            tone="warning"
            icon={CircleDashed}
          />
          <Kpi
            label="Active Work Areas"
            value={String(totals.projects)}
            caption="Projects / initiatives"
            tone="violet"
            icon={LayoutGrid}
          />
        </section>

        <section className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left transition-colors hover:bg-accent/50"
          >
            <span className="flex items-center gap-3">
              <BarChart3 className="size-5 text-info" />
              <span>
                <span className="block text-sm font-semibold text-foreground">Resource summary</span>
                <span className="block text-xs text-muted-foreground">
                  Analytics and filters across projects, priority and sponsor
                </span>
              </span>
            </span>
            <ChevronDown className={cn("size-5 text-muted-foreground transition-transform", open && "rotate-180")} />
          </button>

          {open && (
            <div className="border-t border-border p-5">
              <div className="flex flex-wrap items-end gap-3">
                <label className="flex flex-col gap-1 text-xs font-medium text-muted-foreground">
                  Project Name
                  <select className={selectClass} value={project} onChange={(e) => setProject(e.target.value)}>
                    <option value="all">All projects</option>
                    {data.projects.map((p) => (
                      <option key={p.id} value={p.name}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex flex-col gap-1 text-xs font-medium text-muted-foreground">
                  Prioritization
                  <select className={selectClass} value={tier} onChange={(e) => setTier(e.target.value)}>
                    <option value="all">All priorities</option>
                    {[1, 2, 3, 4, 5].map((p) => (
                      <option key={p} value={String(p)}>
                        Priority {p}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex flex-col gap-1 text-xs font-medium text-muted-foreground">
                  Project Sponsor
                  <select className={selectClass} value={sponsor} onChange={(e) => setSponsor(e.target.value)}>
                    <option value="all">All sponsors</option>
                    {sponsors.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setProject("all");
                    setTier("all");
                    setSponsor("all");
                  }}
                  className="h-9 rounded-md border border-border px-3 text-sm text-muted-foreground transition-colors hover:bg-accent"
                >
                  Clear filters
                </button>
              </div>

              <div className="mt-5">
                <ResourceAnalytics rows={filtered} />
              </div>
            </div>
          )}
        </section>

        <section className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[62rem] text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  <th className="px-5 py-4">What we are working on</th>
                  <th className="px-4 py-4 text-center">Resource Allocated</th>
                  <th className="px-4 py-4">Project Needs Snapshot</th>
                  <th className="px-4 py-4 text-center">Gap</th>
                  <th className="px-4 py-4 text-center">Status</th>
                  <th className="px-5 py-4">Impact if Delayed</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.project.id} className="border-b border-border last:border-0 align-top">
                    <td className="px-5 py-4">
                      <div className="flex items-start gap-3">
                        <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
                          <ProjectIcon name={row.project.icon} className="size-4" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">{row.project.name}</p>
                          <p className="text-muted-foreground">{row.project.description}</p>
                          {row.project.sponsor ? (
                            <p className="mt-1 text-xs text-muted-foreground">
                              Sponsor: {row.project.sponsor}
                            </p>
                          ) : null}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-center">
                      <p className="font-display text-lg text-foreground">{fmt(row.assigned)}</p>
                      <p className="text-xs text-muted-foreground">
                        {row.headcount} {row.headcount === 1 ? "person" : "people"} · {row.fteCount} FTE ·{" "}
                        {row.ftcCount} FTC
                      </p>
                    </td>
                    <td className="px-4 py-4">
                      <ul className="space-y-1">
                        {row.project.neededByRole.map((need) => (
                          <li key={need.role} className="text-muted-foreground">
                            <span className="font-medium text-foreground">{fmt(need.fte)}</span> {need.role}
                          </li>
                        ))}
                      </ul>
                    </td>
                    <td
                      className={cn(
                        "px-4 py-4 text-center font-display text-lg",
                        row.gap < 0 ? "text-danger" : "text-success",
                      )}
                    >
                      {row.gap > 0 ? "+" : ""}
                      {fmt(row.gap)}
                    </td>
                    <td className="px-4 py-4 text-center">
                      <StatusBadge status={row.status} />
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className={cn(
                          "mb-1 inline-flex rounded-md px-2 py-0.5 text-xs font-semibold",
                          row.project.impactLevel === "High"
                            ? "bg-danger-soft text-danger"
                            : row.project.impactLevel === "Medium"
                              ? "bg-warning-soft text-warning"
                              : "bg-secondary text-secondary-foreground",
                        )}
                      >
                        {row.project.impactLevel}
                      </span>
                      <p className="text-muted-foreground">{row.project.impactIfDelayed}</p>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-5 py-10 text-center text-muted-foreground">
                      No projects match the current filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </main>
  );
}
