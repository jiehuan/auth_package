import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import tailwindcss from "@tailwindcss/vite";
import viteReact from "@vitejs/plugin-react";
import { nitro } from "nitro/vite";
import { defineConfig } from "vite";
import tsConfigPaths from "vite-tsconfig-paths";

// Nitro emits a self-contained Node server into .output/ for container deploys.
// Override with NITRO_PRESET=<preset> if you ever target something else.
const nitroPreset = process.env["NITRO_PRESET"] ?? "node-server";

export default defineConfig({
  plugins: [
    tailwindcss(),
    tsConfigPaths({ projects: ["./tsconfig.json"] }),
    tanstackStart({
      // Keeps server-only modules from leaking into the client bundle.
      importProtection: {
        behavior: "error",
        client: {
          files: ["**/server/**"],
          specifiers: ["server-only"],
        },
      },
      // Routes TanStack Start's bundled server entry through src/server.ts,
      // which wraps SSR in an error handler.
      server: { entry: "server" },
    }),
    nitro({ preset: nitroPreset }),
    viteReact(),
  ],

  resolve: {
    alias: { "@": `${process.cwd()}/src` },
    // A duplicate React or Query copy breaks hooks and context at runtime.
    dedupe: [
      "react",
      "react-dom",
      "react/jsx-runtime",
      "react/jsx-dev-runtime",
      "@tanstack/react-query",
      "@tanstack/query-core",
    ],
  },

  optimizeDeps: {
    include: [
      "react",
      "react-dom",
      "react-dom/client",
      "react/jsx-runtime",
      "react/jsx-dev-runtime",
    ],
  },

  server: {
    // Lets `vite dev` reach the API without CORS. Backend default port is 8080.
    proxy: {
      "/api": {
        target: process.env["API_PROXY_TARGET"] ?? "http://localhost:8080",
        changeOrigin: true,
      },
    },
  },
});
