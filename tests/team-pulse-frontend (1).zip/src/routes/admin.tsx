import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTransfer } from "@/components/capacity/DataTransfer";
import { useCapacity } from "@/lib/capacity-store";
import {
  PROJECT_ICONS,
  ROLES,
  neededTotal,
  round1,
  type EmploymentType,
  type ImpactLevel,
  type RoleNeed,
} from "@/lib/capacity-types";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Manage Team Capacity Data — Admin" },
      {
        name: "description",
        content: "Add or edit projects and resource assignments, and move the dataset in and out of Excel.",
      },
      { property: "og:title", content: "Manage Team Capacity Data — Admin" },
      {
        property: "og:description",
        content: "Add projects and resources, edit allocations, download and upload Excel.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});

const selectClass = "h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="font-display text-lg text-foreground">{title}</h3>
      <div className="mt-4">{children}</div>
    </div>
  );
}

function TotalsStrip() {
  const { totals, data } = useCapacity();
  const items = [
    ["Allocated", `${totals.allocated.toFixed(1)} FTE`],
    ["Resource needed", `${totals.needed.toFixed(1)} FTE`],
    ["Capacity gap", totals.gap.toFixed(1)],
    ["People", String(data.people.length)],
    ["Work areas", String(totals.projects)],
  ] as const;
  return (
    <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
      {items.map(([label, value]) => (
        <div key={label} className="rounded-xl border border-border bg-card px-4 py-3">
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          <p className="font-display text-xl text-foreground">{value}</p>
        </div>
      ))}
    </div>
  );
}

function ProjectsTab() {
  const { data, rows, addProject, removeProject, updateProject } = useCapacity();

  const [name, setName] = useState("");
  const [sponsor, setSponsor] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState(PROJECT_ICONS[0]!);
  const [priority, setPriority] = useState(Math.min(5, data.projects.length + 1));
  const [impact, setImpact] = useState("");
  const [impactLevel, setImpactLevel] = useState<ImpactLevel>("Medium");
  const [roles, setRoles] = useState<RoleNeed[]>([{ role: ROLES[1]!, fte: 1 }]);

  function submit() {
    if (!name.trim()) {
      toast.error("Project name is required");
      return;
    }
    addProject({
      name: name.trim(),
      sponsor: sponsor.trim(),
      description: description.trim(),
      icon,
      priority: Math.min(5, Math.max(1, Number(priority) || 5)),
      neededByRole: roles.filter((r) => r.role && r.fte > 0),
      impactIfDelayed: impact.trim(),
      impactLevel,
    });
    setName("");
    setSponsor("");
    setDescription("");
    setImpact("");
    setRoles([{ role: ROLES[1]!, fte: 1 }]);
    toast.success("Project added");
  }

  return (
    <div className="space-y-4">
      <Section title="Add a project">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Project Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Next Gen UW" />
          </div>
          <div className="space-y-1.5">
            <Label>Project Sponsor</Label>
            <Input
              value={sponsor}
              onChange={(e) => setSponsor(e.target.value)}
              placeholder="Chief Underwriting Officer"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Project Description</Label>
            <Input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Building new underwriting capabilities"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Icon</Label>
            <select className={selectClass} value={icon} onChange={(e) => setIcon(e.target.value)}>
              {PROJECT_ICONS.map((i) => (
                <option key={i} value={i}>
                  {i}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Prioritization</Label>
            <Input
              type="number"
              min={1}
              max={5}
              value={priority}
              onChange={(e) => setPriority(Math.min(5, Math.max(1, Number(e.target.value) || 1)))}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Impact level if delayed</Label>
            <select
              className={selectClass}
              value={impactLevel}
              onChange={(e) => setImpactLevel(e.target.value as ImpactLevel)}
            >
              {(["High", "Medium", "Low"] as const).map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5 md:col-span-2">
            <Label>Impact if delayed</Label>
            <Input
              value={impact}
              onChange={(e) => setImpact(e.target.value)}
              placeholder="Launch slips a full quarter"
            />
          </div>
        </div>

        <div className="mt-5">
          <Label>Resource by role — resource needed</Label>
          <div className="mt-2 space-y-2">
            {roles.map((r, idx) => (
              <div key={idx} className="flex flex-wrap items-center gap-2">
                <select
                  className={`${selectClass} max-w-60`}
                  value={r.role}
                  onChange={(e) =>
                    setRoles(roles.map((x, i) => (i === idx ? { ...x, role: e.target.value } : x)))
                  }
                >
                  {ROLES.map((role) => (
                    <option key={role} value={role}>
                      {role}
                    </option>
                  ))}
                </select>
                <Input
                  className="w-28"
                  type="number"
                  step="0.1"
                  min="0"
                  value={r.fte}
                  onChange={(e) =>
                    setRoles(roles.map((x, i) => (i === idx ? { ...x, fte: Number(e.target.value) } : x)))
                  }
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setRoles(roles.filter((_, i) => i !== idx))}
                  aria-label="Remove role"
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={() => setRoles([...roles, { role: ROLES[0]!, fte: 1 }])}>
              <Plus className="size-4" /> Add role
            </Button>
          </div>
        </div>

        <div className="mt-5">
          <Button onClick={submit}>
            <Plus className="size-4" /> Add project
          </Button>
        </div>
      </Section>

      <Section title="Projects">
        <div className="space-y-4">
          {rows.map((row) => (
            <div key={row.project.id} className="rounded-lg border border-border p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-semibold text-foreground">{row.project.name}</p>
                  <p className="text-sm text-muted-foreground">{row.project.description}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Sponsor: {row.project.sponsor || "—"} · Priority {row.project.priority} · Needed{" "}
                    {neededTotal(row.project).toFixed(1)} · Allocated {row.assigned.toFixed(1)} · Gap{" "}
                    {row.gap.toFixed(1)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    className="w-24"
                    type="number"
                    min={1}
                    max={5}
                    value={row.project.priority}
                    onChange={(e) =>
                      updateProject(row.project.id, {
                        priority: Math.min(5, Math.max(1, Number(e.target.value) || 1)),
                      })
                    }
                    aria-label="Prioritization"
                  />
                  <Button variant="ghost" size="icon" onClick={() => removeProject(row.project.id)}>
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </div>

              <div className="mt-3 overflow-x-auto">
                <table className="w-full min-w-[34rem] text-sm">
                  <thead>
                    <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase">
                      <th className="py-2 pr-3">Role</th>
                      <th className="py-2 pr-3 text-center">Needed</th>
                      <th className="py-2 pr-3 text-center">Existing</th>
                      <th className="py-2 pr-3 text-center">FTE</th>
                      <th className="py-2 pr-3 text-center">FTC</th>
                      <th className="py-2 text-center">Gap</th>
                    </tr>
                  </thead>
                  <tbody>
                    {row.byRole.map((r) => (
                      <tr key={r.role} className="border-b border-border last:border-0">
                        <td className="py-2 pr-3 text-foreground">{r.role}</td>
                        <td className="py-2 pr-3 text-center">{r.needed.toFixed(1)}</td>
                        <td className="py-2 pr-3 text-center">{r.existing.toFixed(1)}</td>
                        <td className="py-2 pr-3 text-center">{r.fte.toFixed(1)}</td>
                        <td className="py-2 pr-3 text-center">{r.ftc.toFixed(1)}</td>
                        <td
                          className={`py-2 text-center ${r.gap < 0 ? "text-danger" : "text-success"}`}
                        >
                          {r.gap.toFixed(1)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

function PeopleTab() {
  const { data, addPerson, addAllocation, removeAllocation, updateAllocation, removePerson } = useCapacity();

  const [projectId, setProjectId] = useState(data.projects[0]?.id ?? "");
  const [name, setName] = useState("");
  const [role, setRole] = useState(ROLES[1]!);
  const [employmentType, setEmploymentType] = useState<EmploymentType>("FTE");
  const [allocation, setAllocation] = useState(1);

  function submit() {
    if (!name.trim()) {
      toast.error("Resource name is required");
      return;
    }
    if (!projectId) {
      toast.error("Add a project first");
      return;
    }
    const existing = data.people.find((p) => p.name.toLowerCase() === name.trim().toLowerCase());
    const personId = existing
      ? existing.id
      : addPerson({ name: name.trim(), role, employmentType });
    const error = addAllocation({ personId, projectId, fte: Number(allocation) });
    if (error) {
      toast.error(error);
      return;
    }
    setName("");
    setAllocation(1);
    toast.success("Resource assignment added");
  }

  const assignments = data.allocations.map((a) => ({
    allocation: a,
    person: data.people.find((p) => p.id === a.personId),
    project: data.projects.find((p) => p.id === a.projectId),
  }));

  return (
    <div className="space-y-4">
      <Section title="Add a resource assignment">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Project Name</Label>
            <select className={selectClass} value={projectId} onChange={(e) => setProjectId(e.target.value)}>
              {data.projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Resource Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sarah Chen" />
          </div>
          <div className="space-y-1.5">
            <Label>Role</Label>
            <select className={selectClass} value={role} onChange={(e) => setRole(e.target.value)}>
              {ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Employment Type</Label>
            <select
              className={selectClass}
              value={employmentType}
              onChange={(e) => setEmploymentType(e.target.value as EmploymentType)}
            >
              <option value="FTE">FTE</option>
              <option value="FTC">FTC</option>
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Allocation</Label>
            <Input
              type="number"
              step="0.1"
              min="0"
              value={allocation}
              onChange={(e) => setAllocation(Number(e.target.value))}
            />
          </div>
        </div>
        <div className="mt-5">
          <Button onClick={submit}>
            <Plus className="size-4" /> Add assignment
          </Button>
        </div>
      </Section>

      <Section title="People">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[42rem] text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase">
                <th className="py-2 pr-3">Project Name</th>
                <th className="py-2 pr-3">Resource Name</th>
                <th className="py-2 pr-3">Role</th>
                <th className="py-2 pr-3">Employment Type</th>
                <th className="py-2 pr-3 text-center">Allocation</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {assignments.map(({ allocation: a, person, project }) => (
                <tr key={a.id} className="border-b border-border last:border-0">
                  <td className="py-2 pr-3 text-foreground">{project?.name ?? "—"}</td>
                  <td className="py-2 pr-3 text-foreground">{person?.name ?? "—"}</td>
                  <td className="py-2 pr-3 text-muted-foreground">{person?.role ?? "—"}</td>
                  <td className="py-2 pr-3 text-muted-foreground">{person?.employmentType ?? "—"}</td>
                  <td className="py-2 pr-3 text-center">
                    <Input
                      className="mx-auto w-24"
                      type="number"
                      step="0.1"
                      min="0"
                      value={a.fte}
                      onChange={(e) => updateAllocation(a.id, { fte: round1(Number(e.target.value)) })}
                      aria-label="Allocation"
                    />
                  </td>
                  <td className="py-2 text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        removeAllocation(a.id);
                        const other = data.allocations.filter(
                          (x) => x.personId === a.personId && x.id !== a.id,
                        );
                        if (other.length === 0 && person) removePerson(person.id);
                      }}
                      aria-label="Remove assignment"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>
    </div>
  );
}

function Admin() {
  return (
    <main className="min-h-screen bg-surface px-4 py-8 md:px-10 md:py-12">
      <div className="mx-auto max-w-6xl space-y-6">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl tracking-tight text-foreground">Manage capacity data</h1>
            <p className="mt-1 text-muted-foreground">
              Everything here feeds the executive dashboard directly.
            </p>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            <ArrowLeft className="size-4" /> Back to dashboard
          </Link>
        </header>

        <TotalsStrip />
        <DataTransfer />

        <Tabs defaultValue="projects">
          <TabsList>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="people">People</TabsTrigger>
          </TabsList>
          <TabsContent value="projects" className="mt-4">
            <ProjectsTab />
          </TabsContent>
          <TabsContent value="people" className="mt-4">
            <PeopleTab />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  );
}
