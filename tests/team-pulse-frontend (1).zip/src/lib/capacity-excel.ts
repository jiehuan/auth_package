import * as XLSX from "xlsx";
import {
  type Allocation,
  type CapacityData,
  type Person,
  type Project,
  type RoleNeed,
} from "./capacity-types";

const encodeRoles = (roles: RoleNeed[]) => roles.map((r) => `${r.role}:${r.fte}`).join("; ");

function decodeRoles(value: unknown): RoleNeed[] {
  if (typeof value !== "string" || !value.trim()) return [];
  return value
    .split(";")
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .map((chunk) => {
      const idx = chunk.lastIndexOf(":");
      const role = idx === -1 ? chunk : chunk.slice(0, idx).trim();
      const fte = idx === -1 ? 0 : Number(chunk.slice(idx + 1).trim());
      return { role, fte: Number.isFinite(fte) ? fte : 0 };
    });
}

/** Two detail sheets only — every total, gap and status is recalculated by the app. */
export function exportToExcel(data: CapacityData) {
  const wb = XLSX.utils.book_new();

  const projects = data.projects.map((p) => ({
    "Project Name": p.name,
    "Project Sponsor": p.sponsor,
    "Project Description": p.description,
    Icon: p.icon,
    Prioritization: p.priority,
    "Impact if delayed": p.impactIfDelayed,
    "Resource by role — resource needed": encodeRoles(p.neededByRole),
  }));

  const people = data.allocations.map((a) => {
    const person = data.people.find((p) => p.id === a.personId);
    return {
      "Project Name": data.projects.find((p) => p.id === a.projectId)?.name ?? "",
      "Resource Name": person?.name ?? "",
      Role: person?.role ?? "",
      "Employment Type": person?.employmentType ?? "FTE",
      Allocation: a.fte,
    };
  });

  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(projects), "Projects");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(people), "People");

  XLSX.writeFile(wb, `team-capacity-${data.asOf}.xlsx`);
}

export interface ImportResult {
  data?: CapacityData;
  errors: string[];
}

const str = (v: unknown) => (v === undefined || v === null ? "" : String(v).trim());
const num = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
};

export async function importFromExcel(file: File): Promise<ImportResult> {
  const errors: string[] = [];
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: "array" });

  for (const sheet of ["Projects", "People"]) {
    if (!wb.SheetNames.includes(sheet)) errors.push(`Missing sheet: ${sheet}`);
  }
  if (errors.length) return { errors };

  const readSheet = (name: string) =>
    XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[name]!, { defval: "" });

  const projects: Project[] = [];
  readSheet("Projects").forEach((row, i) => {
    const name = str(row["Project Name"]);
    if (!name) {
      errors.push(`Projects row ${i + 2}: Project Name is required`);
      return;
    }
    const roles = decodeRoles(row["Resource by role — resource needed"] ?? row["Resource Needed By Role"]);
    if (roles.some((r) => !r.role || !Number.isFinite(r.fte))) {
      errors.push(
        `Projects row ${i + 2}: "Resource by role — resource needed" must look like "Data Scientist:2.0; ML Engineer:1.0"`,
      );
      return;
    }
    const impact = str(row["Impact if delayed"]);
    projects.push({
      id: `pr-${i}-${Date.now()}`,
      name,
      sponsor: str(row["Project Sponsor"]),
      description: str(row["Project Description"]),
      icon: str(row["Icon"]) || "rocket",
      priority: Math.min(5, Math.max(1, Math.round(num(row["Prioritization"]) || Math.min(i + 1, 5)))),
      neededByRole: roles,
      impactIfDelayed: impact,
      impactLevel: "Medium",
    });
  });

  const people: Person[] = [];
  const allocations: Allocation[] = [];

  readSheet("People").forEach((row, i) => {
    const personName = str(row["Resource Name"]);
    const projectName = str(row["Project Name"]);
    if (!personName && !projectName) return;
    if (!personName) {
      errors.push(`People row ${i + 2}: Resource Name is required`);
      return;
    }
    const project = projects.find((p) => p.name.toLowerCase() === projectName.toLowerCase());
    if (!project) {
      errors.push(`People row ${i + 2}: unknown Project Name "${projectName}"`);
      return;
    }
    const employment = str(row["Employment Type"]).toUpperCase();
    if (employment !== "FTE" && employment !== "FTC") {
      errors.push(`People row ${i + 2}: Employment Type must be FTE or FTC`);
      return;
    }
    const fte = num(row["Allocation"]);
    if (!Number.isFinite(fte) || fte <= 0) {
      errors.push(`People row ${i + 2}: Allocation must be greater than 0`);
      return;
    }
    const role = str(row["Role"]) || "Unassigned";
    let person = people.find((p) => p.name.toLowerCase() === personName.toLowerCase());
    if (!person) {
      person = { id: `p-${i}-${Date.now()}`, name: personName, role, employmentType: employment };
      people.push(person);
    }
    allocations.push({
      id: `a-${i}-${Date.now()}`,
      personId: person.id,
      projectId: project.id,
      fte,
    });
  });

  if (errors.length) return { errors };

  return {
    data: { asOf: new Date().toISOString().slice(0, 10), people, projects, allocations },
    errors: [],
  };
}
