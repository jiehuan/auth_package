import {
  Brain,
  Database,
  FileText,
  Rocket,
  Server,
  Shield,
  TrendingUp,
  Users,
  type LucideIcon,
} from "lucide-react";

const MAP: Record<string, LucideIcon> = {
  rocket: Rocket,
  "trending-up": TrendingUp,
  shield: Shield,
  "file-text": FileText,
  server: Server,
  users: Users,
  brain: Brain,
  database: Database,
};

export function ProjectIcon({ name, className }: { name: string; className?: string }) {
  const Icon = MAP[name] ?? Rocket;
  return <Icon className={className} />;
}
