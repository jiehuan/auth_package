# AI Team Capacity Dashboard

An executive-friendly, English-language app that shows team resources at a glance, plus an admin screen with forms to add or edit projects and people. All data lives in the browser (seeded demo data, persisted to localStorage), so nothing needs a backend yet. The full detail data can be downloaded as an Excel workbook (Projects / People / Allocations sheets), edited offline, and re-uploaded to replace the stored data — validation runs on upload and the dashboard refreshes immediately.

## Screens

### 1. Executive view (`/`)
Modeled closely on the mockup:

- Header: "AI Team Capacity — At a Glance" + subtitle + "As of <date>".
- Four KPI cards: Total Capacity (FTE), Currently Allocated (FTE), Capacity Gap (FTE), Active Work Areas (count).
- Two extra KPI chips for the resource-type split: Fixed FTE (locked to a project) and Floating FTE (reallocatable) — this is the "how many are flexible" question the boss will ask.
- Table "What we are working on": icon, project name + one-line description, People Assigned (headcount + FTE, with the FTE/FTC split shown as a small "3 FTE · 1 FTC" line), People Needed by role (e.g. "2.0 Data Scientist, 1.0 ML Engineer" — hover/expand for the full role breakdown), total People Needed (FTE), Gap (FTE), Status badge (On Track / At Risk / Gap), and Impact if Delayed (short plain-English consequence, e.g. "Launch slips 1 quarter", color-coded High / Medium / Low).
- Footer callout: "To close the gap of X FTE, we can reallocate from lower priority work, reduce scope, or add capacity."
- Optional small section: list of floating people currently unassigned, so the exec sees available slack.

Everything computed from the data, not hardcoded: allocated = sum of assignments, gap = assigned − needed, totals roll up automatically.

### 2. Admin view (`/admin`)
No login (per your answer). Three tabs:

- **People** — add/edit/remove a person: name, role, employment type (FTE / FTC), total capacity (e.g. 1.0), and whether they are Floating (reallocatable) or Fixed. Shows remaining unallocated capacity per person.
- **Projects** — add/edit/remove a project: name, description, icon/color, People Needed (FTE), priority.
- **Allocations** — assign a person to a project with an FTE amount (0.1 steps). One person can be split across several projects; validation blocks over-allocating past their capacity. Each allocation is marked Fixed or Floating so the exec view can split the totals.

A "Reset to sample data" button restores the seeded numbers from the mockup.

## Data model (in-memory)

```text
Person     { id, name, role, employmentType: "FTE" | "FTC", capacity, isFloating }
Project    { id, name, description, icon, neededFte, priority }
Allocation { id, personId, projectId, fte, kind: "fixed" | "floating" }
```

Derived: assigned per project = sum of allocation fte; gap = assigned − needed; total capacity = sum of person capacity; floating pool = capacity of floating people not yet allocated.

## Technical notes

- Data lives in a single React context/store, seeded with the six work areas from the mockup (Next Gen UW, Pricing Analytics, Claims Analytics, Submission Support, Production Models, Regulatory & BAU) and matching people so the KPI numbers reproduce 11.0 / 10.2 / 2.8 / 6.
- Persisted to `localStorage` so admin edits survive a refresh; still no backend.
- Clean, light, executive design: white cards, soft borders, generous spacing, green/amber/red only for status semantics — tokens added to `src/styles.css`, no hardcoded colors in components.
- Routes: `src/routes/index.tsx` (exec view) and `src/routes/admin.tsx`, each with its own head metadata. All UI copy in English.

## Later (not in this pass)

Cloud database + admin login can be added on top of the same data model when you want multiple people editing shared data.
