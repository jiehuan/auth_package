export type EmploymentType = "FTE" | "FTC";
export type AllocationKind = "fixed" | "floating";
export type ImpactLevel = "High" | "Medium" | "Low";
export type ProjectStatus = "On Track" | "At Risk" | "Gap";

export interface Person {
  id: string;
  name: string;
  role: string;
  employmentType: EmploymentType;
  capacity: number;
  isFloating: boolean;
}

export interface RoleNeed {
  role: string;
  fte: number;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  icon: string;
  neededByRole: RoleNeed[];
  priority: number;
  impactIfDelayed: string;
  impactLevel: ImpactLevel;
}

export interface Allocation {
  id: string;
  personId: string;
  projectId: string;
  fte: number;
  kind: AllocationKind;
}

export interface CapacityData {
  asOf: string;
  people: Person[];
  projects: Project[];
  allocations: Allocation[];
}

export interface RoleBreakdown {
  role: string;
  needed: number;
  existing: number;
  fte: number;
  ftc: number;
  fixed: number;
  floating: number;
  gap: number;
}


export const ROLES = [
  "Lead Data Scientist",
  "Data Scientist",
  "ML Engineer",
  "Data Engineer",
  "MLOps Engineer",
  "Analytics Lead",
  "Business Analyst",
  "Product Owner",
];

export const PROJECT_ICONS = [
  "rocket",
  "trending-up",
  "shield",
  "file-text",
  "server",
  "users",
  "brain",
  "database",
];

export const round1 = (n: number) => Math.round(n * 10) / 10;

export function neededTotal(project: Project) {
  return round1(project.neededByRole.reduce((sum, r) => sum + r.fte, 0));
}

export function statusFor(gap: number): ProjectStatus {
  if (gap >= 0) return "On Track";
  if (gap >= -0.5) return "At Risk";
  return "Gap";
}
