import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { SEED_DATA } from "./capacity-seed";
import {
  neededTotal,
  round1,
  statusFor,
  type Allocation,
  type CapacityData,
  type Person,
  type Project,
  type RoleBreakdown,
} from "./capacity-types";

const STORAGE_KEY = "ai-team-capacity-v1";

export function roleBreakdownFor(
  project: Project,
  people: Person[],
  allocations: Allocation[],
): RoleBreakdown[] {
  const map = new Map<string, RoleBreakdown>();
  const ensure = (role: string) => {
    let entry = map.get(role);
    if (!entry) {
      entry = { role, needed: 0, existing: 0, fte: 0, ftc: 0, fixed: 0, floating: 0, gap: 0 };
      map.set(role, entry);
    }
    return entry;
  };

  project.neededByRole.forEach((need) => {
    ensure(need.role).needed += need.fte;
  });

  allocations
    .filter((a) => a.projectId === project.id)
    .forEach((a) => {
      const person = people.find((p) => p.id === a.personId);
      if (!person) return;
      const entry = ensure(person.role);
      entry.existing += a.fte;
      if (person.employmentType === "FTE") entry.fte += a.fte;
      else entry.ftc += a.fte;
      if (a.kind === "fixed") entry.fixed += a.fte;
      else entry.floating += a.fte;
    });

  return [...map.values()]
    .map((e) => ({
      role: e.role,
      needed: round1(e.needed),
      existing: round1(e.existing),
      fte: round1(e.fte),
      ftc: round1(e.ftc),
      fixed: round1(e.fixed),
      floating: round1(e.floating),
      gap: round1(e.existing - e.needed),
    }))
    .sort((a, b) => b.needed - a.needed || a.role.localeCompare(b.role));
}

export interface ProjectRow {
  project: Project;
  assigned: number;
  headcount: number;
  fteCount: number;
  ftcCount: number;
  needed: number;
  gap: number;
  byRole: RoleBreakdown[];
  status: ReturnType<typeof statusFor>;
}


interface Store {
  data: CapacityData;
  rows: ProjectRow[];
  totals: {
    capacity: number;
    allocated: number;
    gap: number;
    projects: number;
    fixed: number;
    floating: number;
    unallocatedFloating: number;
  };
  peopleWithLoad: Array<Person & { allocated: number; remaining: number }>;
  addPerson: (p: Omit<Person, "id">) => void;
  updatePerson: (id: string, p: Partial<Person>) => void;
  removePerson: (id: string) => void;
  addProject: (p: Omit<Project, "id">) => void;
  updateProject: (id: string, p: Partial<Project>) => void;
  removeProject: (id: string) => void;
  addAllocation: (a: Omit<Allocation, "id">) => string | null;
  updateAllocation: (id: string, a: Partial<Allocation>) => void;
  removeAllocation: (id: string) => void;
  replaceAll: (data: CapacityData) => void;
  reset: () => void;
}

const CapacityContext = createContext<Store | null>(null);

const uid = () => Math.random().toString(36).slice(2, 10);

export function CapacityProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<CapacityData>(SEED_DATA);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setData(JSON.parse(raw) as CapacityData);
    } catch {
      /* ignore malformed storage */
    }
  }, []);

  const persist = useCallback((next: CapacityData) => {
    setData(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
  }, []);

  const value = useMemo<Store>(() => {
    const allocatedFor = (personId: string) =>
      round1(data.allocations.filter((a) => a.personId === personId).reduce((s, a) => s + a.fte, 0));

    const peopleWithLoad = data.people.map((p) => {
      const allocated = allocatedFor(p.id);
      return { ...p, allocated, remaining: round1(p.capacity - allocated) };
    });

    const rows: ProjectRow[] = [...data.projects]
      .sort((a, b) => a.priority - b.priority)
      .map((project) => {
        const allocs = data.allocations.filter((a) => a.projectId === project.id);
        const assigned = round1(allocs.reduce((s, a) => s + a.fte, 0));
        const people = allocs
          .map((a) => data.people.find((p) => p.id === a.personId))
          .filter((p): p is Person => Boolean(p));
        const needed = neededTotal(project);
        const gap = round1(assigned - needed);
        return {
          project,
          assigned,
          headcount: people.length,
          fteCount: people.filter((p) => p.employmentType === "FTE").length,
          ftcCount: people.filter((p) => p.employmentType === "FTC").length,
          needed,
          gap,
          byRole: roleBreakdownFor(project, data.people, data.allocations),

          status: statusFor(gap),
        };
      });

    const capacity = round1(data.people.reduce((s, p) => s + p.capacity, 0));
    const allocated = round1(data.allocations.reduce((s, a) => s + a.fte, 0));
    const fixed = round1(
      data.allocations.filter((a) => a.kind === "fixed").reduce((s, a) => s + a.fte, 0),
    );
    const unallocatedFloating = round1(
      peopleWithLoad.filter((p) => p.isFloating).reduce((s, p) => s + Math.max(p.remaining, 0), 0),
    );

    return {
      data,
      rows,
      peopleWithLoad,
      totals: {
        capacity,
        allocated,
        gap: round1(rows.reduce((s, r) => s + Math.max(-r.gap, 0), 0)),
        projects: data.projects.length,
        fixed,
        floating: round1(allocated - fixed),
        unallocatedFloating,
      },
      addPerson: (p) => persist({ ...data, people: [...data.people, { ...p, id: uid() }] }),
      updatePerson: (id, patch) =>
        persist({ ...data, people: data.people.map((p) => (p.id === id ? { ...p, ...patch } : p)) }),
      removePerson: (id) =>
        persist({
          ...data,
          people: data.people.filter((p) => p.id !== id),
          allocations: data.allocations.filter((a) => a.personId !== id),
        }),
      addProject: (p) => persist({ ...data, projects: [...data.projects, { ...p, id: uid() }] }),
      updateProject: (id, patch) =>
        persist({
          ...data,
          projects: data.projects.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        }),
      removeProject: (id) =>
        persist({
          ...data,
          projects: data.projects.filter((p) => p.id !== id),
          allocations: data.allocations.filter((a) => a.projectId !== id),
        }),
      addAllocation: (a) => {
        const person = peopleWithLoad.find((p) => p.id === a.personId);
        if (!person) return "Person not found";
        if (a.fte <= 0) return "Allocation must be greater than 0";
        if (a.fte > person.remaining + 0.001)
          return `${person.name} only has ${person.remaining.toFixed(1)} FTE left`;
        persist({ ...data, allocations: [...data.allocations, { ...a, id: uid() }] });
        return null;
      },
      updateAllocation: (id, patch) =>
        persist({
          ...data,
          allocations: data.allocations.map((a) => (a.id === id ? { ...a, ...patch } : a)),
        }),
      removeAllocation: (id) =>
        persist({ ...data, allocations: data.allocations.filter((a) => a.id !== id) }),
      replaceAll: (next) => persist(next),
      reset: () => persist(SEED_DATA),
    };
  }, [data, persist]);

  return <CapacityContext.Provider value={value}>{children}</CapacityContext.Provider>;
}

export function useCapacity() {
  const ctx = useContext(CapacityContext);
  if (!ctx) throw new Error("useCapacity must be used inside CapacityProvider");
  return ctx;
}
