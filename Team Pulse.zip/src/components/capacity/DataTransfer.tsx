import { useRef, useState } from "react";
import { Download, Upload, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useCapacity } from "@/lib/capacity-store";
import { exportToExcel, importFromExcel } from "@/lib/capacity-excel";

export function DataTransfer() {
  const { data, replaceAll, reset } = useCapacity();
  const inputRef = useRef<HTMLInputElement>(null);
  const [errors, setErrors] = useState<string[]>([]);

  async function handleFile(file: File) {
    setErrors([]);
    try {
      const result = await importFromExcel(file);
      if (result.errors.length || !result.data) {
        setErrors(result.errors);
        toast.error("Upload rejected — nothing was changed");
        return;
      }
      replaceAll(result.data);
      toast.success(
        `Data updated: ${result.data.projects.length} projects, ${result.data.people.length} people`,
      );
    } catch {
      setErrors(["That file could not be read. Please upload an .xlsx workbook."]);
      toast.error("Could not read that file");
    }
  }

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 className="font-display text-lg text-foreground">Excel download &amp; upload</h2>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            The workbook holds detail data only — three sheets: Projects, People and Allocations. Edit it
            offline and upload it back; totals, gaps and status are recalculated automatically and saved in
            this browser.
          </p>

        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => exportToExcel(data)}>
            <Download className="size-4" /> Download Excel
          </Button>
          <Button onClick={() => inputRef.current?.click()}>
            <Upload className="size-4" /> Upload Excel
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              reset();
              setErrors([]);
              toast.success("Reset to sample data");
            }}
          >
            <RotateCcw className="size-4" /> Reset
          </Button>
          <input
            ref={inputRef}
            type="file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void handleFile(file);
              e.target.value = "";
            }}
          />
        </div>
      </div>

      {errors.length > 0 && (
        <div className="mt-4 rounded-lg bg-danger-soft px-4 py-3">
          <p className="text-sm font-semibold text-danger">Upload failed — please fix and try again:</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-danger">
            {errors.slice(0, 12).map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
