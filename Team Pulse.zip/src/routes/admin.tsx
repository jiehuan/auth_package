import { useState } from "react";

import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTransfer } from "@/components/capacity/DataTransfer";
import { useCapacity } from "@/lib/capacity-store";
import {
  PROJECT_ICONS,
  ROLES,
  neededTotal,
  type ImpactLevel,
  type RoleNeed,
} from "@/lib/capacity-types";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Manage Team Capacity Data — Admin" },
      {
        name: "description",
        content:
          "Add or edit projects, people and allocations, and move the full dataset in and out of Excel.",
      },
      { property: "og:title", content: "Manage Team Capacity Data — Admin" },
      {
        property: "og:description",
        content: "Add projects and resources, edit allocations, download and upload Excel.",
      },
    ],
  }),
  component: Admin,
});

const selectClass =
  "h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="font-display text-lg text-foreground">{title}</h3>
      <div className="mt-4">{children}</div>
    </div>
  );
}

function ProjectsTab() {
  const { data, rows, addProject, removeProject, updateProject } = useCapacity();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState(PROJECT_ICONS[0]!);
  const [impact, setImpact] = useState("");
  const [impactLevel, setImpactLevel] = useState<ImpactLevel>("Medium");
  const [roles, setRoles] = useState<RoleNeed[]>([{ role: ROLES[1]!, fte: 1 }]);

  function submit() {
    if (!name.trim()) {
      toast.error("Project name is required");
      return;
    }
    addProject({
      name: name.trim(),
      description: description.trim(),
      icon,
      priority: data.projects.length + 1,
      neededByRole: roles.filter((r) => r.role && r.fte > 0),
      impactIfDelayed: impact.trim(),
      impactLevel,
    });
    setName("");
    setDescription("");
    setImpact("");
    setRoles([{ role: ROLES[1]!, fte: 1 }]);
    toast.success("Project added");
  }

  return (
    <div className="space-y-4">
      <Section title="Add a project">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Project name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Next Gen UW" />
          </div>
          <div className="space-y-1.5">
            <Label>One-line description</Label>
            <Input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Building new underwriting capabilities"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Icon</Label>
            <select className={selectClass} value={icon} onChange={(e) => setIcon(e.target.value)}>
              {PROJECT_ICONS.map((i) => (
                <option key={i} value={i}>
                  {i}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Impact level if delayed</Label>
            <select
              className={selectClass}
              value={impactLevel}
              onChange={(e) => setImpactLevel(e.target.value as ImpactLevel)}
            >
              {(["High", "Medium", "Low"] as const).map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5 md:col-span-2">
            <Label>Impact if delayed</Label>
            <Input
              value={impact}
              onChange={(e) => setImpact(e.target.value)}
              placeholder="Launch slips a full quarter"
            />
          </div>
        </div>

        <div className="mt-5">
          <Label>Resource by role — resource needed</Label>

          <div className="mt-2 space-y-2">
            {roles.map((r, idx) => (
              <div key={idx} className="flex flex-wrap items-center gap-2">
                <select
                  className={`${selectClass} max-w-60`}
                  value={r.role}
                  onChange={(e) =>
                    setRoles(roles.map((x, i) => (i === idx ? { ...x, role: e.target.value } : x)))
                  }
                >
                  {ROLES.map((role) => (
                    <option key={role} value={role}>
                      {role}
                    </option>
                  ))}
                </select>
                <Input
                  className="w-28"
                  type="number"
                  step="0.1"
                  min="0"
                  value={r.fte}
                  onChange={(e) =>
                    setRoles(roles.map((x, i) => (i === idx ? { ...x, fte: Number(e.target.value) } : x)))
                  }
                />
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setRoles(roles.filter((_, i) => i !== idx))}
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            ))}
          </div>
          <Button
            variant="outline"
            size="sm"
            className="mt-2"
            onClick={() => setRoles([...roles, { role: ROLES[0]!, fte: 1 }])}
          >
            <Plus className="size-4" /> Add role
          </Button>
        </div>

        <Button className="mt-5" onClick={submit}>
          Add project
        </Button>
      </Section>

      <Section title={`Projects (${data.projects.length})`}>
        <div className="space-y-3">
          {rows.map(({ project: p, byRole, assigned, gap }) => (
            <div key={p.id} className="rounded-lg border border-border px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-56">
                  <p className="font-semibold text-foreground">{p.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {p.description || "No description"} · needs {neededTotal(p).toFixed(1)} FTE ·{" "}
                    allocated {assigned.toFixed(1)} FTE · gap {gap.toFixed(1)} · {p.impactLevel} impact
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Label className="text-xs text-muted-foreground">Priority</Label>
                  <Input
                    className="w-20"
                    type="number"
                    min="1"
                    value={p.priority}
                    onChange={(e) => updateProject(p.id, { priority: Number(e.target.value) })}
                  />
                  <Button variant="ghost" size="icon" onClick={() => removeProject(p.id)}>
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </div>

              {byRole.length > 0 && (
                <div className="mt-3 overflow-x-auto rounded-md border border-border">
                  <table className="w-full min-w-[36rem] text-sm">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50 text-left text-xs font-semibold text-muted-foreground uppercase">
                        <th className="px-3 py-2">Role</th>
                        <th className="px-3 py-2 text-center">Resource needed</th>
                        <th className="px-3 py-2 text-center">Existing resource</th>
                        <th className="px-3 py-2 text-center">FTE / FTC</th>
                        <th className="px-3 py-2 text-center">Fixed / Floating</th>
                        <th className="px-3 py-2 text-center">Gap</th>
                      </tr>
                    </thead>
                    <tbody>
                      {byRole.map((r) => (
                        <tr key={r.role} className="border-b border-border last:border-0">
                          <td className="px-3 py-2 text-foreground">{r.role}</td>
                          <td className="px-3 py-2 text-center text-foreground">{r.needed.toFixed(1)}</td>
                          <td className="px-3 py-2 text-center text-foreground">{r.existing.toFixed(1)}</td>
                          <td className="px-3 py-2 text-center text-muted-foreground">
                            {r.fte.toFixed(1)} / {r.ftc.toFixed(1)}
                          </td>
                          <td className="px-3 py-2 text-center text-muted-foreground">
                            {r.fixed.toFixed(1)} / {r.floating.toFixed(1)}
                          </td>
                          <td
                            className={`px-3 py-2 text-center font-semibold ${
                              r.gap < 0 ? "text-danger" : "text-success"
                            }`}
                          >
                            {r.gap > 0 ? "+" : ""}
                            {r.gap.toFixed(1)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ))}
        </div>
      </Section>

    </div>
  );
}

function PeopleTab() {
  const { peopleWithLoad, addPerson, removePerson } = useCapacity();
  const [name, setName] = useState("");
  const [role, setRole] = useState(ROLES[1]!);
  const [employmentType, setEmploymentType] = useState<"FTE" | "FTC">("FTE");
  const [capacity, setCapacity] = useState(1);
  const [isFloating, setIsFloating] = useState(true);

  function submit() {
    if (!name.trim()) {
      toast.error("Name is required");
      return;
    }
    addPerson({ name: name.trim(), role, employmentType, capacity, isFloating });
    setName("");
    toast.success("Resource added");
  }

  return (
    <div className="space-y-4">
      <Section title="Add a resource">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sarah Chen" />
          </div>
          <div className="space-y-1.5">
            <Label>Role</Label>
            <select className={selectClass} value={role} onChange={(e) => setRole(e.target.value)}>
              {ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Employment type</Label>
            <select
              className={selectClass}
              value={employmentType}
              onChange={(e) => setEmploymentType(e.target.value as "FTE" | "FTC")}
            >
              <option value="FTE">FTE (permanent)</option>
              <option value="FTC">FTC (contract)</option>
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Capacity (FTE)</Label>
            <Input
              type="number"
              step="0.1"
              min="0"
              value={capacity}
              onChange={(e) => setCapacity(Number(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Resource type</Label>
            <select
              className={selectClass}
              value={isFloating ? "floating" : "fixed"}
              onChange={(e) => setIsFloating(e.target.value === "floating")}
            >
              <option value="floating">Floating (reallocatable)</option>
              <option value="fixed">Fixed to a project</option>
            </select>
          </div>
        </div>
        <Button className="mt-5" onClick={submit}>
          Add resource
        </Button>
      </Section>

      <Section title={`People (${peopleWithLoad.length})`}>
        <div className="space-y-2">
          {peopleWithLoad.map((p) => (
            <div
              key={p.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border px-4 py-3"
            >
              <div>
                <p className="font-semibold text-foreground">
                  {p.name}{" "}
                  <span className="text-xs font-medium text-muted-foreground">
                    {p.employmentType} · {p.isFloating ? "Floating" : "Fixed"}
                  </span>
                </p>
                <p className="text-sm text-muted-foreground">
                  {p.role} · {p.allocated.toFixed(1)} / {p.capacity.toFixed(1)} FTE allocated ·{" "}
                  {p.remaining.toFixed(1)} free
                </p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => removePerson(p.id)}>
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

function AllocationsTab() {
  const { data, peopleWithLoad, addAllocation, removeAllocation } = useCapacity();
  const [personId, setPersonId] = useState(data.people[0]?.id ?? "");
  const [projectId, setProjectId] = useState(data.projects[0]?.id ?? "");
  const [fte, setFte] = useState(0.5);
  const [kind, setKind] = useState<"fixed" | "floating">("floating");

  function submit() {
    const error = addAllocation({ personId, projectId, fte, kind });
    if (error) toast.error(error);
    else toast.success("Allocation added");
  }

  return (
    <div className="space-y-4">
      <Section title="Assign a person to a project">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1.5">
            <Label>Person</Label>
            <select className={selectClass} value={personId} onChange={(e) => setPersonId(e.target.value)}>
              {peopleWithLoad.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.remaining.toFixed(1)} free)
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Project</Label>
            <select className={selectClass} value={projectId} onChange={(e) => setProjectId(e.target.value)}>
              {data.projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Allocated FTE</Label>
            <Input
              type="number"
              step="0.1"
              min="0.1"
              value={fte}
              onChange={(e) => setFte(Number(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Type</Label>
            <select
              className={selectClass}
              value={kind}
              onChange={(e) => setKind(e.target.value as "fixed" | "floating")}
            >
              <option value="floating">Floating (can move)</option>
              <option value="fixed">Fixed to this project</option>
            </select>
          </div>
        </div>
        <Button className="mt-5" onClick={submit}>
          Add allocation
        </Button>
      </Section>

      <Section title={`Allocations (${data.allocations.length})`}>
        <div className="space-y-2">
          {data.allocations.map((a) => (
            <div
              key={a.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border px-4 py-3"
            >
              <p className="text-sm text-foreground">
                <span className="font-semibold">
                  {data.people.find((p) => p.id === a.personId)?.name ?? "Unknown"}
                </span>{" "}
                → {data.projects.find((p) => p.id === a.projectId)?.name ?? "Unknown"} ·{" "}
                {a.fte.toFixed(1)} FTE · {a.kind === "fixed" ? "Fixed" : "Floating"}
              </p>
              <Button variant="ghost" size="icon" onClick={() => removeAllocation(a.id)}>
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

function TotalsStrip() {
  const { totals, data } = useCapacity();
  const cap = (fn: (p: (typeof data.people)[number]) => boolean) =>
    data.people.filter(fn).reduce((s, p) => s + p.capacity, 0);
  const items = [
    { label: "Total capacity", value: `${totals.capacity.toFixed(1)} FTE` },
    { label: "FTE / FTC capacity", value: `${cap((p) => p.employmentType === "FTE").toFixed(1)} / ${cap((p) => p.employmentType === "FTC").toFixed(1)}` },
    { label: "Fixed / floating capacity", value: `${cap((p) => !p.isFloating).toFixed(1)} / ${cap((p) => p.isFloating).toFixed(1)}` },
    { label: "Currently allocated", value: `${totals.allocated.toFixed(1)} FTE` },
    { label: "Capacity gap", value: totals.gap.toFixed(1) },
    { label: "Active work areas", value: String(totals.projects) },
  ];
  return (
    <div className="grid gap-3 rounded-xl border border-border bg-card p-5 sm:grid-cols-3 lg:grid-cols-6">
      {items.map((i) => (
        <div key={i.label}>
          <p className="text-xs font-semibold text-muted-foreground uppercase">{i.label}</p>
          <p className="mt-1 font-display text-xl text-foreground">{i.value}</p>
        </div>
      ))}
    </div>
  );
}

function Admin() {
  return (
    <main className="min-h-screen bg-surface px-4 py-8 md:px-10 md:py-12">
      <div className="mx-auto max-w-6xl">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" /> Back to dashboard
        </Link>
        <h1 className="mt-4 font-display text-3xl tracking-tight text-foreground">Manage capacity data</h1>
        <p className="mt-2 text-muted-foreground">
          Everything entered here rolls straight up into "AI Team Capacity — At a Glance". All changes are
          stored in this browser.
        </p>

        <div className="mt-6">
          <TotalsStrip />
        </div>

        <div className="mt-4">
          <DataTransfer />
        </div>


        <Tabs defaultValue="projects" className="mt-6">
          <TabsList>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="people">People</TabsTrigger>
            <TabsTrigger value="allocations">Allocations</TabsTrigger>
          </TabsList>
          <TabsContent value="projects" className="mt-4">
            <ProjectsTab />
          </TabsContent>
          <TabsContent value="people" className="mt-4">
            <PeopleTab />
          </TabsContent>
          <TabsContent value="allocations" className="mt-4">
            <AllocationsTab />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  );
}
