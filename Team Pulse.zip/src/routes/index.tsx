import { createFileRoute, Link } from "@tanstack/react-router";
import { CircleDashed, Briefcase, Users, LayoutGrid, Info, Settings } from "lucide-react";
import { ProjectIcon } from "@/components/capacity/icons";
import { useCapacity } from "@/lib/capacity-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI Team Capacity — At a Glance" },
      {
        name: "description",
        content:
          "Executive snapshot of AI team capacity: people available, work in progress, role gaps and the impact of delay.",
      },
      { property: "og:title", content: "AI Team Capacity — At a Glance" },
      {
        property: "og:description",
        content: "Executive snapshot of people, work in progress and the capacity gap.",
      },
    ],
  }),
  component: Dashboard,
});

const fmt = (n: number) => n.toFixed(1);

function Kpi({
  label,
  value,
  unit,
  caption,
  tone,
  icon: Icon,
}: {
  label: string;
  value: string;
  unit?: string;
  caption: string;
  tone: "info" | "success" | "warning" | "violet";
  icon: typeof Users;
}) {
  const tones = {
    info: "bg-info-soft text-info",
    success: "bg-success-soft text-success",
    warning: "bg-warning-soft text-warning",
    violet: "bg-accent text-accent-foreground",
  } as const;
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-start gap-4">
        <div className={cn("flex size-11 shrink-0 items-center justify-center rounded-xl", tones[tone])}>
          <Icon className="size-5" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground">{label}</p>
          <p className="mt-1 flex items-baseline gap-1.5">
            <span className={cn("font-display text-3xl leading-none", tones[tone].split(" ")[1])}>{value}</span>
            {unit ? <span className="text-sm text-muted-foreground">{unit}</span> : null}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">{caption}</p>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: "On Track" | "At Risk" | "Gap" }) {
  const tone =
    status === "On Track"
      ? "bg-success-soft text-success"
      : status === "At Risk"
        ? "bg-warning-soft text-warning"
        : "bg-danger-soft text-danger";
  return (
    <span className={cn("inline-flex rounded-md px-2.5 py-1 text-xs font-semibold", tone)}>{status}</span>
  );
}

function Dashboard() {
  const { rows, totals, peopleWithLoad, data } = useCapacity();
  const free = peopleWithLoad.filter((p) => p.isFloating && p.remaining > 0);
  const asOf = new Date(`${data.asOf}T00:00:00`).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  return (
    <main className="min-h-screen bg-surface px-4 py-8 md:px-10 md:py-12">
      <div className="mx-auto max-w-7xl">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl tracking-tight text-foreground md:text-4xl">
              AI Team Capacity — At a Glance
            </h1>
            <p className="mt-2 text-muted-foreground">
              Snapshot of people, work in progress, and capacity gap
            </p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">As of {asOf}</span>
            <Link
              to="/admin"
              className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
            >
              <Settings className="size-4" /> Manage data
            </Link>
          </div>
        </header>

        <section className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Kpi
            label="Total Capacity"
            value={fmt(totals.capacity)}
            unit="FTE"
            caption="People available"
            tone="info"
            icon={Users}
          />
          <Kpi
            label="Currently Allocated"
            value={fmt(totals.allocated)}
            unit="FTE"
            caption="Working on current work"
            tone="success"
            icon={Briefcase}
          />
          <Kpi
            label="Capacity Gap"
            value={fmt(totals.gap)}
            caption="Additional capacity needed"
            tone="warning"
            icon={CircleDashed}
          />
          <Kpi
            label="Active Work Areas"
            value={String(totals.projects)}
            caption="Projects / initiatives"
            tone="violet"
            icon={LayoutGrid}
          />
        </section>

        <section className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-border bg-card px-5 py-4">
            <p className="text-sm font-semibold text-foreground">Fixed on projects</p>
            <p className="mt-1 text-sm text-muted-foreground">
              <span className="font-display text-xl text-foreground">{fmt(totals.fixed)} FTE</span> locked to
              specific work
            </p>
          </div>
          <div className="rounded-xl border border-border bg-card px-5 py-4">
            <p className="text-sm font-semibold text-foreground">Floating / reallocatable</p>
            <p className="mt-1 text-sm text-muted-foreground">
              <span className="font-display text-xl text-foreground">{fmt(totals.floating)} FTE</span> assigned
              but movable · {fmt(totals.unallocatedFloating)} FTE not yet assigned
            </p>
          </div>
        </section>

        <section className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[62rem] text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  <th className="px-5 py-4">What we are working on</th>
                  <th className="px-4 py-4 text-center">Resource Allocated</th>
                  <th className="px-4 py-4">Project Needs Snapshot</th>
                  <th className="px-4 py-4 text-center">Gap</th>
                  <th className="px-4 py-4 text-center">Status</th>
                  <th className="px-5 py-4">Impact if Delayed</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.project.id} className="border-b border-border last:border-0 align-top">
                    <td className="px-5 py-4">
                      <div className="flex items-start gap-3">
                        <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
                          <ProjectIcon name={row.project.icon} className="size-4" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">{row.project.name}</p>
                          <p className="text-muted-foreground">{row.project.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-center">
                      <p className="font-display text-lg text-foreground">{fmt(row.assigned)}</p>
                      <p className="text-xs text-muted-foreground">
                        {row.headcount} {row.headcount === 1 ? "person" : "people"} · {row.fteCount} FTE ·{" "}
                        {row.ftcCount} FTC
                      </p>
                    </td>
                    <td className="px-4 py-4">
                      <ul className="space-y-1">
                        {row.project.neededByRole.map((need) => (
                          <li key={need.role} className="text-muted-foreground">
                            <span className="font-medium text-foreground">{fmt(need.fte)}</span> {need.role}
                          </li>
                        ))}
                      </ul>
                    </td>
                    <td
                      className={cn(
                        "px-4 py-4 text-center font-display text-lg",
                        row.gap < 0 ? "text-danger" : "text-success",
                      )}
                    >
                      {row.gap > 0 ? "+" : ""}
                      {fmt(row.gap)}
                    </td>
                    <td className="px-4 py-4 text-center">
                      <StatusBadge status={row.status} />
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className={cn(
                          "mb-1 inline-flex rounded-md px-2 py-0.5 text-xs font-semibold",
                          row.project.impactLevel === "High"
                            ? "bg-danger-soft text-danger"
                            : row.project.impactLevel === "Medium"
                              ? "bg-warning-soft text-warning"
                              : "bg-secondary text-secondary-foreground",
                        )}
                      >
                        {row.project.impactLevel}
                      </span>
                      <p className="text-muted-foreground">{row.project.impactIfDelayed}</p>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mt-4 flex items-start gap-3 rounded-xl bg-info-soft px-5 py-4">
          <Info className="mt-0.5 size-5 shrink-0 text-info" />
          <p className="text-sm text-foreground">
            To close the gap of {fmt(totals.gap)} FTE, we can reallocate from lower priority work, reduce
            scope, or add capacity.
          </p>
        </section>

        {free.length > 0 && (
          <section className="mt-4 rounded-xl border border-border bg-card px-5 py-4">
            <p className="text-sm font-semibold text-foreground">Floating people with capacity left</p>
            <ul className="mt-2 flex flex-wrap gap-2">
              {free.map((p) => (
                <li
                  key={p.id}
                  className="rounded-md bg-secondary px-2.5 py-1 text-sm text-secondary-foreground"
                >
                  {p.name} · {p.role} · {fmt(p.remaining)} FTE free
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>
    </main>
  );
}
