// Dev:  `npm run dev` serves the SPA on :5173 and proxies /api to the backend
//       (http://localhost:8080, override with API_PROXY_TARGET).
// Prod: `npm run build` emits dist/, served by server.mjs, which also proxies /api.
import path from "node:path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { tanstackRouter } from "@tanstack/router-plugin/vite";

export default defineConfig({
  plugins: [
    // Must come before react(): generates src/routeTree.gen.ts from src/routes.
    tanstackRouter({ target: "react", autoCodeSplitting: true }),
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: { "@": path.resolve(import.meta.dirname, "src") },
  },
  server: {
    port: 5173,
    proxy: {
      "/api": { target: process.env["API_PROXY_TARGET"] ?? "http://localhost:8080" },
    },
  },
  build: {
    chunkSizeWarningLimit: 900,
  },
});
