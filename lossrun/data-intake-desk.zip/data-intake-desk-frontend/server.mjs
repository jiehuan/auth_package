// Production server for the SPA. No dependencies: Node built-ins only.
//
//   /healthz   liveness/readiness for OpenShift probes (does not touch the backend)
//   /api/*     reverse-proxied to BACKEND_URL (the internal backend Service), streamed both ways
//   /assets/*  hashed build output, cached for a year
//   anything   else: a file from dist/ if it exists, otherwise index.html (client-side routing)
//
// Env: PORT (8080), BACKEND_URL (http://data-intake-desk-backend:8080), PROXY_TIMEOUT_MS (180000)

import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const PORT = Number(process.env.PORT || 8080);
const BACKEND = new URL(process.env.BACKEND_URL || "http://data-intake-desk-backend:8080");
const PROXY_TIMEOUT_MS = Number(process.env.PROXY_TIMEOUT_MS || 180_000);
const DIST = path.join(path.dirname(fileURLToPath(import.meta.url)), "dist");
const INDEX = path.join(DIST, "index.html");

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
  ".map": "application/json; charset=utf-8",
};

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "same-origin",
};

// Hop-by-hop headers must not be forwarded by a proxy (RFC 9110 §7.6.1).
const HOP_BY_HOP = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
]);

if (!fs.existsSync(INDEX)) {
  console.error(`dist/index.html not found in ${DIST}; run "npm run build" first`);
  process.exit(1);
}

const log = (msg) => console.log(`${new Date().toISOString()} ${msg}`);

function sendJson(res, status, body) {
  if (res.headersSent) return res.destroy();
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
    ...SECURITY_HEADERS,
  });
  res.end(JSON.stringify(body));
}

function proxy(req, res) {
  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (!HOP_BY_HOP.has(k.toLowerCase())) headers[k] = v;
  }
  const prior = req.headers["x-forwarded-for"];
  const client = req.socket.remoteAddress || "";
  headers["x-forwarded-for"] = prior ? `${prior}, ${client}` : client;
  headers["x-forwarded-proto"] = req.headers["x-forwarded-proto"] || "http";
  headers["x-forwarded-host"] = req.headers["x-forwarded-host"] || req.headers.host || "";
  headers.host = BACKEND.host;

  const transport = BACKEND.protocol === "https:" ? https : http;
  const upstream = transport.request(
    {
      protocol: BACKEND.protocol,
      hostname: BACKEND.hostname,
      port: BACKEND.port || (BACKEND.protocol === "https:" ? 443 : 80),
      method: req.method,
      path: req.url,
      headers,
      timeout: PROXY_TIMEOUT_MS,
    },
    (up) => {
      const out = {};
      for (const [k, v] of Object.entries(up.headers)) {
        if (!HOP_BY_HOP.has(k.toLowerCase())) out[k] = v;
      }
      res.writeHead(up.statusCode || 502, out);
      up.pipe(res);
      up.on("error", () => res.destroy());
    },
  );

  upstream.on("timeout", () => upstream.destroy(new Error("upstream timeout")));
  upstream.on("error", (err) => {
    log(`proxy error ${req.method} ${req.url}: ${err.message}`);
    sendJson(res, err.message === "upstream timeout" ? 504 : 502, {
      detail: "The service is not reachable right now. Please try again shortly.",
    });
  });
  req.on("aborted", () => upstream.destroy());
  req.pipe(upstream);
}

function resolveStatic(urlPath) {
  let decoded;
  try {
    decoded = decodeURIComponent(urlPath);
  } catch {
    return null;
  }
  if (decoded.includes("\0")) return null;
  const file = path.normalize(path.join(DIST, decoded));
  if (file !== DIST && !file.startsWith(DIST + path.sep)) return null; // path traversal
  try {
    const st = fs.statSync(file);
    return st.isFile() ? { file, size: st.size } : null;
  } catch {
    return null;
  }
}

function serveFile(req, res, file, size, cacheControl) {
  res.writeHead(200, {
    "Content-Type": TYPES[path.extname(file).toLowerCase()] || "application/octet-stream",
    "Content-Length": size,
    "Cache-Control": cacheControl,
    ...SECURITY_HEADERS,
  });
  if (req.method === "HEAD") return res.end();
  fs.createReadStream(file)
    .on("error", () => res.destroy())
    .pipe(res);
}

const server = http.createServer((req, res) => {
  const urlPath = (req.url || "/").split("?")[0];

  if (urlPath === "/healthz") return sendJson(res, 200, { status: "ok" });
  if (urlPath === "/api" || urlPath.startsWith("/api/")) return proxy(req, res);

  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405, { Allow: "GET, HEAD", ...SECURITY_HEADERS });
    return res.end();
  }

  const hit = urlPath !== "/" && resolveStatic(urlPath);
  if (hit) {
    const immutable = urlPath.startsWith("/assets/");
    return serveFile(
      req,
      res,
      hit.file,
      hit.size,
      immutable ? "public, max-age=31536000, immutable" : "no-cache",
    );
  }
  // Missing hashed assets must 404 (not index.html), or the browser reports a MIME error.
  if (urlPath.startsWith("/assets/")) {
    res.writeHead(404, { "Content-Type": "text/plain", ...SECURITY_HEADERS });
    return res.end("Not found");
  }
  serveFile(req, res, INDEX, fs.statSync(INDEX).size, "no-cache");
});

server.requestTimeout = 0; // large uploads are streamed to the backend; PROXY_TIMEOUT_MS bounds them
server.headersTimeout = 60_000;
server.keepAliveTimeout = 65_000;

server.listen(PORT, () => log(`listening on :${PORT}, proxying /api to ${BACKEND.origin}`));

function shutdown(signal) {
  log(`${signal} received, shutting down`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 10_000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
