import { describe, expect, it } from "vitest";
import {
  annualBenefit,
  expectedDays,
  isValidAccuracy,
  priorityScore,
  suggestMeeting,
} from "./priority";

// Must stay in line with the backend (intakedesk/priority.py, tests/test_priority.py).
describe("business impact rules", () => {
  it("efficiency benefit = person days × cost per day", () => {
    expect(annualBenefit({ impact_type: "efficiency", person_days: 400, cost_per_day: 300 })).toBe(
      120000,
    );
  });
  it("profitability values loss-ratio points on the LOB premium base", () => {
    expect(
      annualBenefit({ impact_type: "profitability", loss_ratio_impact: 1.5, lob: "Marine" }),
    ).toBe(300000);
    expect(annualBenefit({ impact_type: "profitability", loss_ratio_impact: 1, lob: "" })).toBe(
      100000,
    );
  });
  it("100% accuracy is not an option", () => {
    expect(isValidAccuracy(100)).toBe(false);
    expect(isValidAccuracy(99.5)).toBe(true);
  });
  it("priority is a log scale", () => {
    expect(priorityScore(10_000)).toBe(20);
    expect(priorityScore(1_000_000)).toBe(60);
  });
  it("return window stays between 1 day and 2 weeks", () => {
    expect(expectedDays("easy", 100, 80)).toBe(1);
    expect(expectedDays("hard", 0, 99)).toBe(14);
  });
  it("hard cases suggest a meeting with an AI engineer", () => {
    expect(suggestMeeting("hard", 90)).toBe(true);
    expect(suggestMeeting("easy", 90)).toBe(false);
  });
});
