// Business impact → benefit, priority and expected return window.
// The backend (intakedesk/priority.py) computes the stored values; this copy is used for live
// display (benefit estimate while filling in the form, benefit per case in lists and charts).
export type ImpactType = "growth" | "efficiency" | "profitability";
export type Complexity = "easy" | "medium" | "hard";

// Assumed annual earned premium per line of business (USD), used to value loss-ratio points.
export const LOB_PREMIUM_BASE: Record<string, number> = {
  Property: 50_000_000,
  Motor: 80_000_000,
  Marine: 20_000_000,
  Casualty: 40_000_000,
  Health: 60_000_000,
  Life: 70_000_000,
  Other: 10_000_000,
};
export const LOBS = Object.keys(LOB_PREMIUM_BASE);
// Share of top-line premium counted as benefit for growth cases.
export const GROWTH_MARGIN = 0.1;

export interface ImpactInput {
  impact_type: ImpactType | string;
  premium_growth?: number;
  person_days?: number;
  cost_per_day?: number;
  loss_ratio_impact?: number; // percentage points improvement
  lob?: string;
}

export function annualBenefit(i: ImpactInput): number {
  if (i.impact_type === "growth") return (i.premium_growth ?? 0) * GROWTH_MARGIN;
  if (i.impact_type === "efficiency") return (i.person_days ?? 0) * (i.cost_per_day ?? 0);
  const base = LOB_PREMIUM_BASE[i.lob ?? "Other"] ?? LOB_PREMIUM_BASE["Other"] ?? 0;
  return ((i.loss_ratio_impact ?? 0) / 100) * base;
}

export function isValidAccuracy(a: number): boolean {
  return Number.isFinite(a) && a > 0 && a < 100;
}

/** 0–100 score: higher benefit → higher priority. */
export function priorityScore(benefit: number): number {
  if (benefit <= 0) return 0;
  // log scale: $10k → ~20, $100k → ~40, $1M → ~60, $10M → ~80
  return Math.max(0, Math.min(100, Math.round((Math.log10(benefit) - 3) * 20)));
}

/** Expected return window in days: 1 day minimum, 14 days maximum. */
export function expectedDays(complexity: Complexity, score: number, accuracy: number): number {
  const base = complexity === "easy" ? 2 : complexity === "medium" ? 6 : 12;
  let d = base - Math.floor(score / 25); // high priority jumps the queue
  if (accuracy >= 97) d += 2;
  return Math.max(1, Math.min(14, d));
}

export function suggestMeeting(complexity: Complexity, accuracy: number): boolean {
  return complexity === "hard" || accuracy >= 98;
}

export function formatUsd(n: number): string {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M`;
  if (n >= 1_000) return `$${Math.round(n / 1_000)}k`;
  return `$${Math.round(n)}`;
}

/** Plain-language basis for the benefit figure. */
export function benefitBasis(i: ImpactInput): string {
  if (i.impact_type === "growth")
    return `Growth: ${formatUsd(i.premium_growth ?? 0)} new premium × ${GROWTH_MARGIN * 100}% margin`;
  if (i.impact_type === "efficiency")
    return `Efficiency: ${i.person_days ?? 0} person-days × ${formatUsd(i.cost_per_day ?? 0)}/day`;
  return `Profitability: ${i.loss_ratio_impact ?? 0} pt loss-ratio improvement on ${i.lob ?? "Other"}`;
}
