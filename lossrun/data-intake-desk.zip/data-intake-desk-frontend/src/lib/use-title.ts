import { useEffect } from "react";

const APP = "Data Intake Desk";

export function useTitle(page?: string) {
  useEffect(() => {
    document.title = page ? `${page} · ${APP}` : APP;
  }, [page]);
}
