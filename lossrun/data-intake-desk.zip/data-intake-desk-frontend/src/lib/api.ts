// Typed client for the Data Intake Desk backend. Every call goes to the same origin under /api
// (proxied by server.mjs in production and by Vite in development), authenticated by the
// httpOnly session cookie.

export type Role = "user" | "admin";
export type Complexity = "easy" | "medium" | "hard";
export type ImpactType = "growth" | "efficiency" | "profitability";

export interface User {
  username: string;
  role: Role;
}

export interface IntakeCase {
  id: string;
  title: string;
  description: string;
  data_elements: string;
  analysis_mode: "immediate" | "fast";
  ai_questions: string[];
  user_examples: string;
  impact_type: ImpactType;
  premium_growth: number;
  person_days: number;
  cost_per_day: number;
  loss_ratio_impact: number;
  lob: string;
  expected_accuracy: number;
  complexity: Complexity;
  priority_score: number;
  expected_days: number;
  meeting_suggested: boolean;
  status: string;
  result_text: string;
  satisfaction: number | null;
  created_by: string;
  created_at: string;
  completed_at: string | null;
}

export interface CaseFile {
  id: string;
  case_id: string;
  file_name: string;
  content_type: string;
  size_bytes: number;
  created_at: string;
  url: string;
}

export interface Feedback {
  id: string;
  case_id: string;
  comment: string;
  wants_engineer: boolean;
  difficulty: "easy" | "hard";
  bot_reply: string;
  eta_hours: number | null;
  created_at: string;
}

export interface CaseDetail {
  case: IntakeCase;
  files: CaseFile[];
  feedback: Feedback[];
}

export interface SampleScan {
  summary: string;
  complexity: Complexity;
  questions: string[];
}

export interface NewCase {
  title: string;
  description: string;
  data_elements: string;
  analysis_mode: "immediate" | "fast";
  ai_questions: string[];
  user_examples: string;
  ai_complexity: Complexity | null;
  impact_type: ImpactType;
  premium_growth: number;
  person_days: number;
  cost_per_day: number;
  loss_ratio_impact: number;
  lob: string;
  expected_accuracy: number;
}

export interface CreatedCase {
  id: string;
  complexity: Complexity;
  expected_days: number;
  meeting_suggested: boolean;
  priority_score: number;
}

export interface ReturnResult {
  difficulty: "easy" | "hard";
  reply: string;
  eta_hours: number | null;
}

export interface AdminOverview {
  cases: IntakeCase[];
  feedback: Feedback[];
}

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

type Body = { json: unknown } | { form: FormData } | undefined;

function errorMessage(status: number, payload: unknown): string {
  const detail = (payload as { detail?: unknown } | null)?.detail;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    const msgs = detail.map((d) => (d as { msg?: string }).msg).filter(Boolean);
    if (msgs.length) return msgs.join("; ");
  }
  if (status === 502 || status === 503 || status === 504)
    return "The service is not reachable right now. Please try again shortly.";
  if (status === 413) return "The upload is too large.";
  return `Request failed (${status}).`;
}

async function request<T>(method: string, path: string, body?: Body): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  let payload: BodyInit | undefined;
  if (method !== "GET") headers["X-Requested-With"] = "XMLHttpRequest"; // required by the backend CSRF guard
  if (body && "json" in body) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body.json);
  } else if (body && "form" in body) {
    payload = body.form; // the browser sets the multipart boundary
  }

  let res: Response;
  try {
    res = await fetch(path, { method, headers, body: payload ?? null, credentials: "same-origin" });
  } catch {
    throw new ApiError("Can't reach the server. Check your connection and try again.", 0);
  }

  const data: unknown = res.headers.get("content-type")?.includes("application/json")
    ? await res.json().catch(() => null)
    : null;

  if (!res.ok) {
    if (res.status === 401 && !path.startsWith("/api/auth/")) {
      // Session expired: back to the sign-in page (full reload drops cached data).
      window.location.assign("/");
    }
    throw new ApiError(errorMessage(res.status, data), res.status);
  }
  return data as T;
}

export const api = {
  me: async (): Promise<User | null> =>
    (await request<{ user: User | null }>("GET", "/api/auth/me")).user,
  login: (username: string, password: string) =>
    request<User>("POST", "/api/auth/login", { json: { username, password } }),
  logout: () => request<{ ok: boolean }>("POST", "/api/auth/logout"),

  listCases: () => request<IntakeCase[]>("GET", "/api/cases"),
  getCase: (id: string) => request<CaseDetail>("GET", `/api/cases/${encodeURIComponent(id)}`),

  analyzeSample: (description: string, dataElements: string, file: File) => {
    const form = new FormData();
    form.append("description", description);
    form.append("data_elements", dataElements);
    form.append("file", file);
    return request<SampleScan>("POST", "/api/cases/analyze-sample", { form });
  },
  createCase: (data: NewCase, files: File[]) => {
    const form = new FormData();
    form.append("payload", JSON.stringify(data));
    for (const f of files) form.append("files", f);
    return request<CreatedCase>("POST", "/api/cases", { form });
  },
  returnCase: (id: string, comment: string, wantsEngineer: boolean) =>
    request<ReturnResult>("POST", `/api/cases/${encodeURIComponent(id)}/return`, {
      json: { comment, wants_engineer: wantsEngineer },
    }),
  rateCase: (id: string, satisfaction: number) =>
    request<{ ok: boolean }>("POST", `/api/cases/${encodeURIComponent(id)}/rating`, {
      json: { satisfaction },
    }),

  adminOverview: () => request<AdminOverview>("GET", "/api/admin/overview"),
  completeCase: (id: string, resultText: string) =>
    request<{ ok: boolean }>("POST", `/api/admin/cases/${encodeURIComponent(id)}/complete`, {
      json: { result_text: resultText },
    }),
};
