import { queryOptions, type QueryClient } from "@tanstack/react-query";
import { redirect } from "@tanstack/react-router";
import { api, type Role, type User } from "./api";

export const meQuery = queryOptions({
  queryKey: ["me"],
  queryFn: api.me,
  staleTime: 60_000,
});

export const homeFor = (role: Role) => (role === "admin" ? "/admin" : "/home");

/** Route guard for beforeLoad: signed in with the given role, else redirect. */
export async function requireRole(queryClient: QueryClient, role: Role): Promise<{ me: User }> {
  const me = await queryClient.ensureQueryData(meQuery);
  if (!me) throw redirect({ to: "/" });
  if (me.role !== role) throw redirect({ to: homeFor(me.role) });
  return { me };
}
