import { annualBenefit, benefitBasis, formatUsd } from "@/lib/priority";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Download, Loader2, Star, Undo2 } from "lucide-react";
import { AppShell, BotBubble, statusLabel } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { api } from "@/lib/api";
import { requireRole } from "@/lib/session";
import { useTitle } from "@/lib/use-title";

export const Route = createFileRoute("/cases/$id")({
  beforeLoad: ({ context }) => requireRole(context.queryClient, "user"),
  component: CaseView,
});

function CaseView() {
  const { me } = Route.useRouteContext();
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const { data, error } = useQuery({ queryKey: ["case", id], queryFn: () => api.getCase(id) });
  const [returning, setReturning] = useState(false);
  const [comment, setComment] = useState("");
  const [engineer, setEngineer] = useState(false);
  const [busy, setBusy] = useState(false);
  useTitle(data?.case.title ?? "Intake case");
  if (error)
    return (
      <AppShell user={me}>
        <p className="text-sm text-destructive">{error.message}</p>
      </AppShell>
    );
  if (!data)
    return (
      <AppShell user={me}>
        <Loader2 className="animate-spin" />
      </AppShell>
    );
  const c = data.case;

  function download() {
    const blob = new Blob([c.result_text], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${c.title.replace(/[^\w]+/g, "_")}_intake_result.txt`;
    a.click();
  }

  return (
    <AppShell user={me}>
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="font-display text-2xl font-bold">{c.title}</h1>
              <p className="text-sm text-muted-foreground">{c.description}</p>
            </div>
            <Badge>{statusLabel[c.status] ?? c.status}</Badge>
          </div>
          <section className="rounded-xl border bg-card p-6">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display font-bold">Intake result</h2>
              {c.result_text && (
                <Button size="sm" variant="outline" onClick={download}>
                  <Download className="mr-1 h-4 w-4" />
                  Download
                </Button>
              )}
            </div>
            {c.result_text ? (
              <pre className="whitespace-pre-wrap rounded-md bg-muted p-4 font-sans text-sm">
                {c.result_text}
              </pre>
            ) : (
              <p className="text-sm text-muted-foreground">
                Not ready yet — expected within {c.expected_days} day(s) of submission.
              </p>
            )}
          </section>

          {c.result_text && (
            <section className="space-y-3 rounded-xl border bg-card p-6">
              <h2 className="font-display font-bold">How satisfied are you?</h2>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    aria-label={`${n} stars`}
                    onClick={async () => {
                      try {
                        await api.rateCase(id, n);
                        qc.invalidateQueries();
                        toast.success("Thanks for your rating");
                      } catch (e) {
                        toast.error((e as Error).message);
                      }
                    }}
                  >
                    <Star
                      className={`h-6 w-6 ${(c.satisfaction ?? 0) >= n ? "fill-accent text-accent" : "text-muted-foreground"}`}
                    />
                  </button>
                ))}
              </div>
              {!returning ? (
                <Button variant="outline" onClick={() => setReturning(true)}>
                  <Undo2 className="mr-1 h-4 w-4" />
                  Not happy? Return case
                </Button>
              ) : (
                <div className="space-y-3">
                  <Textarea
                    placeholder="What should be changed?"
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                  />
                  <label className="flex items-center gap-2 text-sm">
                    <Checkbox checked={engineer} onCheckedChange={(v) => setEngineer(v === true)} />
                    I'd like to talk to an AI engineer
                  </label>
                  <Button
                    disabled={busy || !comment.trim()}
                    onClick={async () => {
                      setBusy(true);
                      try {
                        await api.returnCase(id, comment, engineer);
                        setComment("");
                        setReturning(false);
                        qc.invalidateQueries();
                      } catch (e) {
                        toast.error((e as Error).message);
                      }
                      setBusy(false);
                    }}
                  >
                    {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Send back
                  </Button>
                </div>
              )}
            </section>
          )}

          {data.feedback.map((f) => (
            <div key={f.id} className="space-y-3">
              <div className="ml-auto max-w-lg rounded-2xl rounded-tr-sm bg-primary px-4 py-3 text-sm text-primary-foreground">
                {f.comment}
              </div>
              <BotBubble>
                <p>{f.bot_reply}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {f.difficulty === "easy"
                    ? `Quick fix · ETA ${f.eta_hours}h · you'll be notified here when it's ready`
                    : "Escalated to the AI team"}
                </p>
              </BotBubble>
            </div>
          ))}
        </div>
        <aside className="space-y-4">
          <div className="rounded-xl border bg-card p-5 text-sm">
            <h3 className="mb-2 font-display font-bold">Uploaded files</h3>
            {data.files.length === 0 && <p className="text-muted-foreground">None</p>}
            {data.files.map((f) => (
              <a key={f.id} href={f.url} className="block truncate text-primary underline">
                {f.file_name}
              </a>
            ))}
          </div>
          <div className="space-y-1 rounded-xl border bg-card p-5 text-sm">
            <h3 className="mb-2 font-display font-bold">Details</h3>
            <p>
              <span className="text-muted-foreground">Capture:</span> {c.data_elements}
            </p>
            <p>
              <span className="text-muted-foreground">Impact:</span> {c.impact_type}
            </p>
            <p>
              <span className="text-muted-foreground">Accuracy target:</span> {c.expected_accuracy}%
            </p>
            <p>
              <span className="text-muted-foreground">Target benefit:</span>{" "}
              <b className="text-accent">{formatUsd(annualBenefit(c))}/yr</b>
            </p>
            <p className="text-xs text-muted-foreground">{benefitBasis(c)}</p>
          </div>
        </aside>
      </div>
    </AppShell>
  );
}
