import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Upload, Zap, ScanSearch } from "lucide-react";
import { AppShell, BotBubble } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, type Complexity, type CreatedCase, type SampleScan } from "@/lib/api";
import { requireRole } from "@/lib/session";
import { useTitle } from "@/lib/use-title";
import { LOBS, annualBenefit, isValidAccuracy, type ImpactType } from "@/lib/priority";

export const Route = createFileRoute("/new")({
  beforeLoad: ({ context }) => requireRole(context.queryClient, "user"),
  component: NewCase,
});

const MAX_FILES = 5;
const MAX_FILE_MB = 20;
const money = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(n);

function NewCase() {
  const { me } = Route.useRouteContext();
  const nav = useNavigate();
  const qc = useQueryClient();
  useTitle("New intake case");
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState<File[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [elements, setElements] = useState("");
  const [mode, setMode] = useState<"immediate" | "fast" | null>(null);
  const [scan, setScan] = useState<SampleScan | null>(null);
  const [answers, setAnswers] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [impact, setImpact] = useState<ImpactType>("growth");
  const [premium, setPremium] = useState(0);
  const [days, setDays] = useState(0);
  const [cost, setCost] = useState(0);
  const [lr, setLr] = useState(0);
  const [lob, setLob] = useState("Property");
  const [accuracy, setAccuracy] = useState(95);
  const [result, setResult] = useState<CreatedCase | null>(null);

  const benefit = annualBenefit({
    impact_type: impact,
    premium_growth: premium,
    person_days: days,
    cost_per_day: cost,
    loss_ratio_impact: lr,
    lob,
  });

  async function runScan() {
    setMode("immediate");
    setBusy(true);
    try {
      const r = await api.analyzeSample(`${title}\n${description}`, elements, files[0]!);
      setScan(r);
      setAnswers(r.questions.map(() => ""));
    } catch (e) {
      toast.error((e as Error).message);
      setMode(null);
    }
    setBusy(false);
  }

  async function submit() {
    if (!isValidAccuracy(accuracy)) {
      toast.error("Expected accuracy must be below 100% — 100% is not an option.");
      return;
    }
    setBusy(true);
    try {
      const r = await api.createCase(
        {
          title,
          description,
          data_elements: elements,
          analysis_mode: mode ?? "fast",
          ai_questions: scan?.questions ?? [],
          user_examples: (scan?.questions ?? [])
            .map((q, i) => `Q: ${q}\nA: ${answers[i] ?? ""}`)
            .join("\n\n"),
          ai_complexity: (scan?.complexity ?? null) as Complexity | null,
          impact_type: impact,
          premium_growth: premium,
          person_days: days,
          cost_per_day: cost,
          loss_ratio_impact: lr,
          lob: impact === "profitability" ? lob : "",
          expected_accuracy: accuracy,
        },
        files,
      );
      setResult(r);
      qc.invalidateQueries({ queryKey: ["cases"] });
    } catch (e) {
      toast.error((e as Error).message);
    }
    setBusy(false);
  }

  const step1Ok = files.length > 0 && title.trim() && elements.trim();
  return (
    <AppShell user={me}>
      <div className="mx-auto max-w-3xl space-y-6">
        <BotBubble>
          Let's set up a new intake case. First, upload one or more sample files and tell me what
          needs to be captured.
        </BotBubble>
        <section className="space-y-4 rounded-xl border bg-card p-6">
          <h2 className="font-display text-lg font-bold">1 · Sample files & description</h2>
          <label className="flex cursor-pointer flex-col items-center gap-2 rounded-lg border-2 border-dashed p-6 text-sm text-muted-foreground hover:border-primary">
            <Upload className="h-6 w-6" />
            {files.length
              ? files.map((f) => f.name).join(", ")
              : "Click to upload sample files (PDF, image, text — max 5, 20MB each)"}
            <input
              type="file"
              multiple
              className="hidden"
              accept=".pdf,.png,.jpg,.jpeg,.txt,.csv,.json,.md"
              onChange={(e) => {
                const list = Array.from(e.target.files ?? []).slice(0, MAX_FILES);
                if (list.some((f) => f.size > MAX_FILE_MB * 1024 * 1024)) {
                  toast.error(`Each file must be under ${MAX_FILE_MB}MB.`);
                  return;
                }
                setFiles(list);
              }}
            />
          </label>
          <div className="space-y-2">
            <Label>Case name</Label>
            <Input
              placeholder="e.g. Property policy – Terms & Conditions"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label>What are these documents?</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Document type, source, typical layout…"
            />
          </div>
          <div className="space-y-2">
            <Label>Data elements to capture</Label>
            <Textarea
              value={elements}
              onChange={(e) => setElements(e.target.value)}
              placeholder="Policy number, insured name, effective date, exclusions, deductible…"
            />
          </div>
          {step === 1 && (
            <Button disabled={!step1Ok} onClick={() => setStep(2)}>
              Continue
            </Button>
          )}
        </section>

        {step >= 2 && (
          <>
            <BotBubble>
              Would you like me to <b>analyze a sample now</b>? I'll scan it and ask for examples of
              anything unclear. Or take the <b>fast path</b> — if questions come up later, an AI
              engineer will email you.
            </BotBubble>
            <div className="grid gap-3 pl-12 sm:grid-cols-2">
              <Button
                variant={mode === "immediate" ? "default" : "outline"}
                disabled={busy}
                onClick={runScan}
              >
                <ScanSearch className="mr-2 h-4 w-4" />
                Analyze now
              </Button>
              <Button
                variant={mode === "fast" ? "default" : "outline"}
                disabled={busy}
                onClick={() => {
                  setMode("fast");
                  setScan(null);
                  setStep(3);
                }}
              >
                <Zap className="mr-2 h-4 w-4" />
                Fast path
              </Button>
            </div>
            {busy && mode === "immediate" && (
              <p className="flex items-center gap-2 pl-12 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Scanning {files[0]?.name}…
              </p>
            )}
            {scan && (
              <div className="space-y-4">
                <BotBubble>
                  <p>{scan.summary}</p>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Estimated complexity: <b>{scan.complexity}</b>
                  </p>
                  {scan.questions.length === 0 && (
                    <p className="mt-2">Everything looks clear — no questions from me.</p>
                  )}
                </BotBubble>
                {scan.questions.map((q, i) => (
                  <div key={i} className="space-y-1 pl-12">
                    <Label>{q}</Label>
                    <Input
                      placeholder="Give an example…"
                      value={answers[i] ?? ""}
                      onChange={(e) =>
                        setAnswers((a) => a.map((x, j) => (j === i ? e.target.value : x)))
                      }
                    />
                  </div>
                ))}
                {step === 2 && (
                  <div className="pl-12">
                    <Button onClick={() => setStep(3)}>Continue</Button>
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {step >= 3 && !result && (
          <>
            <BotBubble>
              Almost done — a few quick questions about the business impact so we can prioritize
              your case.
            </BotBubble>
            <section className="space-y-4 rounded-xl border bg-card p-6">
              <h2 className="font-display text-lg font-bold">2 · Business impact</h2>
              <div className="grid grid-cols-3 gap-2">
                {(["growth", "efficiency", "profitability"] as const).map((t) => (
                  <Button
                    key={t}
                    variant={impact === t ? "default" : "outline"}
                    onClick={() => setImpact(t)}
                    className="capitalize"
                  >
                    {t === "efficiency" ? "Efficiency saving" : t}
                  </Button>
                ))}
              </div>
              {impact === "growth" && (
                <div className="space-y-2">
                  <Label>Extra top-line premium written per year (USD)</Label>
                  <Input
                    type="number"
                    min={0}
                    value={premium}
                    onChange={(e) => setPremium(+e.target.value)}
                  />
                </div>
              )}
              {impact === "efficiency" && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Person-days saved per year</Label>
                    <Input
                      type="number"
                      min={0}
                      value={days}
                      onChange={(e) => setDays(+e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Cost per person-day (USD)</Label>
                    <Input
                      type="number"
                      min={0}
                      value={cost}
                      onChange={(e) => setCost(+e.target.value)}
                    />
                  </div>
                </div>
              )}
              {impact === "profitability" && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Loss ratio improvement (percentage points)</Label>
                    <Input
                      type="number"
                      min={0}
                      step={0.1}
                      value={lr}
                      onChange={(e) => setLr(+e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Line of business</Label>
                    <Select value={lob} onValueChange={setLob}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LOBS.map((l) => (
                          <SelectItem key={l} value={l}>
                            {l}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                <Label>Expected accuracy (%) — 100% is not an option</Label>
                <Input
                  type="number"
                  min={50}
                  max={99.9}
                  step={0.1}
                  value={accuracy}
                  onChange={(e) => setAccuracy(+e.target.value)}
                />
                {!isValidAccuracy(accuracy) && (
                  <p className="text-sm text-destructive">Please choose a value below 100%.</p>
                )}
              </div>
              <p className="rounded-md bg-muted px-3 py-2 text-sm">
                Estimated annual business benefit: <b>{money(benefit)}</b>
              </p>
              <Button onClick={submit} disabled={busy || !isValidAccuracy(accuracy)}>
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}Submit case
              </Button>
            </section>
          </>
        )}

        {result && (
          <BotBubble>
            <p>
              Thanks! Your case is submitted (complexity: <b>{result.complexity}</b>).
            </p>
            <p className="mt-1">
              Expected return window:{" "}
              <b>
                {result.expected_days} day{result.expected_days > 1 ? "s" : ""}
              </b>
              .
            </p>
            {result.meeting_suggested && (
              <p className="mt-1">
                This one looks complex — an AI engineer will reach out to set up a short meeting
                first.
              </p>
            )}
            {mode === "fast" && (
              <p className="mt-1">
                You chose the fast path: if anything is unclear, an AI engineer will email you about
                specific data elements.
              </p>
            )}
            <Button size="sm" className="mt-3" onClick={() => nav({ to: "/home" })}>
              Back to home
            </Button>
          </BotBubble>
        )}
      </div>
    </AppShell>
  );
}
