import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ScanText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/ThemeToggle";
import { api, ApiError } from "@/lib/api";
import { homeFor, meQuery } from "@/lib/session";
import { useTitle } from "@/lib/use-title";

export const Route = createFileRoute("/")({
  beforeLoad: async ({ context }) => {
    // If the backend is unreachable, show the sign-in page anyway; signing in reports the error.
    const me = await context.queryClient.ensureQueryData(meQuery).catch(() => null);
    if (me) throw redirect({ to: homeFor(me.role) });
  },
  component: LoginPage,
});

function LoginPage() {
  useTitle("Sign in");
  const nav = useNavigate();
  const qc = useQueryClient();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <div className="relative grid min-h-screen lg:grid-cols-2">
      <div className="absolute right-4 top-4 z-10">
        <ThemeToggle />
      </div>
      <div className="relative hidden flex-col justify-between overflow-hidden border-r bg-card p-12 tech-grid lg:flex">
        <div className="pointer-events-none absolute -left-32 top-1/3 h-96 w-96 rounded-full bg-glow/20 blur-3xl" />
        <div className="relative flex items-center gap-2 font-display text-xl font-bold">
          <ScanText className="text-primary" /> Data Intake Desk
        </div>
        <div className="relative">
          <p className="mb-4 font-mono text-xs uppercase tracking-[0.25em] text-accent">
            // AI-powered document intake
          </p>
          <h1 className="font-display text-5xl font-bold leading-tight">
            From documents
            <br />
            to <span className="text-gradient-brand">decisions.</span>
          </h1>
          <p className="mt-5 max-w-md text-muted-foreground">
            Streamline policy, claims and underwriting documents into the data that drives smarter
            business decisions.
          </p>
        </div>
        <div className="relative flex gap-6 font-mono text-xs text-muted-foreground">
          <span>
            <span className="text-primary">01</span> Upload
          </span>
          <span>
            <span className="text-primary">02</span> Extract
          </span>
          <span>
            <span className="text-primary">03</span> Decide
          </span>
        </div>
      </div>
      <div className="flex items-center justify-center p-8">
        <form
          className="w-full max-w-sm space-y-5 rounded-2xl border bg-card p-8 shadow-glow"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError("");
            try {
              const user = await api.login(username, password);
              qc.setQueryData(meQuery.queryKey, user);
              nav({ to: homeFor(user.role) });
            } catch (err) {
              setError(
                err instanceof ApiError && err.status === 401
                  ? "Wrong username or password."
                  : (err as Error).message || "Sign-in failed, please retry.",
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          <div>
            <h2 className="font-display text-3xl font-bold">Sign in</h2>
            <p className="mt-1 text-sm text-muted-foreground">Use your intake account.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="u">Username</Label>
            <Input
              id="u"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="p">Password</Label>
            <Input
              id="p"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Signing in…" : "Sign in"}
          </Button>
        </form>
      </div>
    </div>
  );
}
