import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AppShell, statusLabel } from "@/components/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { api } from "@/lib/api";
import { requireRole } from "@/lib/session";
import { useTitle } from "@/lib/use-title";
import { annualBenefit } from "@/lib/priority";

export const Route = createFileRoute("/admin")({
  beforeLoad: ({ context }) => requireRole(context.queryClient, "admin"),
  component: Admin,
});

const money = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(n);

function Admin() {
  const { me } = Route.useRouteContext();
  useTitle("Admin");
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["admin"], queryFn: api.adminOverview });
  const [editing, setEditing] = useState<{ id: string; title: string; text: string } | null>(null);
  const [publishing, setPublishing] = useState(false);
  // Full case (requested elements, user examples, sample files) for the engineer working on it.
  const { data: detail } = useQuery({
    queryKey: ["case", editing?.id],
    queryFn: () => api.getCase(editing!.id),
    enabled: !!editing,
  });
  const cases = data?.cases ?? [];
  const withBenefit = cases.map((c) => ({ ...c, benefit: annualBenefit(c) }));
  const totalBenefit = withBenefit.reduce((s, c) => s + c.benefit, 0);
  const rated = cases.filter((c) => c.satisfaction != null);
  const avgSat = rated.length
    ? rated.reduce((s, c) => s + (c.satisfaction ?? 0), 0) / rated.length
    : 0;
  const speed = (["easy", "medium", "hard"] as const).map((lvl) => {
    const done = cases.filter((c) => c.complexity === lvl && c.completed_at);
    const avg = done.length
      ? done.reduce(
          (s, c) =>
            s + (new Date(c.completed_at!).getTime() - new Date(c.created_at).getTime()) / 86400000,
          0,
        ) / done.length
      : 0;
    const promised = cases.filter((c) => c.complexity === lvl);
    return {
      level: lvl,
      actual: +avg.toFixed(1),
      promised: promised.length
        ? +(promised.reduce((s, c) => s + c.expected_days, 0) / promised.length).toFixed(1)
        : 0,
    };
  });
  const byType = (["growth", "efficiency", "profitability"] as const).map((t) => ({
    type: t,
    benefit: Math.round(
      withBenefit.filter((c) => c.impact_type === t).reduce((s, c) => s + c.benefit, 0),
    ),
  }));

  return (
    <AppShell user={me}>
      <h1 className="mb-6 font-display text-3xl font-bold">Admin overview</h1>
      <div className="mb-6 grid gap-4 sm:grid-cols-4">
        {[
          ["Total cases", cases.length],
          ["Open", cases.filter((c) => c.status !== "completed").length],
          ["Avg. satisfaction", rated.length ? `${avgSat.toFixed(1)} / 5` : "—"],
          ["Annual benefit", money(totalBenefit)],
        ].map(([k, v]) => (
          <div key={k} className="rounded-xl border bg-card p-5">
            <div className="text-sm text-muted-foreground">{k}</div>
            <div className="font-display text-2xl font-bold">{v}</div>
          </div>
        ))}
      </div>
      <div className="mb-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border bg-card p-5">
          <h2 className="mb-3 font-display font-bold">Response speed by difficulty (days)</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={speed}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="level" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="promised" name="Promised" fill="var(--chart-2)" />
              <Bar dataKey="actual" name="Actual" fill="var(--chart-1)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-xl border bg-card p-5">
          <h2 className="mb-3 font-display font-bold">Annual benefit by impact type (USD)</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={byType}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="type" />
              <YAxis tickFormatter={money} />
              <Tooltip formatter={(v: number) => money(v)} />
              <Bar dataKey="benefit" fill="var(--chart-3)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="rounded-xl border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Case</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead>Impact</TableHead>
              <TableHead>Benefit / yr</TableHead>
              <TableHead>Difficulty</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Window</TableHead>
              <TableHead>Satisfaction</TableHead>
              <TableHead>Status</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {withBenefit.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="font-medium">
                  {c.title}
                  {c.meeting_suggested && (
                    <Badge variant="outline" className="ml-2">
                      Meeting
                    </Badge>
                  )}
                  {c.analysis_mode === "fast" && (
                    <Badge variant="outline" className="ml-2">
                      Fast path
                    </Badge>
                  )}
                </TableCell>
                <TableCell>{new Date(c.created_at).toLocaleDateString()}</TableCell>
                <TableCell className="capitalize">
                  {c.impact_type}
                  {c.lob ? ` · ${c.lob}` : ""}
                </TableCell>
                <TableCell>{money(c.benefit)}</TableCell>
                <TableCell className="capitalize">{c.complexity}</TableCell>
                <TableCell>{c.priority_score}</TableCell>
                <TableCell>{c.expected_days}d</TableCell>
                <TableCell>{c.satisfaction ? `${c.satisfaction}★` : "—"}</TableCell>
                <TableCell>
                  <Badge variant={c.status === "completed" ? "default" : "secondary"}>
                    {statusLabel[c.status] ?? c.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditing({ id: c.id, title: c.title, text: c.result_text })}
                  >
                    Result
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {(data?.feedback.length ?? 0) > 0 && (
        <div className="mt-6 rounded-xl border bg-card p-5">
          <h2 className="mb-3 font-display font-bold">Returned cases & feedback</h2>
          {data!.feedback.map((f) => (
            <div key={f.id} className="border-b py-2 text-sm last:border-0">
              <b>{cases.find((c) => c.id === f.case_id)?.title}</b> — {f.comment}
              <Badge
                variant={f.difficulty === "easy" ? "secondary" : "destructive"}
                className="ml-2"
              >
                {f.wants_engineer
                  ? "Wants engineer"
                  : f.difficulty === "easy"
                    ? `Easy · ${f.eta_hours}h`
                    : "Hard"}
              </Badge>
            </div>
          ))}
        </div>
      )}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Publish result · {editing?.title}</DialogTitle>
          </DialogHeader>
          {detail && detail.case.id === editing?.id && (
            <div className="space-y-2 rounded-md bg-muted p-3 text-sm">
              <p>
                <span className="text-muted-foreground">Capture:</span> {detail.case.data_elements}
              </p>
              {detail.case.description && (
                <p>
                  <span className="text-muted-foreground">Documents:</span>{" "}
                  {detail.case.description}
                </p>
              )}
              {detail.case.user_examples && (
                <pre className="whitespace-pre-wrap font-sans text-xs text-muted-foreground">
                  {detail.case.user_examples}
                </pre>
              )}
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                <span className="text-muted-foreground">Sample files:</span>
                {detail.files.length === 0 && <span>None</span>}
                {detail.files.map((f) => (
                  <a key={f.id} href={f.url} className="text-primary underline">
                    {f.file_name}
                  </a>
                ))}
              </div>
            </div>
          )}
          <Textarea
            rows={10}
            value={editing?.text ?? ""}
            placeholder="Extracted data to send back to the requester…"
            onChange={(e) => setEditing((x) => x && { ...x, text: e.target.value })}
          />
          <Button
            disabled={publishing || !editing?.text.trim()}
            onClick={async () => {
              if (!editing?.text.trim()) return;
              setPublishing(true);
              try {
                await api.completeCase(editing.id, editing.text);
                setEditing(null);
                qc.invalidateQueries();
                toast.success("Result published — the user will see it on their home screen");
              } catch (e) {
                toast.error((e as Error).message);
              }
              setPublishing(false);
            }}
          >
            Mark completed
          </Button>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
