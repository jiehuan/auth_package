import { annualBenefit, formatUsd } from "@/lib/priority";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Bell, FilePlus2, FolderOpen } from "lucide-react";
import { AppShell, BotBubble, statusLabel } from "@/components/AppShell";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { requireRole } from "@/lib/session";
import { useTitle } from "@/lib/use-title";

export const Route = createFileRoute("/home")({
  beforeLoad: ({ context }) => requireRole(context.queryClient, "user"),
  component: Home,
});

function Home() {
  const { me } = Route.useRouteContext();
  useTitle("Intake assistant");
  const { data: cases = [] } = useQuery({ queryKey: ["cases"], queryFn: api.listCases });
  const [mode, setMode] = useState<"none" | "existing">("none");
  const ready = cases.filter((c) => c.status === "completed" && c.satisfaction == null);
  return (
    <AppShell user={me}>
      <div className="mx-auto max-w-3xl space-y-6">
        {ready.length > 0 && (
          <div className="flex items-center gap-3 rounded-lg border border-accent bg-accent/15 px-4 py-3 text-sm">
            <Bell className="h-4 w-4 text-accent-foreground" />
            <span>
              {ready.length} case result{ready.length > 1 ? "s are" : " is"} ready for your review.
            </span>
          </div>
        )}
        <BotBubble>
          Hi {me.username}! 👋 I'm your intake assistant. Are you here to{" "}
          <b>view an existing intake case</b>, or to <b>set up a new data intake use case</b>?
        </BotBubble>
        <div className="grid gap-4 pl-12 sm:grid-cols-2">
          <button
            onClick={() => setMode("existing")}
            className="rounded-xl border bg-card p-5 text-left transition hover:border-primary hover:shadow-md"
          >
            <FolderOpen className="mb-3 h-6 w-6 text-primary" />
            <div className="font-display font-bold">View existing case</div>
            <p className="text-sm text-muted-foreground">
              See results, download, or send a case back.
            </p>
          </button>
          <Link
            to="/new"
            className="rounded-xl border bg-card p-5 text-left transition hover:border-primary hover:shadow-md"
          >
            <FilePlus2 className="mb-3 h-6 w-6 text-primary" />
            <div className="font-display font-bold">New intake use case</div>
            <p className="text-sm text-muted-foreground">
              Upload samples and describe what to capture.
            </p>
          </Link>
        </div>
        {mode === "existing" && (
          <>
            <BotBubble>Here are your cases. Pick one to see the intake result.</BotBubble>
            <div className="space-y-2 pl-12">
              {cases.map((c) => (
                <Link
                  key={c.id}
                  to="/cases/$id"
                  params={{ id: c.id }}
                  className="flex items-center justify-between rounded-lg border bg-card px-4 py-3 hover:border-primary"
                >
                  <div>
                    <div className="font-medium">{c.title}</div>
                    <div className="text-xs text-muted-foreground">
                      Submitted {new Date(c.created_at).toLocaleDateString()} · {c.lob} · target
                      benefit <b className="text-accent">{formatUsd(annualBenefit(c))}/yr</b>
                    </div>
                  </div>
                  <Badge variant={c.status === "completed" ? "default" : "secondary"}>
                    {statusLabel[c.status] ?? c.status}
                  </Badge>
                </Link>
              ))}
              {cases.length === 0 && <p className="text-sm text-muted-foreground">No cases yet.</p>}
            </div>
          </>
        )}
      </div>
    </AppShell>
  );
}
