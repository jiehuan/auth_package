import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";
import { routeTree } from "@/routeTree.gen";

// Match routes without running loaders or rendering.
describe("routing", () => {
  const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
  it.each(["/", "/home", "/new", "/admin", "/cases/abc"])("matches a page for %s", (url) => {
    expect(router.matchRoutes(url).at(-1)?.routeId).not.toBe(rootRouteId);
  });
  it("falls back to not found for unknown paths", () => {
    expect(router.matchRoutes("/nope").at(-1)?.routeId).toBe(rootRouteId);
  });
});
