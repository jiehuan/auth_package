import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut, ScanText } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { ThemeToggle } from "@/components/ThemeToggle";
import robot from "@/assets/robot-bot.png";

export function AppShell({
  user,
  children,
}: {
  user: { username: string; role: string };
  children: ReactNode;
}) {
  const nav = useNavigate();
  const qc = useQueryClient();
  return (
    <div className="min-h-screen bg-background tech-grid">
      <header className="sticky top-0 z-10 border-b bg-card/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link
            to={user.role === "admin" ? "/admin" : "/home"}
            className="flex items-center gap-2 font-display text-lg font-bold text-primary"
          >
            <ScanText className="h-5 w-5" /> Data Intake Desk
          </Link>
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <ThemeToggle />
            <span>{user.username}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={async () => {
                await api.logout().catch(() => undefined);
                qc.clear();
                nav({ to: "/", replace: true });
              }}
            >
              <LogOut className="mr-1 h-4 w-4" /> Sign out
            </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
    </div>
  );
}

export function BotBubble({ children }: { children: ReactNode }) {
  return (
    <div className="flex gap-3">
      <div className="relative h-11 w-11 shrink-0 rounded-full bg-gradient-to-br from-accent/30 to-primary/20 p-0.5 shadow-glow">
        <img
          src={robot}
          alt="Intake assistant robot"
          width={44}
          height={44}
          className="h-full w-full animate-[bounce_3s_ease-in-out_infinite] object-contain"
        />
        <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card bg-accent" />
      </div>
      <div className="rounded-2xl rounded-tl-sm border bg-card px-4 py-3 text-sm leading-relaxed shadow-sm">
        {children}
      </div>
    </div>
  );
}

export const statusLabel: Record<string, string> = {
  submitted: "Submitted",
  in_progress: "In progress",
  completed: "Completed",
  rework: "Being revised",
  engineer_review: "AI engineer follow-up",
};
