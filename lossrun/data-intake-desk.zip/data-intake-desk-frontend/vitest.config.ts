import path from "node:path";
import { defineConfig } from "vitest/config";

// Pure-logic tests only (no DOM needed), so the default node environment is enough.
export default defineConfig({
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "src") } },
  test: {
    include: ["src/**/*.test.{ts,tsx}"],
  },
});
