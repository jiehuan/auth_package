# Data Intake Desk — Backend

FastAPI API for Data Intake Desk: business teams submit sample documents and the data elements
they need, the AI team publishes the extracted result, and requesters rate it or send it back.

The SPA lives in **data-intake-desk-frontend**; its pod proxies `/api/*` to this service, so the
backend has no Route and needs no CORS.

```
intakedesk/
  main.py            app factory, CSRF guard, /healthz, /readyz
  config.py          all settings from environment variables
  models.py          intake_cases, intake_files, intake_feedback (SQLite / Azure SQL portable)
  db.py  seed.py     engine + create_all, demo data for an empty database
  security.py        two fixed accounts, HMAC-signed httpOnly session cookie
  priority.py        benefit, priority score, return window (mirrored in the frontend)
  storage.py         uploaded files on local disk (the PVC); ADLS can replace it later
  documents.py       upload validation, PDF/text extraction
  llm/               LLM interface: heuristic (default) and openai_compatible
  routers/           auth, cases, admin, files
tests/               pytest, SQLite in a temp dir
```

## API

| Method | Path | Who |
|---|---|---|
| POST | `/api/auth/login` · `/api/auth/logout` | anyone |
| GET | `/api/auth/me` → `{"user": null \| {username, role}}` | anyone |
| GET | `/api/cases` · `/api/cases/{id}` · `/api/files/{id}` | signed in |
| POST | `/api/cases/analyze-sample` (multipart: description, data_elements, file) | user |
| POST | `/api/cases` (multipart: payload = JSON, files = 1–5 files) | user |
| POST | `/api/cases/{id}/return` · `/api/cases/{id}/rating` | user |
| GET | `/api/admin/overview` | admin |
| POST | `/api/admin/cases/{id}/complete` | admin |

OpenAPI docs: `/api/docs`. Every POST must send `X-Requested-With` (the frontend client does);
together with the SameSite=Lax cookie this blocks cross-site requests.

## Local development

```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt pytest
cp .env.example .env && set -a && . ./.env && set +a
python -m uvicorn intakedesk.main:app --reload --port 8080
python -m pytest -q
```

Run the frontend with `npm run dev`; it proxies `/api` to `localhost:8080`.

## Configuration

ConfigMap (`manifests/configmap.yaml`): `DATABASE_URL`, `STORAGE_DIR`, `SEED_DEMO_DATA`,
`COOKIE_SECURE`, `SESSION_HOURS`, `MAX_FILES`, `MAX_FILE_MB`, `LLM_*`, `LOG_LEVEL`.

Secret `data-intake-desk-backend-secret` (created once with `oc`, see
`manifests/secret.example.yaml`; never in Git or in the Harness manifest list):
`SESSION_SECRET`, `INTAKE_USER_PASSWORD`, `INTAKE_ADMIN_PASSWORD`, `LLM_API_KEY`.
An account with an empty password cannot sign in. Changing `SESSION_SECRET` signs everyone out.

## LLM

`LLM_PROVIDER=heuristic` (default) needs no network. It reads text from PDF/TXT/CSV/JSON/MD
samples, checks which requested data elements have a matching label, and asks about the missing
or ambiguous ones; images and scanned PDFs are flagged for manual review. Feedback triage uses
keywords (English and Chinese).

For the internal LLM API set `LLM_PROVIDER=openai_compatible`, `LLM_BASE_URL`, `LLM_MODEL`
(ConfigMap) and `LLM_API_KEY` (Secret). Any `/chat/completions` endpoint with `json_schema`
response format works; for Azure OpenAI style gateways also set `LLM_API_KEY_HEADER=api-key`
and `LLM_API_VERSION`. A different client only needs to implement `LLMProvider` in
`llm/base.py` and be registered in `llm/__init__.py`. If triage fails, the heuristic is used so
the feedback is still recorded; if a sample scan fails, the user sees the error and can take
the fast path.

## Build and deploy (Harness → OpenShift)

CI: `harness/build-stage.yaml`. The `pip_install` step runs
`pip install --target pydeps -r requirements.txt` in `python:3.12-slim-bookworm`, smoke-tests the
import, runs pytest, then buildah packages `pydeps/` + `intakedesk/` (the Dockerfile has no RUN).
The Run step image and the Dockerfile `FROM` must stay identical (compiled wheels).

CD (Harness Service, K8s Manifest):
* Manifest paths: `manifests/configmap.yaml`, `manifests/pvc.yaml`, `manifests/service.yaml`,
  `manifests/deployment.yaml`
* Values YAML: `manifests/values-dev.yaml` (`image: <+artifacts.primary.image>`)
* Artifact source: connector `jfrog0328axio`, image path
  `xlcdiadeep-axiom-ai-submission-prioritisation-s-local-docker/data-intake-desk-backend`,
  tag `<+pipeline.sequenceId>`

First deployment in a namespace: create the Secret before the first deploy, or the pod will not
start (`CreateContainerConfigError`).

Runtime: one replica, `Recreate` strategy, SQLite and uploads on the `data-intake-desk-data` PVC
(5Gi RWO). Probes: startup + liveness on `/healthz`, readiness on `/readyz` (runs `SELECT 1`).

## Moving to Azure SQL

1. Add `pyodbc` to `requirements.txt` and the Microsoft ODBC driver to the image.
2. `DATABASE_URL=mssql+pyodbc://...`
3. Replace `create_all` in `db.py` with Alembic migrations generated from `models.py`.
4. Move files to ADLS (new `Storage` implementation); the PVC can then go and the Deployment
   can scale beyond one replica (switch the strategy back to RollingUpdate).
