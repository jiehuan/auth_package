"""Upload validation and best-effort text extraction for sample documents."""

from __future__ import annotations

import io
import logging
import mimetypes
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)

ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".txt", ".csv", ".json", ".md"}
TEXT_EXTENSIONS = {".txt", ".csv", ".json", ".md"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg"}
MAX_TEXT_CHARS = 40_000
MAX_PDF_PAGES = 40


@dataclass
class SampleDocument:
    name: str
    content_type: str
    data: bytes
    text: str | None  # None when no text could be read (image, scanned PDF)
    pages: int | None = None

    @property
    def is_image(self) -> bool:
        return Path(self.name).suffix.lower() in IMAGE_EXTENSIONS


def extension_ok(name: str) -> bool:
    return Path(name).suffix.lower() in ALLOWED_EXTENSIONS


def guess_type(name: str, declared: str | None) -> str:
    if declared and declared != "application/octet-stream":
        return declared[:100]
    return mimetypes.guess_type(name)[0] or "application/octet-stream"


def load(name: str, declared_type: str | None, data: bytes) -> SampleDocument:
    ext = Path(name).suffix.lower()
    ctype = guess_type(name, declared_type)
    text: str | None = None
    pages: int | None = None
    if ext in TEXT_EXTENSIONS:
        text = data.decode("utf-8", errors="replace")
    elif ext == ".pdf":
        text, pages = _pdf_text(data)
    return SampleDocument(
        name=name,
        content_type=ctype,
        data=data,
        text=text[:MAX_TEXT_CHARS] if text and text.strip() else None,
        pages=pages,
    )


def _pdf_text(data: bytes) -> tuple[str | None, int | None]:
    try:
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        parts: list[str] = []
        total = 0
        for page in reader.pages[:MAX_PDF_PAGES]:
            t = page.extract_text() or ""
            parts.append(t)
            total += len(t)
            if total > MAX_TEXT_CHARS:
                break
        return "\n".join(parts), len(reader.pages)
    except Exception as exc:  # malformed or encrypted PDFs: treat as unreadable
        log.info("PDF text extraction failed for upload: %s", exc)
        return None, None
