from __future__ import annotations

import logging

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import IntakeCase, IntakeFeedback, utcnow
from ..schemas import AdminOverviewOut, CaseOut, CompleteIn, FeedbackOut, OkOut
from ..security import CurrentUser, require_admin
from .common import get_case_or_404

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/overview", response_model=AdminOverviewOut)
def overview(db: Session = Depends(get_db), _: CurrentUser = Depends(require_admin)) -> AdminOverviewOut:
    cases = db.scalars(select(IntakeCase).order_by(IntakeCase.created_at.desc()))
    feedback = db.scalars(select(IntakeFeedback).order_by(IntakeFeedback.created_at.desc()))
    return AdminOverviewOut(
        cases=[CaseOut.model_validate(c) for c in cases],
        feedback=[FeedbackOut.model_validate(f) for f in feedback],
    )


@router.post("/cases/{case_id}/complete", response_model=OkOut)
def complete_case(
    case_id: str, body: CompleteIn, db: Session = Depends(get_db), user: CurrentUser = Depends(require_admin)
) -> OkOut:
    case = get_case_or_404(db, case_id)
    case.result_text = body.result_text
    case.status = "completed"
    case.completed_at = utcnow()
    db.commit()
    log.info("Case %s result published by %s", case.id, user.username)
    return OkOut()
