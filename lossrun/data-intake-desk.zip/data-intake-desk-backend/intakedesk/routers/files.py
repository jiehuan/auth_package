from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import IntakeFile
from ..security import CurrentUser, require_session
from ..storage import Storage
from .common import get_storage

router = APIRouter(prefix="/api/files", tags=["files"])


@router.get("/{file_id}")
def download_file(
    file_id: str,
    db: Session = Depends(get_db),
    storage: Storage = Depends(get_storage),
    _: CurrentUser = Depends(require_session),
) -> FileResponse:
    f = db.get(IntakeFile, file_id)
    if f is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "File not found")
    path = storage.path_for(f.storage_path)
    if not path.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "File is missing from storage")
    return FileResponse(
        path,
        media_type=f.content_type or "application/octet-stream",
        filename=f.file_name,
        headers={"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"},
    )
