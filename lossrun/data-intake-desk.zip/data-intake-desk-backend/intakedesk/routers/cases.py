from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import documents
from ..config import Settings
from ..db import get_db
from ..llm import HeuristicLLM, LLMError, LLMProvider
from ..models import IntakeCase, IntakeFeedback, IntakeFile
from ..priority import (
    annual_benefit,
    expected_days,
    heuristic_complexity,
    is_valid_accuracy,
    priority_score,
    suggest_meeting,
)
from ..schemas import (
    CaseDetailOut,
    CaseOut,
    CreateCaseIn,
    CreateCaseOut,
    FeedbackOut,
    OkOut,
    RatingIn,
    ReturnIn,
    ReturnOut,
    SampleScanOut,
)
from ..security import CurrentUser, get_settings, require_session, require_user
from ..storage import Storage
from .common import file_out, get_case_or_404, get_llm, get_storage, read_upload

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/cases", tags=["cases"])


@router.get("", response_model=list[CaseOut])
def list_cases(db: Session = Depends(get_db), _: CurrentUser = Depends(require_session)) -> list[IntakeCase]:
    return list(db.scalars(select(IntakeCase).order_by(IntakeCase.created_at.desc())))


@router.get("/{case_id}", response_model=CaseDetailOut)
def get_case(case_id: str, db: Session = Depends(get_db), _: CurrentUser = Depends(require_session)) -> CaseDetailOut:
    case = get_case_or_404(db, case_id)
    return CaseDetailOut(
        case=CaseOut.model_validate(case),
        files=[file_out(f) for f in case.files],
        feedback=[FeedbackOut.model_validate(f) for f in case.feedback],
    )


@router.post("/analyze-sample", response_model=SampleScanOut)
def analyze_sample(
    description: str = Form("", max_length=5000),
    data_elements: str = Form(..., max_length=5000),
    file: UploadFile = File(...),
    settings: Settings = Depends(get_settings),
    llm: LLMProvider = Depends(get_llm),
    _: CurrentUser = Depends(require_user),
) -> SampleScanOut:
    name, ctype, data = read_upload(file, settings)
    doc = documents.load(name, ctype, data)
    scan = llm.analyze_sample(description, data_elements, doc)  # LLMError -> 503 (see main.py)
    return SampleScanOut(**scan.model_dump())


@router.post("", response_model=CreateCaseOut, status_code=status.HTTP_201_CREATED)
def create_case(
    payload: str = Form(..., max_length=50_000),
    files: list[UploadFile] = File(...),
    db: Session = Depends(get_db),
    storage: Storage = Depends(get_storage),
    settings: Settings = Depends(get_settings),
    user: CurrentUser = Depends(require_user),
) -> CreateCaseOut:
    try:
        body = CreateCaseIn.model_validate(json.loads(payload))
    except (json.JSONDecodeError, ValidationError) as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, f"Invalid case data: {exc}") from exc
    if not is_valid_accuracy(body.expected_accuracy):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "Expected accuracy must be below 100%.")
    if not 1 <= len(files) <= settings.max_files:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, f"Upload between 1 and {settings.max_files} files.")
    uploads = [read_upload(f, settings) for f in files]  # validate everything before writing

    complexity = body.ai_complexity or heuristic_complexity(body.data_elements, body.expected_accuracy)
    benefit = annual_benefit(
        body.impact_type, body.premium_growth, body.person_days, body.cost_per_day, body.loss_ratio_impact, body.lob
    )
    score = priority_score(benefit)
    days = expected_days(complexity, score, body.expected_accuracy)
    meeting = suggest_meeting(complexity, body.expected_accuracy)

    row = body.model_dump(exclude={"ai_complexity"})
    case = IntakeCase(
        **row,
        complexity=complexity,
        priority_score=score,
        expected_days=days,
        meeting_suggested=meeting,
        created_by=user.username,
    )
    db.add(case)
    db.flush()  # assigns case.id
    try:
        for name, ctype, data in uploads:
            path = storage.save(case.id, name, data)
            db.add(IntakeFile(case_id=case.id, file_name=name, storage_path=path, content_type=ctype, size_bytes=len(data)))
        db.commit()
    except Exception:
        db.rollback()
        storage.delete_case(case.id)
        raise
    log.info("Case %s created by %s (%s, priority %s)", case.id, user.username, complexity, score)
    return CreateCaseOut(
        id=case.id, complexity=complexity, expected_days=days, meeting_suggested=meeting, priority_score=score
    )


@router.post("/{case_id}/return", response_model=ReturnOut)
def return_case(
    case_id: str,
    body: ReturnIn,
    db: Session = Depends(get_db),
    llm: LLMProvider = Depends(get_llm),
    user: CurrentUser = Depends(require_user),
) -> ReturnOut:
    case = get_case_or_404(db, case_id)
    difficulty = "hard"
    reply = "Our AI team will contact you to set up a time to review the details together."
    eta: int | None = None
    if not body.wants_engineer:
        try:
            triage = llm.triage_feedback(case.title, case.data_elements, case.result_text, body.comment)
        except LLMError as exc:
            # The feedback must still be recorded; fall back to the rule-based triage.
            log.warning("LLM triage failed (%s); using heuristic", exc)
            triage = HeuristicLLM().triage_feedback(case.title, case.data_elements, case.result_text, body.comment)
        difficulty = triage.difficulty
        reply = triage.reply
        eta = triage.eta_hours if triage.difficulty == "easy" else None

    db.add(
        IntakeFeedback(
            case_id=case.id,
            comment=body.comment,
            wants_engineer=body.wants_engineer,
            difficulty=difficulty,
            bot_reply=reply,
            eta_hours=eta,
            created_by=user.username,
        )
    )
    case.status = "rework" if difficulty == "easy" else "engineer_review"
    case.completed_at = None
    db.commit()
    return ReturnOut(difficulty=difficulty, reply=reply, eta_hours=eta)


@router.post("/{case_id}/rating", response_model=OkOut)
def rate_case(
    case_id: str, body: RatingIn, db: Session = Depends(get_db), _: CurrentUser = Depends(require_user)
) -> OkOut:
    case = get_case_or_404(db, case_id)
    case.satisfaction = body.satisfaction
    db.commit()
    return OkOut()
