from __future__ import annotations

from fastapi import HTTPException, Request, UploadFile, status
from sqlalchemy.orm import Session

from .. import documents
from ..config import Settings
from ..llm import LLMProvider
from ..models import IntakeCase, IntakeFile
from ..schemas import FileOut
from ..storage import Storage


def get_storage(request: Request) -> Storage:
    return request.app.state.storage


def get_llm(request: Request) -> LLMProvider:
    return request.app.state.llm


def get_case_or_404(db: Session, case_id: str) -> IntakeCase:
    case = db.get(IntakeCase, case_id)
    if case is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    return case


def read_upload(upload: UploadFile, settings: Settings) -> tuple[str, str, bytes]:
    name = (upload.filename or "file").strip()[:200]
    if not documents.extension_ok(name):
        allowed = ", ".join(sorted(documents.ALLOWED_EXTENSIONS))
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, f"{name}: unsupported file type (allowed: {allowed}).")
    data = upload.file.read(settings.max_file_bytes + 1)
    if len(data) > settings.max_file_bytes:
        raise HTTPException(
            status.HTTP_413_CONTENT_TOO_LARGE, f"{name} is larger than {settings.max_file_mb}MB."
        )
    if not data:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"{name} is empty.")
    return name, documents.guess_type(name, upload.content_type), data


def file_out(f: IntakeFile) -> FileOut:
    return FileOut(
        id=f.id,
        case_id=f.case_id,
        file_name=f.file_name,
        content_type=f.content_type,
        size_bytes=f.size_bytes,
        created_at=f.created_at,
        url=f"/api/files/{f.id}",
    )
