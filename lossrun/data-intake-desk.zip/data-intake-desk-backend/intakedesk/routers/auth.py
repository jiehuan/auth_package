from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Response, status

from ..config import Settings
from ..schemas import LoginIn, MeOut, OkOut, UserOut
from ..security import CurrentUser, authenticate, clear_session, current_user_optional, get_settings, issue_session

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=UserOut)
def login(body: LoginIn, response: Response, settings: Settings = Depends(get_settings)) -> UserOut:
    user = authenticate(settings, body.username, body.password)
    if user is None:
        log.info("Failed sign-in for username=%r", body.username[:100])
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Wrong username or password.")
    issue_session(settings, response, user)
    return UserOut(username=user.username, role=user.role)


@router.post("/logout", response_model=OkOut)
def logout(response: Response, settings: Settings = Depends(get_settings)) -> OkOut:
    clear_session(settings, response)
    return OkOut()


@router.get("/me", response_model=MeOut)
def me(user: CurrentUser | None = Depends(current_user_optional)) -> MeOut:
    return MeOut(user=UserOut(username=user.username, role=user.role) if user else None)
