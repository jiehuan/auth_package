"""Business impact -> annual benefit, priority score and expected return window.

Mirrors src/lib/priority.ts in the frontend (which only uses it for live display);
the values stored on a case are always computed here.
"""

from __future__ import annotations

import math
import re
from typing import Literal

ImpactType = Literal["growth", "efficiency", "profitability"]
Complexity = Literal["easy", "medium", "hard"]

# Assumed annual earned premium per line of business (USD), used to value loss-ratio points.
LOB_PREMIUM_BASE: dict[str, float] = {
    "Property": 50_000_000,
    "Motor": 80_000_000,
    "Marine": 20_000_000,
    "Casualty": 40_000_000,
    "Health": 60_000_000,
    "Life": 70_000_000,
    "Other": 10_000_000,
}
LOBS = list(LOB_PREMIUM_BASE)
# Share of top-line premium counted as benefit for growth cases.
GROWTH_MARGIN = 0.1


def annual_benefit(
    impact_type: str,
    premium_growth: float = 0,
    person_days: float = 0,
    cost_per_day: float = 0,
    loss_ratio_impact: float = 0,
    lob: str = "",
) -> float:
    if impact_type == "growth":
        return (premium_growth or 0) * GROWTH_MARGIN
    if impact_type == "efficiency":
        return (person_days or 0) * (cost_per_day or 0)
    base = LOB_PREMIUM_BASE.get(lob or "Other", LOB_PREMIUM_BASE["Other"])
    return ((loss_ratio_impact or 0) / 100) * base


def is_valid_accuracy(a: float) -> bool:
    return math.isfinite(a) and 0 < a < 100


def priority_score(benefit: float) -> int:
    """0-100, log scale: $10k -> 20, $100k -> 40, $1M -> 60, $10M -> 80."""
    if benefit <= 0:
        return 0
    # floor(x + 0.5) matches JavaScript's Math.round (Python's round() is banker's rounding).
    return max(0, min(100, math.floor((math.log10(benefit) - 3) * 20 + 0.5)))


def expected_days(complexity: str, score: int, accuracy: float) -> int:
    """Expected return window in days: 1 day minimum, 14 days maximum."""
    base = {"easy": 2, "medium": 6}.get(complexity, 12)
    d = base - math.floor(score / 25)  # high priority jumps the queue
    if accuracy >= 97:
        d += 2
    return max(1, min(14, d))


def suggest_meeting(complexity: str, accuracy: float) -> bool:
    return complexity == "hard" or accuracy >= 98


ELEMENT_SPLIT = re.compile(r"[,\n;，、；]")


def split_elements(elements: str) -> list[str]:
    return [s.strip() for s in ELEMENT_SPLIT.split(elements) if s.strip()]


def heuristic_complexity(elements: str, accuracy: float) -> Complexity:
    n = len(split_elements(elements))
    if n > 12 or accuracy >= 97:
        return "hard"
    if n > 5:
        return "medium"
    return "easy"
