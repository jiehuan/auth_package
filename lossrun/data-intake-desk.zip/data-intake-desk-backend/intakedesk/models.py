"""ORM models. Column types are portable between SQLite and Azure SQL (SQL Server)."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    # Stored as naive UTC so SQLite and SQL Server behave the same; serialized with "Z".
    return datetime.now(timezone.utc).replace(tzinfo=None)


def new_id() -> str:
    return str(uuid.uuid4())


class Base(DeclarativeBase):
    pass


class IntakeCase(Base):
    __tablename__ = "intake_cases"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    data_elements: Mapped[str] = mapped_column(Text, default="")
    analysis_mode: Mapped[str] = mapped_column(String(16), default="fast")  # immediate | fast
    ai_questions: Mapped[list] = mapped_column(JSON, default=list)
    user_examples: Mapped[str] = mapped_column(Text, default="")
    impact_type: Mapped[str] = mapped_column(String(20))  # growth | efficiency | profitability
    premium_growth: Mapped[float] = mapped_column(Float, default=0)
    person_days: Mapped[float] = mapped_column(Float, default=0)
    cost_per_day: Mapped[float] = mapped_column(Float, default=0)
    loss_ratio_impact: Mapped[float] = mapped_column(Float, default=0)
    lob: Mapped[str] = mapped_column(String(50), default="")
    expected_accuracy: Mapped[float] = mapped_column(Float, default=90)
    complexity: Mapped[str] = mapped_column(String(10), default="medium")  # easy | medium | hard
    priority_score: Mapped[int] = mapped_column(Integer, default=0)
    expected_days: Mapped[int] = mapped_column(Integer, default=5)
    meeting_suggested: Mapped[bool] = mapped_column(Boolean, default=False)
    # submitted | in_progress | completed | rework | engineer_review
    status: Mapped[str] = mapped_column(String(20), default="submitted", index=True)
    result_text: Mapped[str] = mapped_column(Text, default="")
    satisfaction: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[str] = mapped_column(String(100), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    files: Mapped[list[IntakeFile]] = relationship(
        back_populates="case", cascade="all, delete-orphan", order_by="IntakeFile.created_at"
    )
    feedback: Mapped[list[IntakeFeedback]] = relationship(
        back_populates="case", cascade="all, delete-orphan", order_by="IntakeFeedback.created_at"
    )


class IntakeFile(Base):
    __tablename__ = "intake_files"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    case_id: Mapped[str] = mapped_column(ForeignKey("intake_cases.id", ondelete="CASCADE"), index=True)
    file_name: Mapped[str] = mapped_column(String(255))
    storage_path: Mapped[str] = mapped_column(String(500))
    content_type: Mapped[str] = mapped_column(String(100), default="application/octet-stream")
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    case: Mapped[IntakeCase] = relationship(back_populates="files")


class IntakeFeedback(Base):
    __tablename__ = "intake_feedback"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    case_id: Mapped[str] = mapped_column(ForeignKey("intake_cases.id", ondelete="CASCADE"), index=True)
    comment: Mapped[str] = mapped_column(Text)
    wants_engineer: Mapped[bool] = mapped_column(Boolean, default=False)
    difficulty: Mapped[str] = mapped_column(String(10), default="easy")  # easy | hard
    bot_reply: Mapped[str] = mapped_column(Text, default="")
    eta_hours: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[str] = mapped_column(String(100), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)

    case: Mapped[IntakeCase] = relationship(back_populates="feedback")
