"""File storage for uploaded samples.

LocalStorage writes to STORAGE_DIR (a PVC on OpenShift). An ADLS implementation can be added
later behind the same three methods without touching the routers.
"""

from __future__ import annotations

import re
import uuid
from pathlib import Path
from typing import Protocol

_UNSAFE = re.compile(r"[^\w.\-]")


def safe_name(name: str) -> str:
    base = Path(name).name or "file"
    return _UNSAFE.sub("_", base)[-150:]


class Storage(Protocol):
    def save(self, case_id: str, file_name: str, data: bytes) -> str: ...
    def path_for(self, storage_path: str) -> Path: ...
    def delete_case(self, case_id: str) -> None: ...


class LocalStorage:
    def __init__(self, base_dir: Path) -> None:
        self.base = base_dir.resolve()
        self.base.mkdir(parents=True, exist_ok=True)

    def save(self, case_id: str, file_name: str, data: bytes) -> str:
        rel = f"{case_id}/{uuid.uuid4()}-{safe_name(file_name)}"
        target = self.path_for(rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_suffix(target.suffix + ".part")
        tmp.write_bytes(data)
        tmp.replace(target)
        return rel

    def path_for(self, storage_path: str) -> Path:
        p = (self.base / storage_path).resolve()
        if not p.is_relative_to(self.base):
            raise ValueError("invalid storage path")
        return p

    def delete_case(self, case_id: str) -> None:
        d = self.path_for(case_id)
        if d.is_dir():
            for f in d.iterdir():
                f.unlink(missing_ok=True)
            d.rmdir()
