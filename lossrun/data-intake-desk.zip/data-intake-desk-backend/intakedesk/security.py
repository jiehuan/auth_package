"""Fixed-account login and HMAC-signed session cookie.

Two accounts (a requester and an admin) whose passwords come from the Secret. The session is a
signed, httpOnly cookie: base64url(json payload) + "." + base64url(HMAC-SHA256). No server-side
session store, so the backend stays stateless apart from the database.

When Entra ID arrives, replace `authenticate()` / `current_user()` and keep the `require_*`
dependencies so the routers don't change.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Literal

from fastapi import Depends, HTTPException, Request, Response, status

from .config import Settings

Role = Literal["user", "admin"]
COOKIE_NAME = "intake_session"


@dataclass(frozen=True)
class CurrentUser:
    username: str
    role: Role


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _sign(secret: str, data: bytes) -> bytes:
    return hmac.new(secret.encode(), data, hashlib.sha256).digest()


def _safe_equal(a: str, b: str) -> bool:
    # Compare fixed-length digests so neither the content nor the length leaks through timing.
    return hmac.compare_digest(hashlib.sha256(a.encode()).digest(), hashlib.sha256(b.encode()).digest())


def authenticate(settings: Settings, username: str, password: str) -> CurrentUser | None:
    accounts: list[tuple[str, str, Role]] = [
        (settings.user_username, settings.user_password, "user"),
        (settings.admin_username, settings.admin_password, "admin"),
    ]
    username = username.strip()
    match: CurrentUser | None = None
    for name, expected, role in accounts:
        # Always run both comparisons; an empty configured password disables that account.
        ok = _safe_equal(password, expected) and bool(expected)
        if hmac.compare_digest(username.encode(), name.encode()) and ok:
            match = CurrentUser(username=name, role=role)
    return match


def issue_session(settings: Settings, response: Response, user: CurrentUser) -> None:
    exp = int(time.time()) + settings.session_hours * 3600
    payload = _b64(json.dumps({"u": user.username, "role": user.role, "exp": exp}, separators=(",", ":")).encode())
    sig = _b64(_sign(settings.session_secret, payload.encode()))
    response.set_cookie(
        COOKIE_NAME,
        f"{payload}.{sig}",
        max_age=settings.session_hours * 3600,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        path="/",
    )


def clear_session(settings: Settings, response: Response) -> None:
    response.delete_cookie(COOKIE_NAME, path="/", httponly=True, secure=settings.cookie_secure, samesite="lax")


def read_session(settings: Settings, raw: str | None) -> CurrentUser | None:
    if not raw or raw.count(".") != 1:
        return None
    payload, sig = raw.split(".")
    try:
        if not hmac.compare_digest(_unb64(sig), _sign(settings.session_secret, payload.encode())):
            return None
        data = json.loads(_unb64(payload))
    except (ValueError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict) or int(data.get("exp", 0)) <= time.time():
        return None
    if data.get("role") not in ("user", "admin") or not isinstance(data.get("u"), str):
        return None
    return CurrentUser(username=data["u"], role=data["role"])


# ---- FastAPI dependencies -------------------------------------------------------------------


def get_settings(request: Request) -> Settings:
    return request.app.state.settings


def current_user_optional(request: Request, settings: Settings = Depends(get_settings)) -> CurrentUser | None:
    return read_session(settings, request.cookies.get(COOKIE_NAME))


def require_session(user: CurrentUser | None = Depends(current_user_optional)) -> CurrentUser:
    if user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Please sign in again.")
    return user


def require_user(user: CurrentUser = Depends(require_session)) -> CurrentUser:
    if user.role != "user":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Not allowed.")
    return user


def require_admin(user: CurrentUser = Depends(require_session)) -> CurrentUser:
    if user.role != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Not allowed.")
    return user
