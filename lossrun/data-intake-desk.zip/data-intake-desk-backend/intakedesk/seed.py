"""Demo cases inserted into an empty database (SEED_DEMO_DATA=true)."""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy.orm import Session

from .db import is_empty
from .models import IntakeCase, utcnow


def seed_demo_data(db: Session) -> bool:
    if not is_empty(db):
        return False
    now = utcnow()
    db.add_all(
        [
            IntakeCase(
                title="Property policy – Terms & Conditions",
                description="Property policy documents; extract T&C clauses",
                data_elements="Policy number, insured name, effective date, exclusions, deductible, coverage limits",
                impact_type="growth",
                premium_growth=2_000_000,
                expected_accuracy=95,
                complexity="medium",
                priority_score=72,
                expected_days=5,
                status="completed",
                result_text=(
                    "Policy number: PP-2026-00412\nInsured: Harbor View Holdings LLC\nEffective date: 2026-01-01\n"
                    "Coverage limit: USD 12,500,000\nDeductible: USD 25,000\n"
                    "Exclusions: Flood, Earthquake, War & Terrorism\nTermination clause: 30 days written notice"
                ),
                satisfaction=4,
                created_by="intake_user",
                created_at=now - timedelta(days=12),
                completed_at=now - timedelta(days=7),
            ),
            IntakeCase(
                title="Motor claims FNOL forms",
                description="First notice of loss forms for motor claims",
                data_elements="Claim number, date of loss, vehicle plate, damage description",
                impact_type="efficiency",
                person_days=400,
                cost_per_day=300,
                expected_accuracy=92,
                complexity="easy",
                priority_score=64,
                expected_days=1,
                status="completed",
                result_text=(
                    "Claim number: MC-88213\nDate of loss: 2026-10-02\nVehicle plate: SH-A8827\n"
                    "Damage: Rear bumper and tail lamp"
                ),
                satisfaction=5,
                created_by="intake_user",
                created_at=now - timedelta(days=20),
                completed_at=now - timedelta(days=19),
            ),
            IntakeCase(
                title="Marine cargo survey reports",
                description="Survey reports with loss cause analysis",
                data_elements="Vessel, voyage, cause of loss, surveyor opinion",
                impact_type="profitability",
                loss_ratio_impact=1.5,
                lob="Marine",
                expected_accuracy=85,
                complexity="hard",
                priority_score=55,
                expected_days=14,
                meeting_suggested=True,
                status="in_progress",
                created_by="intake_user",
                created_at=now - timedelta(days=3),
            ),
        ]
    )
    db.commit()
    return True
