from __future__ import annotations

from ..config import Settings
from .base import FeedbackTriage, LLMError, LLMProvider, SampleScan
from .heuristic import HeuristicLLM

__all__ = ["FeedbackTriage", "LLMError", "LLMProvider", "SampleScan", "HeuristicLLM", "build_provider"]


def build_provider(settings: Settings) -> LLMProvider:
    if settings.llm_provider in ("", "heuristic", "none"):
        return HeuristicLLM()
    if settings.llm_provider == "openai_compatible":
        from .openai_compatible import OpenAICompatibleLLM

        return OpenAICompatibleLLM(settings)
    raise ValueError(f"Unknown LLM_PROVIDER: {settings.llm_provider!r}")
