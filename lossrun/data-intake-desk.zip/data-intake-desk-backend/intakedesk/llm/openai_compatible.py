"""Client for any OpenAI-compatible /chat/completions endpoint with JSON-schema output.

Configure with:
  LLM_PROVIDER=openai_compatible
  LLM_BASE_URL=https://<gateway>/v1            (".../openai/deployments/<name>" for Azure OpenAI)
  LLM_MODEL=<model or deployment name>
  LLM_API_KEY=<from the Secret>
  LLM_API_KEY_HEADER=Authorization             ("api-key" for Azure OpenAI; Authorization sends "Bearer <key>")
  LLM_API_VERSION=2024-10-21                   (optional, appended as ?api-version=)

PDF and text samples are sent as extracted text; images as a data URL (the model must accept images).
"""

from __future__ import annotations

import base64
import json
import logging
from typing import Any, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

from ..config import Settings
from ..documents import SampleDocument
from .base import (
    FEEDBACK_TRIAGE_INSTRUCTIONS,
    FEEDBACK_TRIAGE_SCHEMA,
    SAMPLE_SCAN_INSTRUCTIONS,
    SAMPLE_SCAN_SCHEMA,
    FeedbackTriage,
    LLMError,
    SampleScan,
)

log = logging.getLogger(__name__)
T = TypeVar("T", bound=BaseModel)


class OpenAICompatibleLLM:
    name = "openai_compatible"

    def __init__(self, settings: Settings) -> None:
        if not settings.llm_base_url or not settings.llm_model:
            raise ValueError("LLM_PROVIDER=openai_compatible needs LLM_BASE_URL and LLM_MODEL")
        self.s = settings
        headers = {"Content-Type": "application/json"}
        if settings.llm_api_key:
            if settings.llm_api_key_header.lower() == "authorization":
                headers["Authorization"] = f"Bearer {settings.llm_api_key}"
            else:
                headers[settings.llm_api_key_header] = settings.llm_api_key
        params = {"api-version": settings.llm_api_version} if settings.llm_api_version else None
        self.client = httpx.Client(
            base_url=settings.llm_base_url,
            headers=headers,
            params=params,
            timeout=httpx.Timeout(settings.llm_timeout_seconds, connect=10),
        )

    # ---- tasks ------------------------------------------------------------------------------

    def analyze_sample(self, description: str, data_elements: str, doc: SampleDocument) -> SampleScan:
        content: list[dict[str, Any]] = [
            {"type": "text", "text": f"Description: {description}\nData elements to extract: {data_elements}"}
        ]
        if doc.is_image:
            b64 = base64.b64encode(doc.data).decode()
            content.append({"type": "image_url", "image_url": {"url": f"data:{doc.content_type};base64,{b64}"}})
        elif doc.text:
            content.append({"type": "text", "text": f"File {doc.name}:\n{doc.text}"})
        else:
            content.append({"type": "text", "text": f"File {doc.name}: (no extractable text: scanned or protected file)"})
        return self._json(SAMPLE_SCAN_INSTRUCTIONS, content, "sample_scan", SAMPLE_SCAN_SCHEMA, SampleScan)

    def triage_feedback(self, title: str, data_elements: str, result_text: str, comment: str) -> FeedbackTriage:
        text = (
            f"Case: {title}\nRequested elements: {data_elements}\nCurrent result:\n{result_text}\n\n"
            f"User feedback: {comment}"
        )
        return self._json(
            FEEDBACK_TRIAGE_INSTRUCTIONS, [{"type": "text", "text": text}], "feedback_triage",
            FEEDBACK_TRIAGE_SCHEMA, FeedbackTriage,
        )

    # ---- transport --------------------------------------------------------------------------

    def _json(self, instructions: str, content: list[dict[str, Any]], name: str, schema: dict, model: type[T]) -> T:
        body = {
            "model": self.s.llm_model,
            "messages": [
                {"role": "system", "content": instructions},
                {"role": "user", "content": content},
            ],
            "response_format": {"type": "json_schema", "json_schema": {"name": name, "schema": schema, "strict": True}},
        }
        try:
            res = self.client.post("/chat/completions", json=body)
        except httpx.HTTPError as exc:
            log.error("LLM request failed: %s", exc)
            raise LLMError("The assistant could not respond right now.") from exc
        if res.status_code == 429:
            raise LLMError("The assistant is busy, please try again in a minute.")
        if res.status_code >= 400:
            log.error("LLM error %s: %s", res.status_code, res.text[:500])
            raise LLMError("The assistant could not respond right now.")
        try:
            raw = res.json()["choices"][0]["message"]["content"]
            return model.model_validate(json.loads(raw))
        except (KeyError, IndexError, TypeError, json.JSONDecodeError, ValidationError) as exc:
            log.error("Unexpected LLM response: %s", exc)
            raise LLMError("The assistant returned an unexpected answer.") from exc
