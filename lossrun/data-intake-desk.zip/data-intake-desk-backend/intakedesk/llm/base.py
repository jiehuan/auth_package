"""The two LLM tasks the app needs, behind one interface.

Providers:
  heuristic          rule-based, no network (default; what runs until the internal LLM API is ready)
  openai_compatible  any /chat/completions endpoint with JSON-schema output (internal gateway,
                     Azure OpenAI, ...), see openai_compatible.py

To plug in a different client, implement LLMProvider and register it in llm/__init__.py.
"""

from __future__ import annotations

from typing import Literal, Protocol

from pydantic import BaseModel, Field, field_validator

from ..documents import SampleDocument


class LLMError(RuntimeError):
    """User-presentable failure (message is shown in the UI)."""


class SampleScan(BaseModel):
    summary: str
    complexity: Literal["easy", "medium", "hard"]
    questions: list[str] = Field(default_factory=list)

    @field_validator("questions")
    @classmethod
    def _at_most_five(cls, v: list[str]) -> list[str]:
        return [q.strip() for q in v if q.strip()][:5]


class FeedbackTriage(BaseModel):
    difficulty: Literal["easy", "hard"]
    reply: str
    eta_hours: int = Field(ge=0)


class LLMProvider(Protocol):
    name: str

    def analyze_sample(self, description: str, data_elements: str, doc: SampleDocument) -> SampleScan:
        """Scan one sample document against the requested data elements."""
        ...

    def triage_feedback(self, title: str, data_elements: str, result_text: str, comment: str) -> FeedbackTriage:
        """Classify a returned case as an easy fix or a hard one, and draft the reply."""
        ...


SAMPLE_SCAN_INSTRUCTIONS = (
    "You are a data-intake analyst for an insurance company. Scan the sample document against the "
    "requested data elements. Identify elements that are ambiguous, missing or could match several "
    "fields, and ask the user for a concrete example for each (max 5 short questions, same language "
    "as the user's description). Rate extraction complexity as easy, medium or hard."
)

FEEDBACK_TRIAGE_INSTRUCTIONS = (
    "You triage feedback on an insurance document data-extraction result. 'easy' = small fixes "
    "(field format, a missed or mislabeled field, minor mapping). 'hard' = new document types, model "
    "accuracy problems, major redesign or unclear requirements. For easy, estimate eta_hours (2-48). "
    "Write a short friendly reply to the user in the same language as their feedback; for easy include "
    "the expected time and say they will be notified; for hard say the AI team will contact them to "
    "schedule a session."
)

SAMPLE_SCAN_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["summary", "complexity", "questions"],
    "properties": {
        "summary": {"type": "string"},
        "complexity": {"type": "string", "enum": ["easy", "medium", "hard"]},
        "questions": {"type": "array", "items": {"type": "string"}},
    },
}

FEEDBACK_TRIAGE_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["difficulty", "reply", "eta_hours"],
    "properties": {
        "difficulty": {"type": "string", "enum": ["easy", "hard"]},
        "reply": {"type": "string"},
        "eta_hours": {"type": "integer"},
    },
}
