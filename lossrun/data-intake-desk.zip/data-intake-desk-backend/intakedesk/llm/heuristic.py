"""Rule-based stand-in for the LLM. Deterministic, offline, good enough to run the workflow."""

from __future__ import annotations

import re

from ..documents import SampleDocument
from ..priority import split_elements
from .base import FeedbackTriage, SampleScan

_CJK = re.compile(r"[\u3400-\u9fff]")
_WORD = re.compile(r"[a-z0-9]+")
_GENERIC = {"date", "amount", "name", "number", "no", "id", "code", "type", "value", "total"}
_HARD_HINTS = (
    "new document", "new type", "different format", "another format", "accuracy", "all wrong",
    "completely wrong", "mostly wrong", "redesign", "doesn't work", "does not work", "unclear",
    "start over", "rethink",
    "新的文档", "新类型", "不同格式", "准确率", "全部错", "全错", "都错", "重新设计", "完全不对", "不清楚",
)


def _is_cjk(text: str) -> bool:
    return bool(_CJK.search(text))


def _found(element: str, text: str) -> bool:
    el = element.lower()
    if el in text:
        return True
    words = [w for w in _WORD.findall(el) if len(w) > 2 or w in {"no", "id"}]
    return bool(words) and all(w in text for w in words)


class HeuristicLLM:
    name = "heuristic"

    def analyze_sample(self, description: str, data_elements: str, doc: SampleDocument) -> SampleScan:
        elements = split_elements(data_elements)
        n = len(elements)
        zh = _is_cjk(description + data_elements)

        if doc.text is None:
            kind = "an image" if doc.is_image else "a scanned or protected file"
            summary = (
                f"{doc.name} 无法自动读取文字（图片或扫描件），AI 工程师会人工查看。"
                if zh
                else f"{doc.name} looks like {kind}, so its text can't be read automatically. "
                "An AI engineer will review it by hand."
            )
            questions = [
                (f"「{el}」在文档中的哪个位置？请给一个示例值。" if zh else f"Where does “{el}” appear, and what does a typical value look like?")
                for el in elements[:3]
            ]
            complexity = "hard" if n > 8 else "medium"
            return SampleScan(summary=summary, complexity=complexity, questions=questions)

        text = doc.text.lower()
        missing = [el for el in elements if not _found(el, text)]
        ambiguous = [
            el for el in elements
            if el not in missing and el.lower() in _GENERIC and text.count(el.lower()) > 1
        ]
        questions: list[str] = []
        for el in missing:
            questions.append(
                f"在 {doc.name} 中没有找到「{el}」的标签。它在文档中是怎样出现的？请给出标签和示例值。"
                if zh
                else f"I couldn't find a label for “{el}” in {doc.name}. How does it appear (label and an example value)?"
            )
        for el in ambiguous:
            cnt = text.count(el.lower())
            questions.append(
                f"「{el}」出现了 {cnt} 次，应该提取哪一个？" if zh else f"“{el}” appears {cnt} times. Which one should be captured?"
            )
        questions = questions[:5]

        pages = f"{doc.pages} page(s), " if doc.pages else ""
        found = n - len(missing)
        summary = (
            f"已读取 {doc.name}（{doc.pages or 1} 页）。请求的 {n} 个数据元素中找到了 {found} 个对应的标签。"
            if zh
            else f"Read {doc.name} ({pages}{len(doc.text):,} characters). Found labels for {found} of {n} requested data elements."
        )
        miss_ratio = len(missing) / n if n else 0
        if n > 12 or miss_ratio > 0.5:
            complexity = "hard"
        elif n > 5 or miss_ratio > 0.2 or ambiguous:
            complexity = "medium"
        else:
            complexity = "easy"
        return SampleScan(summary=summary, complexity=complexity, questions=questions)

    def triage_feedback(self, title: str, data_elements: str, result_text: str, comment: str) -> FeedbackTriage:
        c = comment.lower()
        zh = _is_cjk(comment)
        hard = any(h in c for h in _HARD_HINTS) or len(comment) > 1200
        if hard:
            reply = (
                "收到你的反馈。这个问题需要更深入地处理，AI 团队会联系你约时间一起过一遍细节。"
                if zh
                else "Thanks for the details. This needs a deeper look, so our AI team will contact you to schedule a session."
            )
            return FeedbackTriage(difficulty="hard", reply=reply, eta_hours=0)
        eta = 8 if len(comment) < 200 else 24
        reply = (
            f"收到，这看起来是一个小调整，预计 {eta} 小时内完成，完成后会在这里通知你。"
            if zh
            else f"Got it, this looks like a small fix. Expect an updated result within {eta} hours; you'll be notified here."
        )
        return FeedbackTriage(difficulty="easy", reply=reply, eta_hours=eta)
