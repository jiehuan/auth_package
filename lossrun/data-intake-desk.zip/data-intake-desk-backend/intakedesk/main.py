"""FastAPI application: Data Intake Desk API.

Run locally:  python -m uvicorn intakedesk.main:app --reload --port 8080
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from . import __version__, db
from .config import Settings, load_settings
from .llm import LLMError, build_provider
from .routers import admin, auth, cases, files
from .seed import seed_demo_data
from .storage import LocalStorage

log = logging.getLogger("intakedesk")

UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
CSRF_HEADER = "x-requested-with"


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        db.init_engine(settings.database_url)
        db.create_schema()
        if settings.seed_demo_data:
            with db.new_session() as s:
                if seed_demo_data(s):
                    log.info("Inserted demo cases into the empty database")
        app.state.storage = LocalStorage(settings.storage_dir)
        app.state.llm = build_provider(settings)
        accounts = [n for n, p in ((settings.user_username, settings.user_password), (settings.admin_username, settings.admin_password)) if p]
        if len(accounts) < 2:
            log.warning("Only %s account(s) have a password set: %s", len(accounts), accounts)
        log.info("Data Intake Desk API %s ready (llm=%s)", __version__, app.state.llm.name)
        yield

    app = FastAPI(
        title="Data Intake Desk API",
        version=__version__,
        lifespan=lifespan,
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
        redoc_url=None,
    )
    app.state.settings = settings

    @app.middleware("http")
    async def csrf_guard(request: Request, call_next):
        # Cookies are SameSite=Lax; additionally require a custom header on state-changing API
        # calls. Browsers can't send it cross-site without a CORS preflight, which we never allow.
        if request.method in UNSAFE_METHODS and request.url.path.startswith("/api/") and not request.headers.get(CSRF_HEADER):
            return JSONResponse({"detail": "Missing X-Requested-With header."}, status_code=403)
        response = await call_next(request)
        if request.url.path.startswith("/api/"):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    @app.exception_handler(LLMError)
    async def llm_error(_: Request, exc: LLMError) -> JSONResponse:
        return JSONResponse({"detail": str(exc)}, status_code=503)

    @app.get("/healthz", include_in_schema=False)
    def healthz() -> dict:
        return {"status": "ok"}

    @app.get("/readyz", include_in_schema=False)
    def readyz() -> JSONResponse:
        try:
            db.ping()
        except Exception as exc:  # pragma: no cover - only when the DB is down
            log.error("Readiness check failed: %s", exc)
            return JSONResponse({"status": "unavailable"}, status_code=503)
        return JSONResponse({"status": "ok"})

    app.include_router(auth.router)
    app.include_router(cases.router)
    app.include_router(admin.router)
    app.include_router(files.router)
    return app


app = create_app()
