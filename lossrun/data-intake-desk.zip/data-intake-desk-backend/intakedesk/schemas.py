"""Request and response models. Field names match the database columns (snake_case)."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, PlainSerializer


def _iso_utc(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


UtcDateTime = Annotated[datetime, PlainSerializer(_iso_utc, return_type=str)]


class Orm(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---- auth -----------------------------------------------------------------------------------


class LoginIn(BaseModel):
    username: str = Field(max_length=100)
    password: str = Field(max_length=200)


class UserOut(BaseModel):
    username: str
    role: Literal["user", "admin"]


class MeOut(BaseModel):
    user: UserOut | None


# ---- cases ----------------------------------------------------------------------------------


class CaseOut(Orm):
    id: str
    title: str
    description: str
    data_elements: str
    analysis_mode: str
    ai_questions: list[str]
    user_examples: str
    impact_type: str
    premium_growth: float
    person_days: float
    cost_per_day: float
    loss_ratio_impact: float
    lob: str
    expected_accuracy: float
    complexity: str
    priority_score: int
    expected_days: int
    meeting_suggested: bool
    status: str
    result_text: str
    satisfaction: int | None
    created_by: str
    created_at: UtcDateTime
    completed_at: UtcDateTime | None


class FileOut(Orm):
    id: str
    case_id: str
    file_name: str
    content_type: str
    size_bytes: int
    created_at: UtcDateTime
    url: str


class FeedbackOut(Orm):
    id: str
    case_id: str
    comment: str
    wants_engineer: bool
    difficulty: str
    bot_reply: str
    eta_hours: int | None
    created_at: UtcDateTime


class CaseDetailOut(BaseModel):
    case: CaseOut
    files: list[FileOut]
    feedback: list[FeedbackOut]


class CreateCaseIn(BaseModel):
    """JSON sent in the `payload` form field of POST /api/cases (files go in `files`)."""

    title: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=5000)
    data_elements: str = Field(min_length=1, max_length=5000)
    analysis_mode: Literal["immediate", "fast"]
    ai_questions: list[str] = Field(default_factory=list, max_length=10)
    user_examples: str = Field(default="", max_length=5000)
    ai_complexity: Literal["easy", "medium", "hard"] | None = None
    impact_type: Literal["growth", "efficiency", "profitability"]
    premium_growth: float = Field(default=0, ge=0)
    person_days: float = Field(default=0, ge=0)
    cost_per_day: float = Field(default=0, ge=0)
    loss_ratio_impact: float = Field(default=0, ge=0, le=100)
    lob: str = Field(default="", max_length=50)
    expected_accuracy: float


class CreateCaseOut(BaseModel):
    id: str
    complexity: str
    expected_days: int
    meeting_suggested: bool
    priority_score: int


class SampleScanOut(BaseModel):
    summary: str
    complexity: Literal["easy", "medium", "hard"]
    questions: list[str]


class ReturnIn(BaseModel):
    comment: str = Field(min_length=1, max_length=3000)
    wants_engineer: bool = False


class ReturnOut(BaseModel):
    difficulty: Literal["easy", "hard"]
    reply: str
    eta_hours: int | None


class RatingIn(BaseModel):
    satisfaction: int = Field(ge=1, le=5)


class CompleteIn(BaseModel):
    result_text: str = Field(min_length=1, max_length=50_000)


class AdminOverviewOut(BaseModel):
    cases: list[CaseOut]
    feedback: list[FeedbackOut]


class OkOut(BaseModel):
    ok: bool = True
