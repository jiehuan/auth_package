"""Engine, sessions and schema bootstrap."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from sqlalchemy import create_engine, event, select, text
from sqlalchemy.engine import Engine, make_url
from sqlalchemy.orm import Session, sessionmaker

from .models import Base, IntakeCase

_engine: Engine | None = None
_SessionLocal: sessionmaker[Session] | None = None


def init_engine(database_url: str) -> Engine:
    global _engine, _SessionLocal
    url = make_url(database_url)
    kwargs: dict = {"pool_pre_ping": True}
    is_sqlite = url.get_backend_name() == "sqlite"
    if is_sqlite:
        if url.database and url.database != ":memory:":
            Path(url.database).parent.mkdir(parents=True, exist_ok=True)
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}

    engine = create_engine(url, **kwargs)

    if is_sqlite:

        @event.listens_for(engine, "connect")
        def _sqlite_pragmas(dbapi_conn, _record):  # noqa: ANN001
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.close()

    _engine = engine
    _SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
    return engine


def create_schema() -> None:
    # Fine for SQLite. When moving to Azure SQL, switch to Alembic migrations generated from models.py.
    assert _engine is not None
    Base.metadata.create_all(_engine)


def get_db() -> Iterator[Session]:
    assert _SessionLocal is not None, "init_engine() was not called"
    db = _SessionLocal()
    try:
        yield db
    finally:
        db.close()


def new_session() -> Session:
    assert _SessionLocal is not None
    return _SessionLocal()


def ping() -> None:
    assert _engine is not None
    with _engine.connect() as conn:
        conn.execute(text("SELECT 1"))


def is_empty(db: Session) -> bool:
    return db.execute(select(IntakeCase.id).limit(1)).first() is None
