"""Settings, read once from environment variables (ConfigMap + Secret on OpenShift)."""

from __future__ import annotations

import logging
import os
import secrets
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    return int(raw) if raw else default


@dataclass(frozen=True)
class Settings:
    # Database. SQLite now; an Azure SQL URL (mssql+pyodbc://...) later.
    database_url: str = "sqlite:///./data/intake.db"
    # Uploaded sample files live here (the PVC on OpenShift).
    storage_dir: Path = Path("./data/files")
    # Insert the three demo cases when the database is empty.
    seed_demo_data: bool = True

    # Sessions: HMAC-signed httpOnly cookie.
    session_secret: str = field(default="", repr=False)
    session_hours: int = 12
    cookie_secure: bool = True

    # The two fixed accounts. Passwords come from the Secret; an empty password disables the account.
    user_username: str = "intake_user"
    user_password: str = field(default="", repr=False)
    admin_username: str = "intake_admin"
    admin_password: str = field(default="", repr=False)

    # Uploads
    max_files: int = 5
    max_file_mb: int = 20

    # LLM: "heuristic" (default, no external calls) or "openai_compatible".
    llm_provider: str = "heuristic"
    llm_base_url: str = ""
    llm_api_key: str = field(default="", repr=False)
    llm_api_key_header: str = "Authorization"  # "api-key" for Azure OpenAI style gateways
    llm_api_version: str = ""  # appended as ?api-version=... when set
    llm_model: str = ""
    llm_timeout_seconds: int = 120

    log_level: str = "INFO"

    @property
    def max_file_bytes(self) -> int:
        return self.max_file_mb * 1024 * 1024


def load_settings() -> Settings:
    secret = os.environ.get("SESSION_SECRET", "").strip()
    if not secret:
        secret = secrets.token_urlsafe(48)
        log.warning("SESSION_SECRET is not set: using a random secret; sessions end when the pod restarts.")
    return Settings(
        database_url=os.environ.get("DATABASE_URL", Settings.database_url).strip(),
        storage_dir=Path(os.environ.get("STORAGE_DIR", str(Settings.storage_dir)).strip()),
        seed_demo_data=_bool("SEED_DEMO_DATA", True),
        session_secret=secret,
        session_hours=_int("SESSION_HOURS", 12),
        cookie_secure=_bool("COOKIE_SECURE", True),
        user_username=os.environ.get("INTAKE_USER_USERNAME", "intake_user").strip(),
        user_password=os.environ.get("INTAKE_USER_PASSWORD", ""),
        admin_username=os.environ.get("INTAKE_ADMIN_USERNAME", "intake_admin").strip(),
        admin_password=os.environ.get("INTAKE_ADMIN_PASSWORD", ""),
        max_files=_int("MAX_FILES", 5),
        max_file_mb=_int("MAX_FILE_MB", 20),
        llm_provider=os.environ.get("LLM_PROVIDER", "heuristic").strip().lower(),
        llm_base_url=os.environ.get("LLM_BASE_URL", "").strip().rstrip("/"),
        llm_api_key=os.environ.get("LLM_API_KEY", "").strip(),
        llm_api_key_header=os.environ.get("LLM_API_KEY_HEADER", "Authorization").strip(),
        llm_api_version=os.environ.get("LLM_API_VERSION", "").strip(),
        llm_model=os.environ.get("LLM_MODEL", "").strip(),
        llm_timeout_seconds=_int("LLM_TIMEOUT_SECONDS", 120),
        log_level=os.environ.get("LOG_LEVEL", "INFO").strip().upper(),
    )
