from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from intakedesk.config import Settings
from intakedesk.main import create_app

H = {"X-Requested-With": "XMLHttpRequest"}


@pytest.fixture()
def settings(tmp_path: Path) -> Settings:
    return Settings(
        database_url=f"sqlite:///{tmp_path / 'test.db'}",
        storage_dir=tmp_path / "files",
        seed_demo_data=True,
        session_secret="test-secret",
        cookie_secure=False,
        user_password="user-pass",
        admin_password="admin-pass",
    )


@pytest.fixture()
def client(settings: Settings):
    with TestClient(create_app(settings)) as c:
        yield c


def login(client: TestClient, username: str, password: str) -> None:
    r = client.post("/api/auth/login", json={"username": username, "password": password}, headers=H)
    assert r.status_code == 200, r.text


@pytest.fixture()
def user_client(client: TestClient) -> TestClient:
    login(client, "intake_user", "user-pass")
    return client


@pytest.fixture()
def admin_client(client: TestClient) -> TestClient:
    login(client, "intake_admin", "admin-pass")
    return client
