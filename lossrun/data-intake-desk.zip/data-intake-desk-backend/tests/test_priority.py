from intakedesk.priority import (
    annual_benefit,
    expected_days,
    heuristic_complexity,
    is_valid_accuracy,
    priority_score,
    split_elements,
    suggest_meeting,
)


def test_efficiency_benefit():
    assert annual_benefit("efficiency", person_days=400, cost_per_day=300) == 120_000


def test_growth_and_profitability_benefit():
    assert annual_benefit("growth", premium_growth=2_000_000) == 200_000
    assert annual_benefit("profitability", loss_ratio_impact=1.5, lob="Marine") == 300_000
    assert annual_benefit("profitability", loss_ratio_impact=1, lob="Unknown") == 100_000


def test_accuracy_must_be_below_100():
    assert not is_valid_accuracy(100)
    assert not is_valid_accuracy(0)
    assert is_valid_accuracy(99.5)


def test_priority_score_log_scale():
    assert priority_score(0) == 0
    assert priority_score(10_000) == 20
    assert priority_score(1_000_000) == 60
    assert priority_score(10**12) == 100


def test_return_window_bounds():
    assert expected_days("easy", 100, 80) == 1
    assert expected_days("hard", 0, 99) == 14


def test_meeting_for_hard_cases():
    assert suggest_meeting("hard", 90)
    assert not suggest_meeting("easy", 90)
    assert suggest_meeting("easy", 98)


def test_elements_split_on_cjk_separators():
    assert split_elements("保单号，被保险人、生效日期\nlimit") == ["保单号", "被保险人", "生效日期", "limit"]
    assert heuristic_complexity("a, b", 90) == "easy"
    assert heuristic_complexity("a,b,c,d,e,f", 90) == "medium"
    assert heuristic_complexity("a", 97) == "hard"
