from __future__ import annotations

import json

from conftest import H, login

CASE = {
    "title": "Cyber proposal forms",
    "description": "Broker proposal forms",
    "data_elements": "Insured name, revenue, policy number",
    "analysis_mode": "immediate",
    "ai_questions": ["Which revenue?"],
    "user_examples": "Q: Which revenue?\nA: Last FY",
    "ai_complexity": None,
    "impact_type": "efficiency",
    "premium_growth": 0,
    "person_days": 200,
    "cost_per_day": 500,
    "loss_ratio_impact": 0,
    "lob": "",
    "expected_accuracy": 95,
}
SAMPLE = b"Proposal form\nInsured name: Acme Ltd\nAnnual revenue: 10m\n"


def test_health(client):
    assert client.get("/healthz").json() == {"status": "ok"}
    assert client.get("/readyz").status_code == 200


def test_login_flow(client):
    assert client.get("/api/auth/me").json() == {"user": None}
    r = client.post("/api/auth/login", json={"username": "intake_user", "password": "nope"}, headers=H)
    assert r.status_code == 401
    login(client, "intake_user", "user-pass")
    assert client.get("/api/auth/me").json() == {"user": {"username": "intake_user", "role": "user"}}
    client.post("/api/auth/logout", headers=H)
    assert client.get("/api/auth/me").json() == {"user": None}


def test_tampered_cookie_rejected(user_client):
    raw = user_client.cookies.get("intake_session")
    payload, sig = raw.split(".")
    user_client.cookies.set("intake_session", payload + "." + sig[:-2] + "AA")
    assert user_client.get("/api/auth/me").json() == {"user": None}


def test_csrf_header_required(client):
    r = client.post("/api/auth/login", json={"username": "intake_user", "password": "user-pass"})
    assert r.status_code == 403


def test_requires_session(client):
    assert client.get("/api/cases").status_code == 401


def test_seeded_cases(user_client):
    cases = user_client.get("/api/cases").json()
    assert len(cases) == 3
    assert cases[0]["title"] == "Marine cargo survey reports"  # newest first
    assert cases[0]["created_at"].endswith("Z")


def test_analyze_sample_heuristic(user_client):
    r = user_client.post(
        "/api/cases/analyze-sample",
        data={"description": "Proposal forms", "data_elements": CASE["data_elements"]},
        files={"file": ("sample.txt", SAMPLE, "text/plain")},
        headers=H,
    )
    assert r.status_code == 200, r.text
    scan = r.json()
    assert scan["complexity"] in {"easy", "medium", "hard"}
    assert any("policy number" in q.lower() for q in scan["questions"])


def test_rejects_unsupported_type(user_client):
    r = user_client.post(
        "/api/cases/analyze-sample",
        data={"data_elements": "x"},
        files={"file": ("macro.exe", b"MZ", "application/octet-stream")},
        headers=H,
    )
    assert r.status_code == 415


def test_full_case_lifecycle(client):
    login(client, "intake_user", "user-pass")
    r = client.post(
        "/api/cases",
        data={"payload": json.dumps(CASE)},
        files=[("files", ("sample.txt", SAMPLE, "text/plain")), ("files", ("form.pdf", b"%PDF-1.4 broken", "application/pdf"))],
        headers=H,
    )
    assert r.status_code == 201, r.text
    created = r.json()
    assert created["priority_score"] == 40  # $100k/yr
    assert created["complexity"] == "easy"
    case_id = created["id"]

    detail = client.get(f"/api/cases/{case_id}").json()
    assert detail["case"]["created_by"] == "intake_user"
    assert [f["file_name"] for f in detail["files"]] == ["sample.txt", "form.pdf"]
    dl = client.get(detail["files"][0]["url"])
    assert dl.status_code == 200 and dl.content == SAMPLE
    assert "attachment" in dl.headers["content-disposition"]

    # requester cannot publish
    assert client.post(f"/api/admin/cases/{case_id}/complete", json={"result_text": "x"}, headers=H).status_code == 403

    login(client, "intake_admin", "admin-pass")
    assert client.get("/api/cases").status_code == 200
    r = client.post(f"/api/admin/cases/{case_id}/complete", json={"result_text": "Insured: Acme"}, headers=H)
    assert r.status_code == 200
    overview = client.get("/api/admin/overview").json()
    assert len(overview["cases"]) == 4

    login(client, "intake_user", "user-pass")
    assert client.post(f"/api/cases/{case_id}/rating", json={"satisfaction": 4}, headers=H).status_code == 200
    r = client.post(f"/api/cases/{case_id}/return", json={"comment": "Date format should be ISO", "wants_engineer": False}, headers=H)
    assert r.status_code == 200
    assert r.json()["difficulty"] == "easy" and r.json()["eta_hours"]
    r = client.post(f"/api/cases/{case_id}/return", json={"comment": "准确率太低，全部错了", "wants_engineer": False}, headers=H)
    assert r.json()["difficulty"] == "hard"
    assert "AI 团队" in r.json()["reply"]

    detail = client.get(f"/api/cases/{case_id}").json()
    assert detail["case"]["status"] == "engineer_review"
    assert detail["case"]["completed_at"] is None
    assert len(detail["feedback"]) == 2


def test_invalid_accuracy_rejected(user_client):
    bad = {**CASE, "expected_accuracy": 100}
    r = user_client.post(
        "/api/cases", data={"payload": json.dumps(bad)}, files=[("files", ("a.txt", b"x", "text/plain"))], headers=H
    )
    assert r.status_code == 422


def test_case_not_found(user_client):
    assert user_client.get("/api/cases/does-not-exist").status_code == 404
