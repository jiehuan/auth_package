from __future__ import annotations

import json

import httpx
import pytest

from intakedesk.config import Settings
from intakedesk.documents import load
from intakedesk.llm import LLMError, build_provider
from intakedesk.llm.heuristic import HeuristicLLM
from intakedesk.llm.openai_compatible import OpenAICompatibleLLM


def _provider(handler) -> OpenAICompatibleLLM:
    s = Settings(
        llm_provider="openai_compatible", llm_base_url="https://llm.example/v1", llm_model="m",
        llm_api_key="k", llm_api_key_header="api-key", llm_api_version="2024-10-21",
    )
    p = build_provider(s)
    assert isinstance(p, OpenAICompatibleLLM)
    p.client._transport = httpx.MockTransport(handler)
    return p


def test_openai_compatible_sample_scan():
    seen = {}

    def handler(req: httpx.Request) -> httpx.Response:
        seen["url"] = str(req.url)
        seen["key"] = req.headers.get("api-key")
        seen["body"] = json.loads(req.content)
        content = json.dumps({"summary": "ok", "complexity": "medium", "questions": ["q1"] * 7})
        return httpx.Response(200, json={"choices": [{"message": {"content": content}}]})

    scan = _provider(handler).analyze_sample("d", "a, b", load("s.txt", "text/plain", b"hello"))
    assert scan.complexity == "medium" and len(scan.questions) == 5
    assert seen["url"] == "https://llm.example/v1/chat/completions?api-version=2024-10-21"
    assert seen["key"] == "k"
    assert seen["body"]["response_format"]["json_schema"]["name"] == "sample_scan"


def test_openai_compatible_errors():
    p = _provider(lambda req: httpx.Response(429))
    with pytest.raises(LLMError, match="busy"):
        p.triage_feedback("t", "e", "r", "c")
    p = _provider(lambda req: httpx.Response(200, json={"choices": [{"message": {"content": "not json"}}]}))
    with pytest.raises(LLMError):
        p.triage_feedback("t", "e", "r", "c")


def test_heuristic_image_sample():
    scan = HeuristicLLM().analyze_sample("forms", "a, b, c, d", load("scan.png", "image/png", b"\x89PNG"))
    assert scan.complexity == "medium"
    assert len(scan.questions) == 3


def test_unknown_provider():
    with pytest.raises(ValueError):
        build_provider(Settings(llm_provider="magic"))
