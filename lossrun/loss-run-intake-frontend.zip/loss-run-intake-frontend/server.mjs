// Production server for the SPA (zero dependencies, Node >= 22).
//   - serves the Vite build in ./dist with SPA fallback to index.html
//   - reverse-proxies /api/* to the backend Service (streaming, so large uploads are not buffered)
// Env: PORT (8080), BACKEND_URL (http://loss-run-intake-api:8080), PROXY_TIMEOUT_MS (300000)
import http from "node:http";
import https from "node:https";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const PORT = Number(process.env.PORT ?? 8080);
const BACKEND = new URL(process.env.BACKEND_URL ?? "http://loss-run-intake-api:8080");
const PROXY_TIMEOUT_MS = Number(process.env.PROXY_TIMEOUT_MS ?? 300_000);
const DIST = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "dist");

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".json": "application/json",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
};

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  // SAMEORIGIN (not DENY): MSAL silent token renewal loads this origin in a hidden iframe
  "X-Frame-Options": "SAMEORIGIN",
};

const HOP_BY_HOP = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
]);

function log(...args) {
  console.log(new Date().toISOString(), ...args);
}

function sendJson(res, status, body) {
  if (res.headersSent) return res.destroy();
  res.writeHead(status, { "Content-Type": "application/json", ...SECURITY_HEADERS });
  res.end(JSON.stringify(body));
}

// ------------------------------------------------------------------ /api proxy
function proxy(req, res) {
  const client = BACKEND.protocol === "https:" ? https : http;
  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (!HOP_BY_HOP.has(k.toLowerCase())) headers[k] = v;
  }
  const remote = req.socket.remoteAddress ?? "";
  headers["x-forwarded-for"] = req.headers["x-forwarded-for"]
    ? `${req.headers["x-forwarded-for"]}, ${remote}`
    : remote;
  headers["x-forwarded-proto"] = req.headers["x-forwarded-proto"] ?? "http";
  headers["x-forwarded-host"] = req.headers["x-forwarded-host"] ?? req.headers.host ?? "";
  headers.host = BACKEND.host;

  const upstream = client.request(
    {
      protocol: BACKEND.protocol,
      hostname: BACKEND.hostname,
      port: BACKEND.port || (BACKEND.protocol === "https:" ? 443 : 80),
      method: req.method,
      path: req.url,
      headers,
      timeout: PROXY_TIMEOUT_MS,
    },
    (up) => {
      const out = {};
      for (const [k, v] of Object.entries(up.headers)) {
        if (!HOP_BY_HOP.has(k.toLowerCase())) out[k] = v;
      }
      res.writeHead(up.statusCode ?? 502, out);
      up.pipe(res);
    },
  );
  upstream.on("timeout", () => upstream.destroy(new Error("upstream timeout")));
  upstream.on("error", (err) => {
    log("proxy error", req.method, req.url, err.message);
    sendJson(res, err.message === "upstream timeout" ? 504 : 502, {
      detail: "Backend unavailable",
    });
  });
  req.on("aborted", () => upstream.destroy());
  req.pipe(upstream);
}

// ------------------------------------------------------------------ static files
async function fileFor(urlPath) {
  let decoded;
  try {
    decoded = decodeURIComponent(urlPath);
  } catch {
    return null;
  }
  const full = path.resolve(DIST, "." + decoded);
  if (full !== DIST && !full.startsWith(DIST + path.sep)) return null; // path traversal
  try {
    const s = await stat(full);
    return s.isFile() ? { full, size: s.size } : null;
  } catch {
    return null;
  }
}

async function serveStatic(req, res, pathname) {
  if (req.method !== "GET" && req.method !== "HEAD") {
    return sendJson(res, 405, { detail: "Method Not Allowed" });
  }
  let file = await fileFor(pathname);
  const isAsset = pathname.startsWith("/assets/");
  if (!file) {
    if (isAsset || path.extname(pathname)) return sendJson(res, 404, { detail: "Not Found" });
    file = await fileFor("/index.html"); // SPA route
    if (!file) return sendJson(res, 500, { detail: "index.html missing — was the app built?" });
  }
  const ext = path.extname(file.full);
  res.writeHead(200, {
    "Content-Type": TYPES[ext] ?? "application/octet-stream",
    "Content-Length": file.size,
    // hashed assets never change; index.html must always be revalidated
    "Cache-Control": isAsset ? "public, max-age=31536000, immutable" : "no-cache",
    ...SECURITY_HEADERS,
  });
  if (req.method === "HEAD") return res.end();
  createReadStream(file.full).pipe(res);
}

// ------------------------------------------------------------------ server
const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url ?? "/", "http://localhost").pathname;
  try {
    if (pathname === "/healthz") return sendJson(res, 200, { status: "ok" });
    if (pathname === "/api" || pathname.startsWith("/api/")) return proxy(req, res);
    await serveStatic(req, res, pathname);
  } catch (err) {
    log("error", req.method, req.url, err);
    sendJson(res, 500, { detail: "Internal server error" });
  }
});
server.requestTimeout = 0; // uploads are bounded by PROXY_TIMEOUT_MS instead
server.headersTimeout = 60_000;
server.keepAliveTimeout = 65_000;

server.listen(PORT, () => log(`listening on :${PORT}, /api -> ${BACKEND.origin}`));

for (const sig of ["SIGTERM", "SIGINT"]) {
  process.on(sig, () => {
    log(`${sig} received, closing`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 10_000).unref();
  });
}
