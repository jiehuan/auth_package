// Typed client for the Python BFF (/api). In Entra mode every request carries a bearer
// access token (see lib/auth.ts); in dev/header mode identity is resolved server-side.
import { getAccessToken } from "./auth";

export type FieldType = "string" | "number" | "date" | "boolean";

export type TemplateField = {
  key: string;
  label: string;
  type?: FieldType;
  required: boolean;
  hint: string;
  value?: string;
};

export type Lob = { id: string; name: string; slug: string };

export type Me = {
  id: string;
  email: string;
  display_name: string | null;
  roles: string[];
  is_admin: boolean;
};

export type TeamUser = Me & { is_active: boolean; created_at: string; last_seen_at: string | null };

export type Client = { id: string; name: string; created_at: string };

export type TemplateLabel = "System" | "Custom" | "Carrier";

export type Template = {
  id: string;
  name: string;
  lob_id: string;
  lob: Lob | null;
  fields: TemplateField[];
  is_golden: boolean;
  is_system: boolean;
  label: TemplateLabel;
  owner_user_id: string | null;
  can_edit: boolean;
  created_at: string;
  updated_at: string;
};

export type JobStatus = "queued" | "extracting" | "reconciling" | "ready" | "error";

export type Job = {
  id: string;
  name: string;
  user_id: string;
  status: JobStatus;
  status_message: string | null;
  source_files: { name: string; size: number; type: string }[];
  client: { id: string; name: string } | null;
  template: { id: string; name: string; fields?: TemplateField[] } | null;
  lob: Lob | null;
  attempts: number;
  created_at: string;
  completed_at: string | null;
};

export type ExtractionRow = {
  id: string;
  row_index: number;
  source_file: string | null;
  data: Record<string, unknown>;
  included_in_export: boolean;
};

export type Issue = {
  id: string;
  row_id: string | null;
  severity: "info" | "warning" | "error";
  code: string;
  field: string | null;
  message: string;
};

export type JobDetail = { job: Job; rows: ExtractionRow[]; issues: Issue[] };

export type TemplateSource = {
  path: string;
  name: string;
  type: string;
  pages: string[];
  recommended_page: string;
  reason: string;
};

export type InferredField = TemplateField & { value: string };

export const ACTIVE_STATUSES: JobStatus[] = ["queued", "extracting", "reconciling"];

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  const token = await getAccessToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (init.body && !(init.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const res = await fetch(`/api${path}`, { credentials: "same-origin", ...init, headers });
  if (!res.ok) {
    let message = `${res.status} ${res.statusText}`;
    try {
      const body = await res.json();
      if (typeof body?.detail === "string") message = body.detail;
      else if (Array.isArray(body?.detail))
        message = body.detail.map((d: { msg?: string }) => d.msg).join("; ");
    } catch {
      /* not JSON */
    }
    throw new ApiError(message, res.status);
  }
  const ct = res.headers.get("content-type") ?? "";
  return (ct.includes("application/json") ? res.json() : res.blob()) as Promise<T>;
}

const json = (body: unknown) => JSON.stringify(body);

export const api = {
  me: () => request<Me>("/me"),
  lobs: () => request<Lob[]>("/lobs"),
  clients: () => request<Client[]>("/clients"),

  templates: () => request<Template[]>("/templates"),
  template: (id: string) => request<Template>(`/templates/${id}`),
  createTemplate: (body: {
    name: string;
    lob_id: string;
    fields: TemplateField[];
    source_file_path?: string;
    label?: TemplateLabel;
  }) => request<Template>("/templates", { method: "POST", body: json(body) }),
  updateTemplate: (id: string, body: { name?: string; fields?: TemplateField[] }) =>
    request<Template>(`/templates/${id}`, { method: "PATCH", body: json(body) }),
  copyTemplate: (id: string) => request<Template>(`/templates/${id}/copy`, { method: "POST" }),
  setTemplateLabel: (id: string, label: TemplateLabel) =>
    request<{ ok: true }>(`/templates/${id}/label`, { method: "PUT", body: json({ label }) }),
  deleteTemplate: (id: string) => request<{ ok: true }>(`/templates/${id}`, { method: "DELETE" }),

  uploadTemplateSource: (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<TemplateSource>("/template-sources", { method: "POST", body: fd });
  },
  previewTemplateSource: (p: { path: string; name: string; page: string }) =>
    request<{ rows: string[][]; total_rows: number }>(
      `/template-sources/preview?${new URLSearchParams(p).toString()}`,
    ),
  inferFields: (body: { path: string; name: string; type: string; page: string }) =>
    request<{ fields: InferredField[] }>("/template-sources/infer", {
      method: "POST",
      body: json(body),
    }),

  jobs: () => request<Job[]>("/jobs"),
  job: (id: string) => request<JobDetail>(`/jobs/${id}`),
  createJob: (p: { carrier_name: string; lob_id: string; template_id: string; files: File[] }) => {
    const fd = new FormData();
    fd.append("carrier_name", p.carrier_name);
    fd.append("lob_id", p.lob_id);
    fd.append("template_id", p.template_id);
    for (const f of p.files) fd.append("files", f, f.name);
    return request<Job>("/jobs", { method: "POST", body: fd });
  },
  rerunJob: (id: string) => request<Job>(`/jobs/${id}/run`, { method: "POST" }),
  reconcileJob: (id: string) =>
    request<{ ok: true; issues: number }>(`/jobs/${id}/reconcile`, { method: "POST" }),
  updateRow: (jobId: string, rowId: string, body: { included_in_export?: boolean; data?: object }) =>
    request<ExtractionRow>(`/jobs/${jobId}/rows/${rowId}`, { method: "PATCH", body: json(body) }),
  setAllIncluded: (jobId: string, included: boolean) =>
    request<{ ok: true }>(`/jobs/${jobId}/rows/include`, {
      method: "POST",
      body: json({ included }),
    }),
  exportJob: (jobId: string, selected_fields: string[]) =>
    request<Blob>(`/jobs/${jobId}/export`, { method: "POST", body: json({ selected_fields }) }),
  deleteJob: (id: string) => request<{ ok: true }>(`/jobs/${id}`, { method: "DELETE" }),

  team: () => request<TeamUser[]>("/admin/users"),
  addMember: (body: { email: string; display_name?: string }) =>
    request<TeamUser>("/admin/users", { method: "POST", body: json(body) }),
  setRole: (userId: string, role: "admin" | "member", grant: boolean) =>
    request<{ ok: true }>(`/admin/users/${userId}/roles`, {
      method: "PUT",
      body: json({ role, grant }),
    }),
  seedDemo: () =>
    request<{ ok: true; skipped: boolean; jobs?: number; clients?: number }>("/admin/demo/seed", {
      method: "POST",
    }),
};

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function errorMessage(e: unknown, fallback = "Something went wrong") {
  return e instanceof Error ? e.message : fallback;
}
