// Authentication bootstrap. The BFF tells the SPA which mode it runs in (GET /api/config):
//   dev / header -> nothing to do here (identity is resolved server-side)
//   entra        -> sign in with Microsoft Entra ID (MSAL redirect flow) and attach a bearer
//                   access token for the BFF's API scope to every /api request.
import type { PublicClientApplication } from "@azure/msal-browser";

type RuntimeConfig = {
  auth_mode: "dev" | "header" | "entra";
  entra?: { client_id: string; authority: string; scopes: string[] };
};

let msal: PublicClientApplication | null = null;
let scopes: string[] = [];

export async function initAuth(): Promise<void> {
  const res = await fetch("/api/config", { credentials: "same-origin" });
  if (!res.ok) throw new Error(`Could not load app configuration (${res.status})`);
  const cfg = (await res.json()) as RuntimeConfig;
  if (cfg.auth_mode !== "entra" || !cfg.entra) return;

  // Loaded lazily so dev/header deployments never download MSAL.
  const { PublicClientApplication } = await import("@azure/msal-browser");
  scopes = cfg.entra.scopes;
  msal = new PublicClientApplication({
    auth: {
      clientId: cfg.entra.client_id,
      authority: cfg.entra.authority,
      redirectUri: `${window.location.origin}/`,
      postLogoutRedirectUri: `${window.location.origin}/`,
      navigateToLoginRequestUrl: true,
    },
    cache: { cacheLocation: "sessionStorage" },
  });
  await msal.initialize();

  const result = await msal.handleRedirectPromise();
  if (result?.account) msal.setActiveAccount(result.account);
  if (!msal.getActiveAccount()) {
    const accounts = msal.getAllAccounts();
    if (accounts.length > 0) msal.setActiveAccount(accounts[0]);
  }
  if (!msal.getActiveAccount()) {
    await msal.loginRedirect({ scopes, redirectStartPage: window.location.href });
    await new Promise(() => {}); // the browser is navigating to the sign-in page
  }
}

export async function getAccessToken(): Promise<string | null> {
  if (!msal) return null;
  const account = msal.getActiveAccount() ?? undefined;
  const { InteractionRequiredAuthError } = await import("@azure/msal-browser");
  try {
    const r = await msal.acquireTokenSilent({ scopes, account });
    return r.accessToken;
  } catch (e) {
    if (e instanceof InteractionRequiredAuthError) {
      await msal.acquireTokenRedirect({ scopes, account, redirectStartPage: window.location.href });
      await new Promise(() => {});
    }
    throw e;
  }
}

export function canSignOut(): boolean {
  return msal !== null;
}

export async function signOut(): Promise<void> {
  if (!msal) return;
  await msal.logoutRedirect({ account: msal.getActiveAccount() ?? undefined });
}
