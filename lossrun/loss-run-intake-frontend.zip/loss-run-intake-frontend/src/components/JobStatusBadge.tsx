import { Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ACTIVE_STATUSES, type JobStatus } from "@/lib/api";

export function JobStatusBadge({ status }: { status: JobStatus }) {
  const active = ACTIVE_STATUSES.includes(status);
  return (
    <Badge variant={status === "ready" ? "default" : status === "error" ? "destructive" : "secondary"}>
      {active && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
      {status}
    </Badge>
  );
}
