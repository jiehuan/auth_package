import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { FieldType } from "@/lib/api";

const TYPES: FieldType[] = ["string", "number", "date", "boolean"];

export function FieldTypeSelect({
  value,
  onChange,
  className,
}: {
  value: FieldType | undefined;
  onChange: (v: FieldType) => void;
  className?: string;
}) {
  return (
    <Select value={value ?? "string"} onValueChange={(v) => onChange(v as FieldType)}>
      <SelectTrigger className={className}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {TYPES.map((t) => (
          <SelectItem key={t} value={t}>
            {t}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
