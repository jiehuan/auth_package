import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Upload as UploadIcon, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/upload")({
  component: UploadPage,
});

function UploadPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const templates = useQuery({ queryKey: ["templates"], queryFn: api.templates });
  const lobs = useQuery({ queryKey: ["lobs"], queryFn: api.lobs });
  const clients = useQuery({ queryKey: ["clients"], queryFn: api.clients });

  const [carrier, setCarrier] = useState("");
  const [lobId, setLobId] = useState<string>("");
  const [templateId, setTemplateId] = useState<string>("");
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);

  const filteredTemplates = useMemo(
    () => (templates.data ?? []).filter((t) => !lobId || t.lob_id === lobId),
    [templates.data, lobId],
  );

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!carrier.trim() || !templateId || !lobId || files.length === 0) {
      toast.error("Carrier name, line of business, agent and at least one file are required");
      return;
    }
    setBusy(true);
    try {
      const job = await api.createJob({
        carrier_name: carrier.trim(),
        lob_id: lobId,
        template_id: templateId,
        files,
      });
      qc.invalidateQueries({ queryKey: ["jobs"] });
      qc.invalidateQueries({ queryKey: ["clients"] });
      toast.success("Files uploaded — extraction queued");
      navigate({ to: "/jobs/$id", params: { id: job.id } });
    } catch (err) {
      toast.error(errorMessage(err, "Upload failed"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="p-6 max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">New extraction</h1>
        <p className="text-sm text-muted-foreground">
          Upload PDF, XLSX or CSV loss runs; AI extracts fields per agent.
        </p>
      </div>
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="pt-4 text-sm space-y-1">
          <div className="font-medium">Underwriter tip</div>
          <p className="text-muted-foreground">
            Pick the <b>golden agent</b> for the line of business so extraction produces a
            consistent schema you can compare across submissions. Attach all valuation periods you
            have — reconciliation compares them for adverse development.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Job details</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={submit}>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label>Carrier name (mandatory)</Label>
                <Input
                  list="carrier-options"
                  value={carrier}
                  onChange={(e) => setCarrier(e.target.value)}
                  placeholder="e.g. Travelers"
                  required
                />
                <datalist id="carrier-options">
                  {clients.data?.map((c) => <option key={c.id} value={c.name} />)}
                </datalist>
                <p className="text-xs text-muted-foreground mt-1">
                  Pick an existing carrier or type a new one — the job is named automatically.
                </p>
              </div>
              <div>
                <Label>Line of business</Label>
                <Select
                  value={lobId}
                  onValueChange={(v) => {
                    setLobId(v);
                    setTemplateId("");
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select LoB" />
                  </SelectTrigger>
                  <SelectContent>
                    {lobs.data?.map((l) => (
                      <SelectItem key={l.id} value={l.id}>
                        {l.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Agent</Label>
              <Select value={templateId} onValueChange={setTemplateId}>
                <SelectTrigger>
                  <SelectValue placeholder={lobId ? "Select agent" : "Pick LoB first"} />
                </SelectTrigger>
                <SelectContent>
                  {filteredTemplates.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name}
                      {t.is_golden ? " ★" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Files</Label>
              <label className="mt-1 flex flex-col items-center justify-center border-2 border-dashed rounded-md p-6 cursor-pointer hover:bg-accent">
                <UploadIcon className="h-6 w-6 mb-2" />
                <span className="text-sm">Click to add PDF / XLSX / CSV</span>
                <input
                  type="file"
                  multiple
                  className="hidden"
                  accept=".pdf,.xlsx,.xls,.csv,application/pdf"
                  onChange={(e) => {
                    const picked = Array.from(e.target.files ?? []);
                    setFiles((prev) => [...prev, ...picked]);
                    e.target.value = "";
                  }}
                />
              </label>
              <div className="mt-2 space-y-1">
                {files.map((f, i) => (
                  <div
                    key={`${f.name}-${i}`}
                    className="flex items-center justify-between text-sm border rounded px-2 py-1"
                  >
                    <span className="truncate">{f.name}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => setFiles((p) => p.filter((_, idx) => idx !== i))}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
            <Button className="w-full" disabled={busy}>
              {busy ? "Uploading..." : "Start extraction"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
