import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { useMe } from "@/hooks/use-me";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserPlus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/admin/team")({
  component: TeamPage,
});

function TeamPage() {
  const qc = useQueryClient();
  const me = useMe().data;
  const { data = [], error } = useQuery({ queryKey: ["team"], queryFn: api.team, retry: false });

  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");

  const add = useMutation({
    mutationFn: () =>
      api.addMember({ email: email.trim(), display_name: displayName.trim() || undefined }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["team"] });
      toast.success(`${email.trim()} added — they can sign in with their company account`);
      setEmail("");
      setDisplayName("");
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  const m = useMutation({
    mutationFn: (p: { user_id: string; role: "admin" | "member"; grant: boolean }) =>
      api.setRole(p.user_id, p.role, p.grant),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["team"] });
      qc.invalidateQueries({ queryKey: ["me"] });
      toast.success("Updated");
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  if (error) return <div className="p-6 text-sm text-destructive">{(error as Error).message}</div>;

  return (
    <div className="p-6 max-w-5xl space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Team</h1>
        <p className="text-sm text-muted-foreground">
          Add members and grant admin access. Admins can manage all agents and jobs.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserPlus className="h-4 w-4" /> Add member
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form
            className="grid gap-3 sm:grid-cols-3 items-end"
            onSubmit={(e) => {
              e.preventDefault();
              add.mutate();
            }}
          >
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="person@company.com"
              />
            </div>
            <div>
              <Label>Display name (optional)</Label>
              <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
            </div>
            <Button disabled={add.isPending}>{add.isPending ? "Adding…" : "Add member"}</Button>
          </form>
          <p className="text-xs text-muted-foreground mt-2">
            Members sign in through company single sign-on; no password is stored in this app.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Members</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Roles</TableHead>
                <TableHead>Last seen</TableHead>
                <TableHead className="w-32">Admin</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((u) => (
                <TableRow key={u.id}>
                  <TableCell className="text-sm">{u.email}</TableCell>
                  <TableCell className="text-sm">{u.display_name ?? "—"}</TableCell>
                  <TableCell>
                    {u.roles.map((r) => (
                      <Badge key={r} variant="secondary" className="mr-1">
                        {r}
                      </Badge>
                    ))}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {u.last_seen_at ? new Date(u.last_seen_at).toLocaleString() : "never"}
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={u.roles.includes("admin")}
                      disabled={u.id === me?.id}
                      onCheckedChange={(v) => m.mutate({ user_id: u.id, role: "admin", grant: v })}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
