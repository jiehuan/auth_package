import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import {
  api,
  ACTIVE_STATUSES,
  downloadBlob,
  errorMessage,
  type Issue,
  type JobDetail,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ArrowLeft, Download, RefreshCw, AlertTriangle, Loader2, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { JobSummary } from "@/components/JobSummary";
import { JobStatusBadge } from "@/components/JobStatusBadge";

export const Route = createFileRoute("/_app/jobs/$id")({
  component: JobDetailPage,
});

function JobDetailPage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const key = ["job", id];

  const q = useQuery({
    queryKey: key,
    queryFn: () => api.job(id),
    refetchInterval: (query) =>
      query.state.data && ACTIVE_STATUSES.includes(query.state.data.job.status) ? 3000 : false,
  });
  const [selectedFields, setSelectedFields] = useState<string[] | null>(null);
  const [downloading, setDownloading] = useState(false);

  const job = q.data?.job;
  const rows = q.data?.rows ?? [];
  const issues = q.data?.issues ?? [];
  const fields = job?.template?.fields ?? [];
  const running = !!job && ACTIVE_STATUSES.includes(job.status);

  const issuesByRow = useMemo(() => {
    const m = new Map<string, Issue[]>();
    for (const iss of issues) {
      if (!iss.row_id) continue;
      const arr = m.get(iss.row_id) ?? [];
      arr.push(iss);
      m.set(iss.row_id, arr);
    }
    return m;
  }, [issues]);

  const effectiveSelected = selectedFields ?? fields.map((f) => f.key);

  const setInclude = useMutation({
    mutationFn: (p: { row_id: string; v: boolean }) =>
      api.updateRow(id, p.row_id, { included_in_export: p.v }),
    onMutate: async (p) => {
      await qc.cancelQueries({ queryKey: key });
      qc.setQueryData<JobDetail>(key, (d) =>
        d && {
          ...d,
          rows: d.rows.map((r) => (r.id === p.row_id ? { ...r, included_in_export: p.v } : r)),
        },
      );
    },
    onSettled: () => qc.invalidateQueries({ queryKey: key }),
  });
  const setAll = useMutation({
    mutationFn: (v: boolean) => api.setAllIncluded(id, v),
    onSettled: () => qc.invalidateQueries({ queryKey: key }),
  });
  const rec = useMutation({
    mutationFn: () => api.reconcileJob(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: key });
      toast.success("Re-reconciled");
    },
    onError: (e) => toast.error(errorMessage(e)),
  });
  const rerun = useMutation({
    mutationFn: () => api.rerunJob(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: key });
      qc.invalidateQueries({ queryKey: ["jobs"] });
      toast.success("Extraction re-queued");
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  async function exportExcel() {
    if (!job) return;
    setDownloading(true);
    try {
      const blob = await api.exportJob(id, effectiveSelected);
      downloadBlob(blob, `${job.name.replace(/[^\w.-]+/g, "_")}.xlsx`);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setDownloading(false);
    }
  }

  if (q.isLoading) return <div className="p-6">Loading...</div>;
  if (!job) return <div className="p-6">Not found</div>;

  const included = rows.filter((r) => r.included_in_export).length;

  return (
    <div className="p-6 max-w-none space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-1" /> Back
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-semibold">{job.name}</h1>
            <div className="text-xs text-muted-foreground flex items-center gap-1 flex-wrap">
              {job.client?.name ?? "No client"} · {job.lob?.name} · {job.template?.name} ·{" "}
              <JobStatusBadge status={job.status} />
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          {job.status === "error" && (
            <Button variant="outline" onClick={() => rerun.mutate()} disabled={rerun.isPending}>
              <RotateCcw className="h-4 w-4 mr-1" /> Re-run extraction
            </Button>
          )}
          <Button
            variant="outline"
            onClick={() => rec.mutate()}
            disabled={rec.isPending || running || rows.length === 0}
          >
            <RefreshCw className="h-4 w-4 mr-1" /> Reconcile
          </Button>
          <Button onClick={exportExcel} disabled={downloading || running || included === 0}>
            <Download className="h-4 w-4 mr-1" /> Export ({included})
          </Button>
        </div>
      </div>

      {running && (
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="py-3 text-sm flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            {job.status_message ?? "Working..."} — this page refreshes automatically.
          </CardContent>
        </Card>
      )}
      {job.status === "error" && (
        <Card className="border-destructive/40 bg-destructive/5">
          <CardContent className="py-3 text-sm text-destructive">
            {job.status_message ?? "Extraction failed"}
          </CardContent>
        </Card>
      )}

      <JobSummary rows={rows} issues={issues} />

      <Tabs defaultValue="rows">
        <TabsList>
          <TabsTrigger value="rows">Rows ({rows.length})</TabsTrigger>
          <TabsTrigger value="quality">Data quality ({issues.length})</TabsTrigger>
          <TabsTrigger value="fields">Export fields</TabsTrigger>
          <TabsTrigger value="files">Source files</TabsTrigger>
        </TabsList>

        <TabsContent value="rows">
          <Card>
            <CardContent className="p-0 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8">
                      <Checkbox
                        checked={rows.length > 0 && rows.every((r) => r.included_in_export)}
                        onCheckedChange={(v) => setAll.mutate(!!v)}
                      />
                    </TableHead>
                    <TableHead>Issues</TableHead>
                    <TableHead>Source</TableHead>
                    {fields.map((f) => (
                      <TableHead key={f.key}>{f.label}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => {
                    const rowIssues = issuesByRow.get(r.id) ?? [];
                    const hasError = rowIssues.some((i) => i.severity === "error");
                    const hasWarn = rowIssues.some((i) => i.severity === "warning");
                    return (
                      <TableRow
                        key={r.id}
                        className={cn(
                          hasError && "bg-destructive/10",
                          !hasError && hasWarn && "bg-amber-100/40",
                        )}
                      >
                        <TableCell>
                          <Checkbox
                            checked={r.included_in_export}
                            onCheckedChange={(v) => setInclude.mutate({ row_id: r.id, v: !!v })}
                          />
                        </TableCell>
                        <TableCell>
                          {rowIssues.length > 0 && (
                            <Badge
                              variant={hasError ? "destructive" : "secondary"}
                              title={rowIssues.map((i) => i.message).join("\n")}
                            >
                              {rowIssues.length}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-xs">{r.source_file}</TableCell>
                        {fields.map((f) => {
                          const bad = rowIssues.some((i) => i.field === f.key);
                          const v = r.data?.[f.key];
                          return (
                            <TableCell
                              key={f.key}
                              className={cn("text-sm", bad && "text-destructive font-medium")}
                            >
                              {v === null || v === undefined || v === "" ? (
                                <span className="text-muted-foreground">—</span>
                              ) : (
                                String(v)
                              )}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    );
                  })}
                  {rows.length === 0 && (
                    <TableRow>
                      <TableCell
                        colSpan={fields.length + 3}
                        className="text-center text-sm text-muted-foreground"
                      >
                        {running ? "Extraction in progress…" : "No rows extracted."}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quality">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" /> Data quality issues
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="rounded-md border p-2 text-xs text-muted-foreground">
                <b>Why this matters:</b> Errors (duplicates, negative reserves) can double-count
                losses or hide reserve strengthening. Warnings (missing report date, adverse
                development) affect lag analysis, reserve adequacy, and trend selection.
              </div>
              {issues.map((i) => (
                <div
                  key={i.id}
                  className={cn(
                    "border rounded-md p-2 text-sm",
                    i.severity === "error"
                      ? "border-destructive/40 bg-destructive/5"
                      : i.severity === "warning"
                        ? "border-amber-400/40 bg-amber-100/30"
                        : "",
                  )}
                >
                  <div className="flex items-center gap-2">
                    <Badge variant={i.severity === "error" ? "destructive" : "secondary"}>
                      {i.severity}
                    </Badge>
                    <span className="font-mono text-xs">{i.code}</span>
                    {i.field && (
                      <span className="text-xs text-muted-foreground">field: {i.field}</span>
                    )}
                  </div>
                  <div className="mt-1">{i.message}</div>
                </div>
              ))}
              {issues.length === 0 && (
                <p className="text-sm text-muted-foreground">No issues detected.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fields">
          <Card>
            <CardHeader>
              <CardTitle>Choose which fields to export</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {fields.map((f) => (
                <label key={f.key} className="flex items-center gap-2 border rounded-md px-3 py-2">
                  <Checkbox
                    checked={effectiveSelected.includes(f.key)}
                    onCheckedChange={(v) => {
                      const next = new Set(effectiveSelected);
                      if (v) next.add(f.key);
                      else next.delete(f.key);
                      setSelectedFields(fields.map((x) => x.key).filter((k) => next.has(k)));
                    }}
                  />
                  <span className="text-sm">{f.label}</span>
                </label>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="files">
          <Card>
            <CardContent className="space-y-1 pt-4">
              {job.source_files.map((f, i) => (
                <div
                  key={i}
                  className="border rounded-md px-3 py-2 text-sm flex justify-between"
                >
                  <span>{f.name}</span>
                  <span className="text-muted-foreground">{(f.size / 1024).toFixed(0)} KB</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
