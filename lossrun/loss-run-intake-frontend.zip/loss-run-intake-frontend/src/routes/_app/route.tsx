import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { useMe } from "@/hooks/use-me";
import { canSignOut, signOut } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Upload, FileStack, Users, Loader2, LogOut } from "lucide-react";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/upload", label: "New extraction", icon: Upload },
  { to: "/templates", label: "Agents", icon: FileStack },
] as const;
const adminNav = [{ to: "/admin/team", label: "Team", icon: Users }] as const;

function AppLayout() {
  const me = useMe();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  if (me.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }
  if (me.error || !me.data) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="max-w-md text-center space-y-2">
          <h1 className="text-lg font-semibold">Access restricted</h1>
          <p className="text-sm text-muted-foreground">
            {(me.error as Error)?.message ?? "Could not load your account."}
          </p>
          <p className="text-xs text-muted-foreground">
            Contact the administrator to request access.
          </p>
        </div>
      </div>
    );
  }

  const user = me.data;
  const linkCls = (to: string) =>
    cn(
      "flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-accent",
      pathname.startsWith(to) && "bg-accent font-medium",
    );

  return (
    <div className="min-h-screen flex bg-muted/30">
      <aside className="w-60 shrink-0 border-r bg-background flex flex-col">
        <div className="p-4 border-b">
          <div className="font-semibold text-sm">Loss Run Extractor</div>
          <div className="text-xs text-muted-foreground truncate" title={user.email}>
            {user.display_name ?? user.email}
          </div>
        </div>
        <nav className="flex-1 p-2 space-y-0.5">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className={linkCls(n.to)}>
              <n.icon className="h-4 w-4" /> {n.label}
            </Link>
          ))}
          {user.is_admin && (
            <>
              <div className="mt-4 mb-1 px-3 text-xs uppercase text-muted-foreground">Admin</div>
              {adminNav.map((n) => (
                <Link key={n.to} to={n.to} className={linkCls(n.to)}>
                  <n.icon className="h-4 w-4" /> {n.label}
                </Link>
              ))}
            </>
          )}
        </nav>
        <div className="p-2 border-t space-y-1">
          <div className="px-2 text-xs text-muted-foreground truncate">{user.email}</div>
          {canSignOut() && (
            <Button variant="ghost" size="sm" className="w-full justify-start" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-2" /> Sign out
            </Button>
          )}
        </div>
      </aside>
      <main className="flex-1 min-w-0 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
