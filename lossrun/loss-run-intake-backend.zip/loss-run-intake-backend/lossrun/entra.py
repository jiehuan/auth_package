"""Microsoft Entra ID access-token validation (AUTH_MODE=entra).

The SPA acquires a delegated access token for ``api://<api-client-id>/access_as_user``
via MSAL and sends it as ``Authorization: Bearer ...``. Here we verify signature
(tenant JWKS), issuer, audience, expiry and scope, and return the caller identity.
"""

from dataclasses import dataclass
from functools import lru_cache

import jwt
from fastapi import HTTPException

from .config import get_settings


@dataclass
class EntraIdentity:
    oid: str
    email: str
    name: str | None
    roles: list[str]


@lru_cache
def _jwks_client() -> jwt.PyJWKClient:
    s = get_settings()
    url = f"{s.entra_authority_host}/{s.entra_tenant_id}/discovery/v2.0/keys"
    # keys are cached in-process; unknown kid triggers a refetch (key rotation)
    return jwt.PyJWKClient(url, cache_keys=True, lifespan=3600, timeout=10)


def _issuers(tenant_id: str) -> list[str]:
    s = get_settings()
    return [f"{s.entra_authority_host}/{tenant_id}/v2.0", f"https://sts.windows.net/{tenant_id}/"]


def validate_token(token: str) -> EntraIdentity:
    s = get_settings()
    if not (s.entra_tenant_id and s.entra_api_client_id):
        raise HTTPException(500, "Entra ID is not configured (ENTRA_TENANT_ID / ENTRA_API_CLIENT_ID)")
    try:
        key = _jwks_client().get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            audience=s.entra_audiences,
            issuer=_issuers(s.entra_tenant_id),
            options={"require": ["exp", "iat", "aud", "iss"]},
            leeway=60,
        )
    except jwt.ExpiredSignatureError as e:
        raise HTTPException(401, "Token expired") from e
    except (jwt.InvalidTokenError, jwt.PyJWKClientError) as e:
        raise HTTPException(401, f"Invalid token: {e}") from e

    if claims.get("tid") != s.entra_tenant_id:
        raise HTTPException(401, "Token is from another tenant")
    scopes = set(str(claims.get("scp", "")).split())
    roles = [str(r) for r in claims.get("roles", []) or []]
    if s.entra_api_scope and s.entra_api_scope not in scopes:
        raise HTTPException(403, f"Token is missing the '{s.entra_api_scope}' scope")

    email = claims.get("preferred_username") or claims.get("upn") or claims.get("email")
    if not email or not claims.get("oid"):
        raise HTTPException(401, "Token has no user identity")
    return EntraIdentity(oid=claims["oid"], email=str(email).lower(), name=claims.get("name"), roles=roles)
