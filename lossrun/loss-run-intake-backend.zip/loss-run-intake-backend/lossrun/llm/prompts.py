"""Prompts and JSON schemas for the LLM intake (ported from the original app).

A provider can send ``*_prompt(...)`` as the user message and ask the model for
structured output matching ``*_schema(...)``.
"""

from .base import FieldSpec

# ---------------------------------------------------------------- page choice


def page_choice_prompt(pages: list[str]) -> str:
    return (
        "You are preparing an extraction template for an insurance loss run.\n"
        "Pick the ONE page that best shows the claim-level detail table (claim numbers, dates, "
        "amounts, status) — the page whose columns cover the fields an underwriter needs.\n"
        f"Available pages: {', '.join(pages)}\n"
        "Return recommendedPage exactly as one of those strings, and a one-sentence reason."
    )


PAGE_CHOICE_SCHEMA = {
    "type": "object",
    "properties": {"recommendedPage": {"type": "string"}, "reason": {"type": "string"}},
    "required": ["recommendedPage", "reason"],
    "additionalProperties": False,
}

# ---------------------------------------------------------------- field inference


def infer_fields_prompt(page: str, doc_name: str) -> str:
    return (
        "You are designing an extraction template for insurance loss run documents.\n"
        f'Read ONLY "{page}" of the attached document and list every claim-level field it contains.\n'
        "For each field return:\n"
        "- key: snake_case machine name\n"
        "- label: the keyword/header exactly as printed in the document\n"
        "- value: the true value found on that page for the first claim/record (verbatim; empty string if none)\n"
        "- required: true only for fields essential to loss run analysis (claim number, date of loss, paid/incurred amounts)\n"
        "- hint: a short instruction telling an extraction model where to find the value\n"
        "- type: one of string, number, date, boolean (amounts are number, dates are date)\n"
        "Do not invent fields that are not evidenced on that page.\n\n"
        f"Document name: {doc_name}"
    )


INFER_FIELDS_SCHEMA = {
    "type": "object",
    "properties": {
        "fields": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "key": {"type": "string"},
                    "label": {"type": "string"},
                    "value": {"type": "string"},
                    "required": {"type": "boolean"},
                    "hint": {"type": "string"},
                    "type": {"type": "string", "enum": ["string", "number", "date", "boolean"]},
                },
                "required": ["key", "label", "value", "required", "hint", "type"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["fields"],
    "additionalProperties": False,
}

# ---------------------------------------------------------------- claim extraction


def extraction_prompt(fields: list[FieldSpec], doc_name: str) -> str:
    lines = []
    for f in fields:
        line = f"- {f.key}{' (required)' if f.required else ''}: {f.label}"
        if f.hint:
            line += f" — {f.hint}"
        lines.append(line)
    return (
        "You extract loss-run claim rows from insurance documents.\n"
        "Return one entry per claim. Use null for unknown values. Dates as YYYY-MM-DD. "
        "Numbers as plain numbers (no currency symbols).\n"
        "Fields:\n" + "\n".join(lines) + f"\n\nDocument name: {doc_name}"
    )


def extraction_schema(fields: list[FieldSpec]) -> dict:
    json_type = {"number": "number", "boolean": "boolean"}
    props = {f.key: {"type": [json_type.get(f.type, "string"), "null"]} for f in fields}
    return {
        "type": "object",
        "properties": {
            "claims": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": props,
                    "required": list(props.keys()),
                    "additionalProperties": False,
                },
            }
        },
        "required": ["claims"],
        "additionalProperties": False,
    }
