"""Company LLM API provider — skeleton.

Implement ``_complete_json`` against the internal endpoint; the three intake
methods below are already built on top of it using the prompts/schemas in
``prompts.py``. Configure with LLM_PROVIDER=internal, LLM_BASE_URL, LLM_API_KEY,
LLM_MODEL.
"""

import base64

from ..config import get_settings
from ..services.documents import Document
from . import prompts
from .base import FieldSpec, InferredField, LLMError, LLMIntake, PageChoice


class InternalLLM(LLMIntake):
    name = "internal"

    def __init__(self) -> None:
        s = get_settings()
        self.base_url = s.llm_base_url.rstrip("/")
        self.api_key = s.llm_api_key
        self.model = s.llm_model
        self.timeout = s.llm_timeout_seconds

    # ------------------------------------------------------------------ TODO
    def _complete_json(self, prompt: str, schema: dict, doc: Document) -> dict:
        """Send ``prompt`` plus the document to the model and return JSON matching ``schema``.

        Suggested payload:
          - doc.kind == "pdf":   attach doc.data (base64 below) if the API accepts files,
                                 otherwise send doc.text (text layer; empty for scans)
          - doc.kind == "sheet": send doc.text (sheet rows rendered as JSON records)
          - doc.kind == "text":  send doc.text
        Raise ``LLMError`` on transport errors or when the output does not parse.
        """
        _pdf_b64 = base64.b64encode(doc.data).decode() if doc.kind == "pdf" else None  # noqa: F841
        raise NotImplementedError("Wire the company LLM API here")

    # ------------------------------------------------------------------ intake
    def recommend_page(self, doc: Document, pages: list[str]) -> PageChoice:
        out = self._complete_json(prompts.page_choice_prompt(pages), prompts.PAGE_CHOICE_SCHEMA, doc)
        page = out.get("recommendedPage")
        return PageChoice(page if page in pages else pages[0], str(out.get("reason", "")))

    def infer_fields(self, doc: Document, page: str) -> list[InferredField]:
        out = self._complete_json(
            prompts.infer_fields_prompt(page, doc.name), prompts.INFER_FIELDS_SCHEMA, doc
        )
        try:
            return [
                InferredField(
                    key=str(f["key"]),
                    label=str(f["label"]),
                    value=str(f.get("value", "")),
                    required=bool(f.get("required", False)),
                    hint=str(f.get("hint", "")),
                    type=f.get("type") if f.get("type") in ("string", "number", "date", "boolean") else "string",
                )
                for f in out.get("fields", [])
            ]
        except (KeyError, TypeError) as e:
            raise LLMError(f"Unexpected field inference output: {e}") from e

    def extract_claims(self, doc: Document, fields: list[FieldSpec]) -> list[dict]:
        out = self._complete_json(
            prompts.extraction_prompt(fields, doc.name), prompts.extraction_schema(fields), doc
        )
        claims = out.get("claims")
        if not isinstance(claims, list):
            raise LLMError("Extraction output has no 'claims' array")
        return [c for c in claims if isinstance(c, dict)]
