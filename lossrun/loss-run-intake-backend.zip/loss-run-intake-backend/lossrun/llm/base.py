"""LLM intake interface.

Everything that needs a model goes through ``LLMIntake``. The rest of the app
(BFF endpoints, worker, reconciliation, export) never talks to a model directly,
so plugging in the real LLM means implementing one class — see ``internal.py``.
"""

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass

from ..services.documents import Document


class LLMNotConfigured(RuntimeError):
    """Raised when the configured provider cannot handle the request (no model yet)."""


class LLMError(RuntimeError):
    """Model call failed or returned unusable output."""


@dataclass
class FieldSpec:
    key: str
    label: str
    type: str = "string"  # string | number | date | boolean
    required: bool = False
    hint: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "FieldSpec":
        return cls(
            key=str(d.get("key", "")),
            label=str(d.get("label", d.get("key", ""))),
            type=str(d.get("type") or "string"),
            required=bool(d.get("required", False)),
            hint=str(d.get("hint") or ""),
        )


@dataclass
class PageChoice:
    recommended_page: str
    reason: str


@dataclass
class InferredField:
    key: str
    label: str
    value: str
    required: bool
    hint: str
    type: str = "string"  # string | number | date | boolean

    def to_dict(self) -> dict:
        return asdict(self)


class LLMIntake(ABC):
    """Contract for loss-run intake models."""

    name: str = "base"

    @abstractmethod
    def recommend_page(self, doc: Document, pages: list[str]) -> PageChoice:
        """Agent wizard step 2: pick the page/sheet with the claim-level detail table."""

    @abstractmethod
    def infer_fields(self, doc: Document, page: str) -> list[InferredField]:
        """Agent wizard step 3: list the claim-level fields on ``page`` with the first record's value."""

    @abstractmethod
    def extract_claims(self, doc: Document, fields: list[FieldSpec]) -> list[dict]:
        """Extraction job: one dict per claim, keyed by ``FieldSpec.key``. Use None for unknown values."""
