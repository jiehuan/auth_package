"""No-model fallback so the full pipeline can be exercised before the LLM is wired in.

Works on spreadsheets / CSV only: columns are matched to agent fields by header name
(label, key, or a small synonym list). PDFs raise ``LLMNotConfigured``.
"""

import re

from ..services.documents import Document, sheet_records
from ..services.normalize import parse_date, parse_number
from .base import FieldSpec, InferredField, LLMIntake, LLMNotConfigured, PageChoice

PDF_MSG = (
    "PDF / unstructured documents need the LLM intake, which is not wired in yet "
    "(LLM_PROVIDER=heuristic only reads spreadsheet/CSV columns)."
)

# normalized header -> field key
SYNONYMS: dict[str, list[str]] = {
    "claim_number": ["claim", "claim no", "claim num", "claim id", "claim ref", "claim reference", "file number"],
    "policy_number": ["policy", "policy no", "policy num", "policy id"],
    "date_of_loss": ["loss date", "dol", "date of incident", "accident date", "incident date", "occurrence date"],
    "date_reported": ["reported date", "report date", "date notified", "notification date", "reported"],
    "claimant": ["claimant name", "injured", "injured worker", "employee", "driver", "insured name"],
    "cause_of_loss": ["cause", "loss cause", "cause description", "accident type", "peril", "injury cause"],
    "description": ["loss description", "accident description", "description of loss", "narrative", "details"],
    "status": ["claim status", "open closed", "open/closed", "state"],
    "paid_indemnity": ["indemnity paid", "paid loss", "loss paid", "paid indemnity", "medical paid"],
    "paid_expense": ["expense paid", "paid alae", "alae paid", "paid lae", "expense"],
    "reserve_indemnity": ["indemnity reserve", "loss reserve", "outstanding indemnity", "os indemnity"],
    "reserve_expense": ["expense reserve", "alae reserve", "outstanding expense", "os expense"],
    "incurred_total": ["total incurred", "incurred", "gross incurred", "total", "incurred loss"],
    "deductible": ["ded", "deductible amount", "sir", "retention"],
    "currency": ["ccy", "currency code"],
}

CORE_KEYS = ("claim_number", "date_of_loss", "incurred_total", "paid_indemnity")
KNOWN_TYPES = {
    "date_of_loss": "date",
    "date_reported": "date",
    "paid_indemnity": "number",
    "paid_expense": "number",
    "reserve_indemnity": "number",
    "reserve_expense": "number",
    "incurred_total": "number",
    "deductible": "number",
}


def guess_type(key: str, values: list[str]) -> str:
    if key in KNOWN_TYPES:
        return KNOWN_TYPES[key]
    sample = [v for v in values if v and v.strip()][:20]
    if not sample:
        return "string"
    if all(parse_number(v) is not None for v in sample) and not key.endswith(("_number", "_id", "_no")):
        return "number"
    if all(parse_date(v) is not None for v in sample) and any(c in sample[0] for c in "-/"):
        return "date"
    return "string"


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def snake(s: str) -> str:
    return re.sub(r"_+", "_", re.sub(r"[^a-z0-9]+", "_", (s or "").lower())).strip("_") or "field"


def _match_columns(headers: list[str], fields: list[FieldSpec]) -> dict[str, str]:
    """field.key -> header"""
    by_norm = {norm(h): h for h in headers if h}
    mapping: dict[str, str] = {}
    used: set[str] = set()
    for f in fields:
        candidates = [f.label, f.key, f.key.replace("_", " ")] + SYNONYMS.get(f.key, [])
        for c in candidates:
            h = by_norm.get(norm(c))
            if h and h not in used:
                mapping[f.key] = h
                used.add(h)
                break
    return mapping


def _score_sheet(rows: list[list[str]]) -> int:
    recs = sheet_records(rows)
    if not recs:
        return 0
    headers = list(recs[0].keys())
    generic = [FieldSpec(key=k, label=k.replace("_", " ")) for k in SYNONYMS]
    return len(_match_columns(headers, generic)) * 1000 + len(recs)


class HeuristicLLM(LLMIntake):
    name = "heuristic"

    def recommend_page(self, doc: Document, pages: list[str]) -> PageChoice:
        if doc.kind != "sheet":
            return PageChoice(pages[0], "AI page recommendation is not available yet; showing the first page.")
        best = max(pages, key=lambda p: _score_sheet(doc.sheets.get(p, [])))
        return PageChoice(best, "This sheet has the most recognizable claim columns.")

    def infer_fields(self, doc: Document, page: str) -> list[InferredField]:
        if doc.kind != "sheet":
            raise LLMNotConfigured(PDF_MSG)
        rows = doc.sheets.get(page) or next(iter(doc.sheets.values()), [])
        recs = sheet_records(rows)
        if not recs:
            return []
        first = recs[0]
        generic = [FieldSpec(key=k, label=k.replace("_", " ")) for k in SYNONYMS]
        known = {h: k for k, h in _match_columns(list(first.keys()), generic).items()}
        out: list[InferredField] = []
        seen: set[str] = set()
        for header, value in first.items():
            key = known.get(header) or snake(header)
            if key in seen:
                key = f"{key}_{len(seen)}"
            seen.add(key)
            out.append(
                InferredField(
                    key=key,
                    label=header,
                    value=value,
                    required=key in CORE_KEYS,
                    hint=f'Column "{header}"',
                    type=guess_type(key, [r.get(header, "") for r in recs]),
                )
            )
        return out

    def extract_claims(self, doc: Document, fields: list[FieldSpec]) -> list[dict]:
        if doc.kind != "sheet":
            raise LLMNotConfigured(PDF_MSG)
        claims: list[dict] = []
        for _, rows in doc.sheets.items():
            recs = sheet_records(rows)
            if not recs:
                continue
            mapping = _match_columns(list(recs[0].keys()), fields)
            if not mapping:
                continue  # sheet has nothing we recognize (cover page, notes, ...)
            for rec in recs:
                row = {f.key: (rec.get(mapping[f.key]) if f.key in mapping else None) for f in fields}
                if all(v in (None, "") for v in row.values()):
                    continue
                claims.append(row)
        return claims
