from ..services.documents import Document
from .base import FieldSpec, InferredField, LLMIntake, LLMNotConfigured, PageChoice

MSG = "LLM intake is not configured (LLM_PROVIDER=disabled)."


class DisabledLLM(LLMIntake):
    name = "disabled"

    def recommend_page(self, doc: Document, pages: list[str]) -> PageChoice:
        raise LLMNotConfigured(MSG)

    def infer_fields(self, doc: Document, page: str) -> list[InferredField]:
        raise LLMNotConfigured(MSG)

    def extract_claims(self, doc: Document, fields: list[FieldSpec]) -> list[dict]:
        raise LLMNotConfigured(MSG)
