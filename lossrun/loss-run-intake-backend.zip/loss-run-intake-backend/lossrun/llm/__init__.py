from functools import lru_cache

from ..config import get_settings
from .base import FieldSpec, InferredField, LLMError, LLMIntake, LLMNotConfigured, PageChoice

__all__ = [
    "FieldSpec",
    "InferredField",
    "LLMError",
    "LLMIntake",
    "LLMNotConfigured",
    "PageChoice",
    "get_llm",
]


@lru_cache
def get_llm() -> LLMIntake:
    provider = get_settings().llm_provider.lower()
    if provider == "heuristic":
        from .heuristic import HeuristicLLM

        return HeuristicLLM()
    if provider == "disabled":
        from .disabled import DisabledLLM

        return DisabledLLM()
    if provider == "internal":
        from .internal import InternalLLM

        return InternalLLM()
    raise ValueError(f"Unknown LLM_PROVIDER {provider!r} (heuristic | disabled | internal)")
