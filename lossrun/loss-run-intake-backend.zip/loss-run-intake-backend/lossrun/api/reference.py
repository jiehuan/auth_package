"""Current user, lines of business, clients (carriers)."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..auth import current_user
from ..db import get_db
from ..models import Client, ExtractionJob, LineOfBusiness, User
from ..schemas import ClientCreate, client_out, lob_out, user_out
from ..services.access import visible_clients

router = APIRouter(prefix="/api")


@router.get("/me")
def me(user: User = Depends(current_user)):
    return user_out(user)


@router.get("/lobs")
def list_lobs(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return [lob_out(l) for l in db.scalars(select(LineOfBusiness).order_by(LineOfBusiness.name))]


@router.get("/clients")
def list_clients(db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = visible_clients(user).order_by(Client.created_at.desc())
    return [client_out(c) for c in db.scalars(q)]


@router.post("/clients", status_code=201)
def create_client(body: ClientCreate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    c = Client(name=body.name.strip(), created_by=user.id)
    db.add(c)
    db.commit()
    return client_out(c)


@router.delete("/clients/{client_id}")
def delete_client(client_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    c = db.scalar(visible_clients(user).where(Client.id == client_id))
    if c is None:
        raise HTTPException(404, "Client not found")
    for j in db.scalars(select(ExtractionJob).where(ExtractionJob.client_id == c.id)):
        j.client_id = None
    db.delete(c)
    db.commit()
    return {"ok": True}


def resolve_carrier(db: Session, user: User, name: str) -> Client:
    """Find a visible carrier by name (case-insensitive) or create it."""
    name = name.strip()

    existing = db.scalar(visible_clients(user).where(func.lower(Client.name) == name.lower()).limit(1))
    if existing:
        return existing
    c = Client(name=name, created_by=user.id)
    db.add(c)
    db.flush()
    return c
