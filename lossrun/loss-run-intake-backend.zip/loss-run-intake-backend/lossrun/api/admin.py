"""Team management + demo data (admin only)."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from ..auth import ensure_role, require_admin
from ..db import get_db
from ..models import ROLE_ADMIN, ROLE_MEMBER, Template, User, UserRole, UserTemplateAccess
from ..schemas import MemberCreate, RoleChange, TemplateAccessUpdate, user_out
from ..services.demo import clear_demo, seed_demo

router = APIRouter(prefix="/api/admin")


@router.get("/users")
def list_users(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return [user_out(u) for u in db.scalars(select(User).order_by(User.created_at.desc()))]


@router.post("/users", status_code=201)
def add_member(body: MemberCreate, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    """Pre-provision a member by email. They sign in through SSO; no password is stored here."""
    email = body.email.strip().lower()
    if db.scalar(select(User.id).where(func.lower(User.email) == email)):
        raise HTTPException(409, "That user already exists")
    u = User(email=email, display_name=(body.display_name or "").strip() or email.split("@")[0])
    db.add(u)
    db.flush()
    db.add(UserRole(user_id=u.id, role=ROLE_MEMBER))
    db.commit()
    db.refresh(u)
    return user_out(u)


@router.put("/users/{user_id}/roles")
def set_role(user_id: str, body: RoleChange, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    u = db.get(User, user_id)
    if u is None:
        raise HTTPException(404, "User not found")
    if body.grant:
        ensure_role(db, u, body.role)
    else:
        if body.role == ROLE_ADMIN and u.id == admin.id:
            raise HTTPException(400, "You cannot remove your own admin role")
        db.execute(delete(UserRole).where(UserRole.user_id == u.id, UserRole.role == body.role))
    db.commit()
    return {"ok": True}


@router.get("/users/{user_id}/template-access")
def get_access(user_id: str, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    ids = db.scalars(select(UserTemplateAccess.template_id).where(UserTemplateAccess.user_id == user_id))
    return {"template_ids": list(ids)}


@router.put("/users/{user_id}/template-access")
def set_access(
    user_id: str, body: TemplateAccessUpdate, db: Session = Depends(get_db), _: User = Depends(require_admin)
):
    if db.get(User, user_id) is None:
        raise HTTPException(404, "User not found")
    valid = set(db.scalars(select(Template.id).where(Template.id.in_(body.template_ids))))
    db.execute(delete(UserTemplateAccess).where(UserTemplateAccess.user_id == user_id))
    for tid in valid:
        db.add(UserTemplateAccess(user_id=user_id, template_id=tid))
    db.commit()
    return {"template_ids": sorted(valid)}


@router.post("/demo/seed")
def demo_seed(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    try:
        return seed_demo(db, admin)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/demo/clear")
def demo_clear(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return clear_demo(db)
