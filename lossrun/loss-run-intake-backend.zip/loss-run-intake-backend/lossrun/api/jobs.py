"""Extraction jobs: create (upload), status, rows, reconciliation, export."""

from datetime import date

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from ..auth import current_user
from ..db import get_db
from ..models import (
    JOB_ACTIVE,
    JOB_EXTRACTING,
    JOB_QUEUED,
    JOB_RECONCILING,
    DataQualityIssue,
    ExtractionJob,
    ExtractionRow,
    User,
)
from ..schemas import BulkInclude, ExportRequest, RowPatch, issue_out, job_out, row_out
from ..services.access import get_job_or_404, get_template_or_404, visible_jobs
from ..services.export import build_workbook
from ..services.reconcile import reconcile_job
from ..storage import get_storage, make_key, safe_filename
from .reference import resolve_carrier
from .uploads import read_upload

router = APIRouter(prefix="/api/jobs")


@router.get("")
def list_jobs(db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = visible_jobs(user).order_by(ExtractionJob.created_at.desc())
    return [job_out(j) for j in db.scalars(q)]


@router.post("", status_code=201)
async def create_job(
    carrier_name: str = Form(..., min_length=1, max_length=200),
    lob_id: str = Form(...),
    template_id: str = Form(...),
    files: list[UploadFile] = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    """Upload loss run files and queue an extraction job for the worker."""
    template = get_template_or_404(db, user, template_id)
    if template.lob_id != lob_id:
        raise HTTPException(400, "Agent does not belong to that line of business")
    if not files:
        raise HTTPException(400, "At least one file is required")

    storage = get_storage()
    stored: list[dict] = []
    try:
        for f in files:
            data = await read_upload(f)
            key = make_key("uploads", user.id, f.filename or "file")
            storage.put(key, data)
            stored.append(
                {"name": f.filename or safe_filename(key), "path": key, "size": len(data), "type": f.content_type or ""}
            )

        carrier = resolve_carrier(db, user, carrier_name)
        job = ExtractionJob(
            user_id=user.id,
            client_id=carrier.id,
            template_id=template.id,
            lob_id=lob_id,
            name=f"{carrier.name} — {template.lob.name} — {date.today():%m/%d/%Y}",
            status=JOB_QUEUED,
            status_message="Waiting for worker",
            source_files=stored,
        )
        db.add(job)
        db.commit()
    except Exception:
        db.rollback()
        for s in stored:
            storage.delete(s["path"])
        raise
    return job_out(job)


@router.get("/{job_id}")
def get_job(job_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    job = get_job_or_404(db, user, job_id)
    rows = db.scalars(select(ExtractionRow).where(ExtractionRow.job_id == job.id).order_by(ExtractionRow.row_index))
    issues = db.scalars(select(DataQualityIssue).where(DataQualityIssue.job_id == job.id))
    return {
        "job": job_out(job, with_fields=True),
        "rows": [row_out(r) for r in rows],
        "issues": [issue_out(i) for i in issues],
    }


@router.get("/{job_id}/status")
def job_status(job_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    job = get_job_or_404(db, user, job_id)
    return {"id": job.id, "status": job.status, "status_message": job.status_message}


@router.post("/{job_id}/run")
def rerun_job(job_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Re-queue extraction (e.g. after the LLM is configured or a failure)."""
    job = get_job_or_404(db, user, job_id)
    if job.status in JOB_ACTIVE:
        raise HTTPException(409, "Job is already queued or running")
    job.status = JOB_QUEUED
    job.status_message = "Waiting for worker"
    job.completed_at = None
    job.claimed_by = None
    db.commit()
    return job_out(job)


@router.post("/{job_id}/reconcile")
def reconcile(job_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    job = get_job_or_404(db, user, job_id)
    if job.status in JOB_ACTIVE:
        raise HTTPException(409, "Wait for extraction to finish")
    n = reconcile_job(db, job)
    db.commit()
    return {"ok": True, "issues": n}


@router.patch("/{job_id}/rows/{row_id}")
def update_row(
    job_id: str, row_id: str, body: RowPatch, db: Session = Depends(get_db), user: User = Depends(current_user)
):
    job = get_job_or_404(db, user, job_id)
    row = db.scalar(select(ExtractionRow).where(ExtractionRow.id == row_id, ExtractionRow.job_id == job.id))
    if row is None:
        raise HTTPException(404, "Row not found")
    if body.data is not None:
        row.data = body.data
    if body.included_in_export is not None:
        row.included_in_export = body.included_in_export
    db.commit()
    return row_out(row)


@router.post("/{job_id}/rows/include")
def bulk_include(job_id: str, body: BulkInclude, db: Session = Depends(get_db), user: User = Depends(current_user)):
    job = get_job_or_404(db, user, job_id)
    stmt = update(ExtractionRow).where(ExtractionRow.job_id == job.id)
    if body.row_ids is not None:
        stmt = stmt.where(ExtractionRow.id.in_(body.row_ids))
    db.execute(stmt.values(included_in_export=body.included))
    db.commit()
    return {"ok": True}


@router.post("/{job_id}/export")
def export_job(job_id: str, body: ExportRequest, db: Session = Depends(get_db), user: User = Depends(current_user)):
    job = get_job_or_404(db, user, job_id)
    content = build_workbook(db, job, body.selected_fields)
    filename = safe_filename(f"{job.name}.xlsx")
    return Response(
        content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.delete("/{job_id}")
def delete_job(job_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    job = get_job_or_404(db, user, job_id)
    if job.status in (JOB_EXTRACTING, JOB_RECONCILING):
        raise HTTPException(409, "Job is running")
    paths = [f.get("path") for f in (job.source_files or []) if f.get("path", "").startswith("uploads/")]
    db.execute(delete(DataQualityIssue).where(DataQualityIssue.job_id == job.id))
    db.execute(delete(ExtractionRow).where(ExtractionRow.job_id == job.id))
    db.delete(job)
    db.commit()
    storage = get_storage()
    for p in paths:
        storage.delete(p)
    return {"ok": True}
