from fastapi import HTTPException, UploadFile

from ..config import get_settings
from ..services.documents import SHEET_EXTS

ALLOWED_EXTS = (".pdf",) + SHEET_EXTS


async def read_upload(f: UploadFile) -> bytes:
    name = (f.filename or "").lower()
    if not name.endswith(ALLOWED_EXTS):
        raise HTTPException(400, f"Unsupported file type: {f.filename}. Use PDF, XLSX, XLS or CSV.")
    limit = get_settings().max_upload_mb * 1024 * 1024
    data = await f.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"{f.filename} exceeds {get_settings().max_upload_mb} MB")
    if not data:
        raise HTTPException(400, f"{f.filename} is empty")
    return data
