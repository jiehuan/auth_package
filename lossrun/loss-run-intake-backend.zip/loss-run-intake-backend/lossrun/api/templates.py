"""Extraction agents (templates) + the three-step agent builder."""

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from sqlalchemy import delete, exists, select
from sqlalchemy.orm import Session

from ..auth import current_user
from ..db import get_db
from ..llm import LLMError, LLMNotConfigured, get_llm
from ..models import ExtractionJob, LineOfBusiness, Template, User, UserTemplateAccess
from ..schemas import InferRequest, TemplateCreate, TemplateLabel, TemplateUpdate, template_out
from ..services import documents
from ..services.access import can_edit_template, get_template_or_404, visible_templates
from ..storage import get_storage, make_key
from .uploads import read_upload

router = APIRouter(prefix="/api")


def _out(t: Template, user: User) -> dict:
    return template_out(t, can_edit_template(user, t))


@router.get("/templates")
def list_templates(db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = visible_templates(user).order_by(Template.created_at.desc())
    return [_out(t, user) for t in db.scalars(q)]


@router.get("/templates/{template_id}")
def get_template(template_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return _out(get_template_or_404(db, user, template_id), user)


@router.post("/templates", status_code=201)
def create_template(body: TemplateCreate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.get(LineOfBusiness, body.lob_id) is None:
        raise HTTPException(400, "Unknown line of business")
    fields = [f.model_dump() for f in body.fields]
    if body.clone_from:
        fields = list(get_template_or_404(db, user, body.clone_from).fields or [])
    if body.source_file_path and not body.source_file_path.startswith(f"templates/{user.id}/"):
        raise HTTPException(400, "Invalid source file")
    t = Template(
        name=body.name.strip(),
        lob_id=body.lob_id,
        fields=fields,
        owner_user_id=user.id,
        is_system=False,
        label=body.label or "Custom",
        source_file_path=body.source_file_path,
    )
    db.add(t)
    db.commit()
    return _out(t, user)


@router.post("/templates/{template_id}/copy", status_code=201)
def copy_template(template_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    src = get_template_or_404(db, user, template_id)
    t = Template(
        name=f"{src.name} (copy)",
        lob_id=src.lob_id,
        fields=[dict(f) for f in (src.fields or [])],
        owner_user_id=user.id,
        is_system=False,
        label="Custom",
    )
    db.add(t)
    db.commit()
    return _out(t, user)


def _editable(db: Session, user: User, template_id: str) -> Template:
    t = get_template_or_404(db, user, template_id)
    if not can_edit_template(user, t):
        raise HTTPException(403, "System agents are read only — copy it to make changes")
    return t


@router.patch("/templates/{template_id}")
def update_template(
    template_id: str, body: TemplateUpdate, db: Session = Depends(get_db), user: User = Depends(current_user)
):
    t = _editable(db, user, template_id)
    if body.name is not None:
        t.name = body.name.strip()
    if body.fields is not None:
        keys = [f.key for f in body.fields]
        if len(keys) != len(set(keys)):
            raise HTTPException(400, "Field keys must be unique")
        t.fields = [f.model_dump() for f in body.fields]
    db.commit()
    return _out(t, user)


@router.put("/templates/{template_id}/label")
def set_label(template_id: str, body: TemplateLabel, db: Session = Depends(get_db), user: User = Depends(current_user)):
    t = _editable(db, user, template_id)
    t.label = body.label
    db.commit()
    return {"ok": True}


@router.delete("/templates/{template_id}")
def delete_template(template_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    t = _editable(db, user, template_id)
    if db.scalar(select(exists().where(ExtractionJob.template_id == t.id))):
        raise HTTPException(409, "This agent is used by extraction jobs and cannot be deleted")
    db.execute(delete(UserTemplateAccess).where(UserTemplateAccess.template_id == t.id))
    db.delete(t)
    db.commit()
    if t.source_file_path:
        get_storage().delete(t.source_file_path)
    return {"ok": True}


# ------------------------------------------------------------------ agent builder


def _own_source(user: User, path: str) -> bytes:
    if not path.startswith(f"templates/{user.id}/"):
        raise HTTPException(404, "File not found")
    try:
        return get_storage().get(path)
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(404, "File not found") from e


def _llm_http_error(e: Exception) -> HTTPException:
    if isinstance(e, (LLMNotConfigured, NotImplementedError)):
        return HTTPException(503, str(e) or "LLM intake is not implemented yet")
    return HTTPException(502, f"Document analysis failed: {str(e)[:300]}")


@router.post("/template-sources", status_code=201)
async def upload_template_source(file: UploadFile = File(...), user: User = Depends(current_user)):
    """Step 1+2: store the sample loss run, list its pages/sheets and recommend one."""
    data = await read_upload(file)
    name = file.filename or "document"
    ctype = file.content_type or ""
    key = make_key("templates", user.id, name)
    get_storage().put(key, data)

    def analyze():
        pages = documents.list_pages(data, name, ctype)
        if len(pages) == 1:
            return pages, pages[0], "This document has a single page of data."
        doc = documents.Document.load(name, ctype, data)
        try:
            choice = get_llm().recommend_page(doc, pages)
            page = choice.recommended_page if choice.recommended_page in pages else pages[0]
            return pages, page, choice.reason
        except (LLMNotConfigured, NotImplementedError):
            return pages, pages[0], "AI page recommendation is not available yet; review the pages yourself."

    try:
        pages, page, reason = await run_in_threadpool(analyze)
    except LLMError as e:
        raise _llm_http_error(e) from e
    except Exception as e:
        raise HTTPException(400, f"Could not read {name}: {e}") from e
    return {"path": key, "name": name, "type": ctype, "pages": pages, "recommended_page": page, "reason": reason}


@router.get("/template-sources/preview")
def preview_template_source(path: str, name: str, page: str, user: User = Depends(current_user)):
    """Sheet preview for the builder (PDFs are previewed client-side)."""
    data = _own_source(user, path)
    if documents.doc_kind(name) != "sheet":
        raise HTTPException(400, "Preview is only available for spreadsheets")
    rows, total = documents.sheet_preview(data, name, page)
    return {"rows": rows, "total_rows": total}


@router.post("/template-sources/infer")
async def infer_fields(body: InferRequest, user: User = Depends(current_user)):
    """Step 3: extract keyword / label / true value from the selected page."""
    data = _own_source(user, body.path)

    def run():
        doc = documents.Document.load(body.name, body.type, data, page=body.page)
        return get_llm().infer_fields(doc, body.page)

    try:
        fields = await run_in_threadpool(run)
    except (LLMNotConfigured, NotImplementedError, LLMError) as e:
        raise _llm_http_error(e) from e
    if not fields:
        raise HTTPException(422, "No fields could be detected on that page.")
    return {"fields": [f.to_dict() for f in fields]}
