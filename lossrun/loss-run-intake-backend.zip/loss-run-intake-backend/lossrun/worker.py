"""Extraction worker: polls the jobs table and runs queued extractions.

    python -m lossrun.worker            # run forever
    python -m lossrun.worker --once     # process whatever is queued, then exit
    python -m lossrun.worker --check    # liveness probe (heartbeat freshness)
"""

import argparse
import logging
import os
import signal
import socket
import sys
import time
from datetime import timedelta

from sqlalchemy import or_, select, update

from .config import get_settings
from .db import SessionLocal
from .llm import get_llm
from .models import JOB_EXTRACTING, JOB_QUEUED, JOB_RECONCILING, ExtractionJob, utcnow
from .services.extraction import JobFailed, fail_job, run_job

settings = get_settings()
logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("lossrun.worker")

WORKER_ID = f"{socket.gethostname()}:{os.getpid()}"
MAX_ATTEMPTS = 3
_stop = False


def _handle_stop(signum, _frame):
    global _stop
    log.info("signal %s received, finishing current job then exiting", signum)
    _stop = True


def heartbeat() -> None:
    try:
        settings.worker_heartbeat_file.touch()
    except OSError:
        pass


def requeue_stale(db) -> int:
    """Jobs whose worker died mid-run (lease expired) go back to the queue."""
    cutoff = utcnow() - timedelta(seconds=settings.worker_job_lease_seconds)
    res = db.execute(
        update(ExtractionJob)
        .where(
            ExtractionJob.status.in_((JOB_EXTRACTING, JOB_RECONCILING)),
            or_(ExtractionJob.claimed_at.is_(None), ExtractionJob.claimed_at < cutoff),
        )
        .values(status=JOB_QUEUED, status_message="Re-queued after worker interruption", claimed_by=None)
    )
    db.commit()
    return res.rowcount or 0


def claim_next(db) -> str | None:
    """Atomically move one queued job to 'extracting'. Safe with several workers."""
    candidates = db.scalars(
        select(ExtractionJob.id).where(ExtractionJob.status == JOB_QUEUED).order_by(ExtractionJob.created_at).limit(5)
    ).all()
    for job_id in candidates:
        res = db.execute(
            update(ExtractionJob)
            .where(ExtractionJob.id == job_id, ExtractionJob.status == JOB_QUEUED)
            .values(
                status=JOB_EXTRACTING,
                status_message="Starting",
                claimed_by=WORKER_ID,
                claimed_at=utcnow(),
                attempts=ExtractionJob.attempts + 1,
            )
        )
        db.commit()
        if res.rowcount == 1:
            return job_id
    return None


def process(job_id: str) -> None:
    db = SessionLocal()
    try:
        job = db.get(ExtractionJob, job_id)
        if job is None:
            return
        log.info("job %s: start (attempt %s, %d files)", job_id, job.attempts, len(job.source_files or []))
        t0 = time.monotonic()
        run_job(db, job, heartbeat=heartbeat)
        log.info("job %s: ready in %.1fs — %s", job_id, time.monotonic() - t0, job.status_message)
    except JobFailed as e:
        db.rollback()
        log.warning("job %s: failed — %s", job_id, e)
        fail_job(db, job_id, str(e))
    except Exception as e:
        db.rollback()
        log.exception("job %s: crashed", job_id)
        job = db.get(ExtractionJob, job_id)
        if job is not None and job.attempts < MAX_ATTEMPTS:
            job.status = JOB_QUEUED
            job.status_message = f"Retrying after error: {str(e)[:300]}"
            job.claimed_by = None
            db.commit()
        else:
            fail_job(db, job_id, f"Extraction failed: {e}")
    finally:
        db.close()


def run(once: bool = False) -> None:
    # Schema is created by the app container; until it exists the poll below just logs and retries.
    signal.signal(signal.SIGTERM, _handle_stop)
    signal.signal(signal.SIGINT, _handle_stop)
    log.info("worker %s started (llm=%s, poll=%ss)", WORKER_ID, get_llm().name, settings.worker_poll_seconds)

    last_stale_check = 0.0
    while not _stop:
        heartbeat()
        try:
            db = SessionLocal()
            try:
                if time.monotonic() - last_stale_check > 60:
                    n = requeue_stale(db)
                    if n:
                        log.warning("re-queued %d stale job(s)", n)
                    last_stale_check = time.monotonic()
                job_id = claim_next(db)
            finally:
                db.close()
        except Exception:
            log.exception("poll failed")
            job_id = None

        if job_id:
            process(job_id)
            continue
        if once:
            break
        time.sleep(settings.worker_poll_seconds)
    log.info("worker stopped")


def check() -> int:
    """Exit 0 if the heartbeat is fresh (used as an OpenShift exec liveness probe)."""
    hb = settings.worker_heartbeat_file
    limit = max(120, settings.worker_job_lease_seconds)
    try:
        age = time.time() - hb.stat().st_mtime
    except FileNotFoundError:
        return 1
    return 0 if age < limit else 1


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--once", action="store_true")
    p.add_argument("--check", action="store_true")
    args = p.parse_args()
    if args.check:
        sys.exit(check())
    run(once=args.once)


if __name__ == "__main__":
    main()
