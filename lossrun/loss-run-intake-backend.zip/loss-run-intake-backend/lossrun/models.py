"""ORM models.

Portable between SQLite and Azure SQL:
- UUIDs stored as String(36)
- JSON columns map to NVARCHAR(max) on SQL Server
- No database-level ON DELETE CASCADE (SQL Server rejects multiple cascade paths);
  child rows are deleted explicitly in the service layer.
"""

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    true,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def new_id() -> str:
    return str(uuid.uuid4())


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


ROLE_ADMIN = "admin"
ROLE_MEMBER = "member"
TEMPLATE_LABELS = ("System", "Custom", "Carrier")

# Job lifecycle: queued -> extracting -> reconciling -> ready | error
JOB_QUEUED = "queued"
JOB_EXTRACTING = "extracting"
JOB_RECONCILING = "reconciling"
JOB_READY = "ready"
JOB_ERROR = "error"
JOB_ACTIVE = (JOB_QUEUED, JOB_EXTRACTING, JOB_RECONCILING)


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    # Entra ID object id (oid) once the user has signed in through Entra
    external_id: Mapped[str | None] = mapped_column(String(64), unique=True, index=True)
    display_name: Mapped[str | None] = mapped_column(String(200))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    roles: Mapped[list["UserRole"]] = relationship(back_populates="user", lazy="selectin")

    @property
    def role_names(self) -> list[str]:
        return sorted(r.role for r in self.roles)

    @property
    def is_admin(self) -> bool:
        return any(r.role == ROLE_ADMIN for r in self.roles)


class UserRole(Base):
    __tablename__ = "user_roles"
    __table_args__ = (UniqueConstraint("user_id", "role", name="uq_user_role"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    role: Mapped[str] = mapped_column(String(20))

    user: Mapped[User] = relationship(back_populates="roles")


class LineOfBusiness(Base):
    __tablename__ = "lines_of_business"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(200))
    slug: Mapped[str] = mapped_column(String(100), unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Client(Base):
    """Carrier / insured the loss run belongs to."""

    __tablename__ = "clients"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(200), index=True)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Template(Base):
    """Extraction agent: the field schema pulled from a loss run (shown as "Agent" in the UI)."""

    __tablename__ = "templates"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(300))
    lob_id: Mapped[str] = mapped_column(ForeignKey("lines_of_business.id"), index=True)
    fields: Mapped[list] = mapped_column(JSON, default=list)
    is_golden: Mapped[bool] = mapped_column(Boolean, default=False)
    is_system: Mapped[bool] = mapped_column(Boolean, default=False)
    label: Mapped[str] = mapped_column(String(20), default="Custom")
    owner_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), index=True)
    source_file_path: Mapped[str | None] = mapped_column(String(1000))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    lob: Mapped[LineOfBusiness] = relationship(lazy="joined")


# At most one golden agent per line of business (filtered index on both SQLite and SQL Server).
Index(
    "one_golden_per_lob",
    Template.lob_id,
    unique=True,
    sqlite_where=Template.is_golden == true(),
    mssql_where=Template.is_golden == true(),
)


class UserTemplateAccess(Base):
    __tablename__ = "user_template_access"

    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), primary_key=True)
    template_id: Mapped[str] = mapped_column(ForeignKey("templates.id"), primary_key=True)
    granted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ExtractionJob(Base):
    __tablename__ = "extraction_jobs"
    __table_args__ = (Index("ix_jobs_status_created", "status", "created_at"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    client_id: Mapped[str | None] = mapped_column(ForeignKey("clients.id"), index=True)
    template_id: Mapped[str] = mapped_column(ForeignKey("templates.id"), index=True)
    lob_id: Mapped[str] = mapped_column(ForeignKey("lines_of_business.id"))
    name: Mapped[str] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(20), default=JOB_QUEUED)
    status_message: Mapped[str | None] = mapped_column(Text)
    # [{name, path, size, type}]
    source_files: Mapped[list] = mapped_column(JSON, default=list)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    claimed_by: Mapped[str | None] = mapped_column(String(200))
    claimed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    client: Mapped[Client | None] = relationship(lazy="joined")
    template: Mapped[Template] = relationship(lazy="joined")
    lob: Mapped[LineOfBusiness] = relationship(lazy="joined")


class ExtractionRow(Base):
    """One extracted claim."""

    __tablename__ = "extraction_rows"
    __table_args__ = (Index("ix_rows_job_index", "job_id", "row_index"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    job_id: Mapped[str] = mapped_column(ForeignKey("extraction_jobs.id"))
    row_index: Mapped[int] = mapped_column(Integer)
    source_file: Mapped[str | None] = mapped_column(String(500))
    data: Mapped[dict] = mapped_column(JSON, default=dict)
    included_in_export: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class DataQualityIssue(Base):
    __tablename__ = "data_quality_issues"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    job_id: Mapped[str] = mapped_column(ForeignKey("extraction_jobs.id"), index=True)
    row_id: Mapped[str | None] = mapped_column(ForeignKey("extraction_rows.id"), index=True)
    severity: Mapped[str] = mapped_column(String(20), default="warning")  # info | warning | error
    code: Mapped[str] = mapped_column(String(100))
    field: Mapped[str | None] = mapped_column(String(200))
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
