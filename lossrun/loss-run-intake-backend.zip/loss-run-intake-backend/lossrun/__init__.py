"""Loss run intake: BFF + extraction worker."""

__version__ = "1.0.0"
