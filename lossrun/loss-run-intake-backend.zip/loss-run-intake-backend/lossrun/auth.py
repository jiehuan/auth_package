"""Request identity.

AUTH_MODE:
  dev     every request is DEV_USER_EMAIL (local development only)
  entra   Microsoft Entra ID bearer token validated by the BFF (see entra.py)
  header  trusted identity header injected by an auth proxy in front of the route

Users are matched by Entra object id first, then by email (so members an admin
pre-provisioned by email are linked on their first Entra sign-in).
"""

from dataclasses import dataclass, field

from fastapi import Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .config import get_settings
from .db import get_db
from .models import ROLE_ADMIN, ROLE_MEMBER, User, UserRole, utcnow


@dataclass
class Identity:
    email: str
    name: str | None = None
    external_id: str | None = None
    roles: list[str] = field(default_factory=list)  # Entra app roles


def _identity_from_request(request: Request) -> Identity:
    s = get_settings()
    if s.auth_mode == "dev":
        return Identity(email=s.dev_user_email.lower(), name=s.dev_user_name)
    if s.auth_mode == "entra":
        from .entra import validate_token

        authz = request.headers.get("Authorization", "")
        if not authz.lower().startswith("bearer "):
            raise HTTPException(401, "Not authenticated", headers={"WWW-Authenticate": "Bearer"})
        ident = validate_token(authz[7:].strip())
        return Identity(email=ident.email, name=ident.name, external_id=ident.oid, roles=ident.roles)
    if s.auth_mode == "header":
        email = (request.headers.get(s.auth_user_header) or "").strip().lower()
        if not email:
            raise HTTPException(401, "Not authenticated")
        name = (request.headers.get(s.auth_name_header) or "").strip() or None
        return Identity(email=email, name=name)
    raise HTTPException(500, f"Unsupported AUTH_MODE {s.auth_mode!r}")


def ensure_role(db: Session, user: User, role: str) -> None:
    if role not in user.role_names:
        db.add(UserRole(user_id=user.id, role=role))
        db.flush()
        db.refresh(user)


def provision_user(db: Session, ident: Identity) -> User:
    """Create a user; the very first user (or anyone in ADMIN_EMAILS) becomes admin."""
    s = get_settings()
    first_admin = db.scalar(select(UserRole.id).where(UserRole.role == ROLE_ADMIN).limit(1)) is None
    user = User(
        email=ident.email,
        external_id=ident.external_id,
        display_name=ident.name or ident.email.split("@")[0],
    )
    db.add(user)
    db.flush()
    db.add(UserRole(user_id=user.id, role=ROLE_MEMBER))
    if first_admin or ident.email in s.admin_email_set:
        db.add(UserRole(user_id=user.id, role=ROLE_ADMIN))
    db.flush()
    db.refresh(user)
    return user


def _find_user(db: Session, ident: Identity) -> User | None:
    if ident.external_id:
        u = db.scalar(select(User).where(User.external_id == ident.external_id))
        if u:
            return u
    return db.scalar(select(User).where(func.lower(User.email) == ident.email))


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    s = get_settings()
    ident = _identity_from_request(request)
    user = _find_user(db, ident)
    if user is None:
        if not s.auth_auto_provision:
            raise HTTPException(403, "Access is restricted. Ask an administrator to add you to the team.")
        try:
            user = provision_user(db, ident)
            db.commit()
        except IntegrityError:  # concurrent first request
            db.rollback()
            user = _find_user(db, ident)
    if user is None or not user.is_active:
        raise HTTPException(403, "Account disabled")

    changed = False
    if ident.external_id and user.external_id != ident.external_id:
        user.external_id = ident.external_id  # link a pre-provisioned member
        changed = True
    if user.email != ident.email and not db.scalar(
        select(User.id).where(func.lower(User.email) == ident.email, User.id != user.id)
    ):
        user.email = ident.email  # UPN / email changed in Entra
        changed = True
    if ident.name and user.display_name != ident.name and s.auth_mode == "entra":
        user.display_name = ident.name
        changed = True
    wants_admin = ident.email in s.admin_email_set or (
        s.entra_admin_role and s.entra_admin_role in ident.roles
    )
    if wants_admin and not user.is_admin:
        ensure_role(db, user, ROLE_ADMIN)
        changed = True

    now = utcnow()
    last = user.last_seen_at
    if last is not None and last.tzinfo is None:  # SQLite returns naive datetimes
        last = last.replace(tzinfo=now.tzinfo)
    if last is None or (now - last).total_seconds() > 300:  # avoid a write on every request
        user.last_seen_at = now
        changed = True
    if changed:
        db.commit()
    return user


def require_admin(user: User = Depends(current_user)) -> User:
    if not user.is_admin:
        raise HTTPException(403, "Forbidden: admin only")
    return user
