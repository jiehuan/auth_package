from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All runtime configuration comes from environment variables (see .env.example)."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Database -----------------------------------------------------------
    # SQLite now; later e.g.
    # mssql+mssqlpython://user:pass@server.database.windows.net:1433/db?Encrypt=yes
    database_url: str = "sqlite:////data/lossrun.db"
    db_echo: bool = False
    # create tables + seed reference data when the app starts (disable once migrations run as a job)
    db_init_on_startup: bool = True

    # --- File storage -------------------------------------------------------
    storage_backend: str = "local"  # local | azure_blob (not implemented yet)
    storage_dir: Path = Path("/data/files")
    max_upload_mb: int = 50

    # --- Auth ---------------------------------------------------------------
    # dev:    every request is DEV_USER_EMAIL (local development only)
    # entra:  Microsoft Entra ID — the SPA signs in with MSAL and sends a bearer access
    #         token; the BFF validates it against the tenant's signing keys
    # header: identity comes from a trusted header set by an auth proxy (e.g. oauth2-proxy)
    auth_mode: str = "dev"
    auth_user_header: str = "X-Forwarded-Email"
    auth_name_header: str = "X-Forwarded-Preferred-Username"
    auth_auto_provision: bool = True
    dev_user_email: str = "dev.user@example.com"
    dev_user_name: str = "Dev User"
    admin_emails: str = ""  # comma separated; always granted admin

    # --- Microsoft Entra ID (AUTH_MODE=entra) --------------------------------
    entra_tenant_id: str = ""
    entra_api_client_id: str = ""  # app registration that exposes the API
    entra_api_audience: str = ""  # defaults to api://<entra_api_client_id>
    entra_spa_client_id: str = ""  # SPA app registration (may be the same app)
    entra_api_scope: str = "access_as_user"  # delegated scope the SPA requests
    entra_admin_role: str = "LossRun.Admin"  # app role value that grants admin (optional)
    entra_authority_host: str = "https://login.microsoftonline.com"

    # --- LLM intake ---------------------------------------------------------
    # heuristic: no model, maps spreadsheet/CSV columns to agent fields by header name
    # disabled:  every LLM call fails with a clear "not configured" error
    # internal:  company LLM API (to be implemented in lossrun/llm/internal.py)
    llm_provider: str = "heuristic"
    llm_base_url: str = ""
    llm_api_key: str = ""
    llm_model: str = ""
    llm_timeout_seconds: int = 180

    # --- Worker -------------------------------------------------------------
    worker_poll_seconds: float = 3.0
    worker_job_lease_seconds: int = 900
    worker_heartbeat_file: Path = Path("/tmp/worker-heartbeat")

    # --- Web ----------------------------------------------------------------
    # Only needed if the SPA calls the API cross-origin (normally it goes through the frontend proxy)
    cors_origins: str = ""
    log_level: str = "INFO"

    @property
    def admin_email_set(self) -> set[str]:
        return {e.strip().lower() for e in self.admin_emails.split(",") if e.strip()}

    @property
    def entra_audiences(self) -> list[str]:
        aud = [a for a in (self.entra_api_audience, self.entra_api_client_id) if a]
        if self.entra_api_client_id and not self.entra_api_audience:
            aud.append(f"api://{self.entra_api_client_id}")
        return aud

    @property
    def entra_scope_uri(self) -> str:
        base = self.entra_api_audience or f"api://{self.entra_api_client_id}"
        return f"{base}/{self.entra_api_scope}"

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")


@lru_cache
def get_settings() -> Settings:
    return Settings()
