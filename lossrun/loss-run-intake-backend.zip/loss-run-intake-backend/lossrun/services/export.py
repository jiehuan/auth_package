"""Excel export: Summary / Claims / Data Quality sheets."""

import io

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import DataQualityIssue, ExtractionJob, ExtractionRow

HEADER_FILL = PatternFill("solid", fgColor="EEF2F7")
ERROR_FILL = PatternFill("solid", fgColor="FDE2E1")
WARN_FILL = PatternFill("solid", fgColor="FEF3C7")


def _fmt_dt(v) -> str:
    return v.strftime("%Y-%m-%d %H:%M UTC") if v else ""


def build_workbook(db: Session, job: ExtractionJob, selected_fields: list[str] | None) -> bytes:
    rows = list(
        db.scalars(select(ExtractionRow).where(ExtractionRow.job_id == job.id).order_by(ExtractionRow.row_index))
    )
    issues = list(db.scalars(select(DataQualityIssue).where(DataQualityIssue.job_id == job.id)))
    tpl_fields = [f for f in (job.template.fields or []) if f.get("key")]
    selected = [f for f in tpl_fields if f["key"] in selected_fields] if selected_fields else tpl_fields

    wb = Workbook()
    wb.properties.creator = "Loss Run Extractor"

    # Summary
    ws = wb.active
    ws.title = "Summary"
    for label, value in [
        ("Job Name", job.name),
        ("Client", job.client.name if job.client else ""),
        ("Line of Business", job.lob.name if job.lob else ""),
        ("Agent", job.template.name if job.template else ""),
        ("Status", job.status),
        ("Created", _fmt_dt(job.created_at)),
        ("Completed", _fmt_dt(job.completed_at)),
        ("Total Rows", len(rows)),
        ("Included in Export", sum(1 for r in rows if r.included_in_export)),
        ("Data Quality Issues", len(issues)),
    ]:
        ws.append([label, value])
        ws.cell(ws.max_row, 1).font = Font(bold=True)
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 60

    # Claims — rows with issues on an exported field are highlighted
    severity_by_row: dict[str, str] = {}
    bad_cells: set[tuple[str, str]] = set()
    for i in issues:
        if not i.row_id:
            continue
        if i.severity == "error" or severity_by_row.get(i.row_id) != "error":
            severity_by_row[i.row_id] = i.severity
        if i.field:
            bad_cells.add((i.row_id, i.field))

    cl = wb.create_sheet("Claims")
    cl.append(["Source File"] + [f.get("label") or f["key"] for f in selected])
    for c in cl[1]:
        c.font = Font(bold=True)
        c.fill = HEADER_FILL
    for r in rows:
        if not r.included_in_export:
            continue
        d = r.data or {}
        cl.append([r.source_file or ""] + [d.get(f["key"]) for f in selected])
        for col, f in enumerate(selected, start=2):
            if (r.id, f["key"]) in bad_cells:
                sev = severity_by_row.get(r.id)
                cl.cell(cl.max_row, col).fill = ERROR_FILL if sev == "error" else WARN_FILL
    cl.column_dimensions["A"].width = 24
    for idx in range(2, len(selected) + 2):
        cl.column_dimensions[cl.cell(1, idx).column_letter].width = 22
    cl.freeze_panes = "B2"

    # Data quality
    dq = wb.create_sheet("Data Quality")
    dq.append(["Severity", "Code", "Field", "Message"])
    for c in dq[1]:
        c.font = Font(bold=True)
        c.fill = HEADER_FILL
    for i in issues:
        dq.append([i.severity, i.code, i.field or "", i.message])
    for col, w in zip("ABCD", (12, 26, 22, 80)):
        dq.column_dimensions[col].width = w

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
