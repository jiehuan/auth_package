"""Data quality checks + cross-period reconciliation (pure Python, no model)."""

from dataclasses import dataclass

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..models import DataQualityIssue, ExtractionJob, ExtractionRow
from .normalize import parse_date

AMOUNT_FIELDS = ("reserve_indemnity", "reserve_expense", "paid_indemnity", "paid_expense")
DATE_FIELDS = ("date_of_loss", "date_reported")
DEVELOPMENT_FIELDS = ("paid_indemnity", "paid_expense", "incurred_total")


@dataclass
class Issue:
    severity: str
    code: str
    message: str
    field: str | None = None
    row_id: str | None = None


def _empty(v) -> bool:
    return v is None or v == ""


def _num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def check_rows(rows: list[ExtractionRow], fields: list[dict]) -> list[Issue]:
    required = [f["key"] for f in fields if f.get("required") and f.get("key")]
    issues: list[Issue] = []
    by_claim: dict[str, list[ExtractionRow]] = {}

    for r in rows:
        d = r.data or {}
        for k in required:
            if _empty(d.get(k)):
                issues.append(Issue("error", "MISSING_REQUIRED", f'Missing required field "{k}"', k, r.id))
        for k in AMOUNT_FIELDS:
            v = d.get(k)
            if _num(v) and v < 0:
                issues.append(Issue("warning", "NEGATIVE_AMOUNT", f"Negative value for {k}: {v}", k, r.id))
        for k in DATE_FIELDS:
            v = d.get(k)
            if not _empty(v) and parse_date(v) is None:
                issues.append(Issue("warning", "INVALID_DATE", f"Invalid date for {k}: {v}", k, r.id))
        cn = str(d.get("claim_number") or "").strip()
        if cn:
            by_claim.setdefault(cn, []).append(r)

    for cn, group in by_claim.items():
        if len(group) < 2:
            continue

        def sort_key(r: ExtractionRow):
            dt = parse_date((r.data or {}).get("date_reported"))
            return (dt.toordinal() if dt else 0, r.row_index)

        ordered = sorted(group, key=sort_key)
        for prev_row, cur_row in zip(ordered, ordered[1:]):
            prev, cur = prev_row.data or {}, cur_row.data or {}
            for k in DEVELOPMENT_FIELDS:
                if _num(prev.get(k)) and _num(cur.get(k)) and cur[k] < prev[k]:
                    issues.append(
                        Issue(
                            "warning",
                            "AMOUNT_REGRESSION",
                            f"Claim {cn}: {k} decreased from {prev[k]} to {cur[k]} across periods",
                            k,
                            cur_row.id,
                        )
                    )
            ps, cs = str(prev.get("status") or "").lower(), str(cur.get("status") or "").lower()
            if "closed" in ps and "open" in cs and "reopen" not in cs:
                issues.append(
                    Issue("info", "STATUS_REGRESSION", f"Claim {cn} reopened (was Closed, now Open)", "status", cur_row.id)
                )
        if len(group) > 5:
            issues.append(Issue("info", "DUPLICATE_CLAIM_HIGH", f"Claim number {cn} appears {len(group)} times"))
    return issues


def reconcile_job(db: Session, job: ExtractionJob) -> int:
    """Replace the job's issues with a fresh reconciliation. Caller commits."""
    rows = list(
        db.scalars(select(ExtractionRow).where(ExtractionRow.job_id == job.id).order_by(ExtractionRow.row_index))
    )
    # Keep issues raised during extraction (EXTRACTION_*); recompute everything else.
    db.execute(
        delete(DataQualityIssue).where(
            DataQualityIssue.job_id == job.id, ~DataQualityIssue.code.startswith("EXTRACTION_", autoescape=True)
        )
    )
    issues = check_rows(rows, job.template.fields or [])
    for i in issues:
        db.add(
            DataQualityIssue(
                job_id=job.id, row_id=i.row_id, severity=i.severity, code=i.code, field=i.field, message=i.message
            )
        )
    return len(issues)
