"""Run an extraction job end to end (called by the worker)."""

import logging

from sqlalchemy import delete
from sqlalchemy.orm import Session

from ..llm import FieldSpec, LLMError, LLMNotConfigured, get_llm
from ..models import (
    JOB_ERROR,
    JOB_READY,
    JOB_RECONCILING,
    DataQualityIssue,
    ExtractionJob,
    ExtractionRow,
    utcnow,
)
from ..storage import get_storage
from .documents import Document
from .normalize import normalize_row
from .reconcile import reconcile_job

log = logging.getLogger(__name__)


class JobFailed(Exception):
    pass


def run_job(db: Session, job: ExtractionJob, heartbeat=lambda: None) -> None:
    """Extract every source file, then reconcile. Commits as it goes so the UI sees progress."""
    fields = list(job.template.fields or [])
    if not fields:
        raise JobFailed("Agent has no fields")
    specs = [FieldSpec.from_dict(f) for f in fields if f.get("key")]
    llm = get_llm()
    storage = get_storage()

    db.execute(delete(DataQualityIssue).where(DataQualityIssue.job_id == job.id))
    db.execute(delete(ExtractionRow).where(ExtractionRow.job_id == job.id))
    db.commit()

    row_index = 0
    for src in job.source_files or []:
        name = src.get("name") or src.get("path")
        heartbeat()
        job.status_message = f"Extracting {name}"
        job.claimed_at = utcnow()
        db.commit()

        try:
            data = storage.get(src["path"])
        except FileNotFoundError as e:
            raise JobFailed(f"Source file missing from storage: {name}") from e

        try:
            doc = Document.load(name, src.get("type", ""), data)
            claims = llm.extract_claims(doc, specs)
        except (LLMNotConfigured, NotImplementedError) as e:
            raise JobFailed(str(e) or "LLM intake is not implemented yet") from e
        except LLMError as e:
            db.add(
                DataQualityIssue(
                    job_id=job.id,
                    severity="error",
                    code="EXTRACTION_PARSE_FAILED",
                    message=f"Could not parse extraction output for {name}: {e}",
                )
            )
            db.commit()
            continue
        except Exception as e:  # corrupt file etc. — record and keep going with the other files
            log.exception("extraction failed for %s", name)
            db.add(
                DataQualityIssue(
                    job_id=job.id,
                    severity="error",
                    code="EXTRACTION_FILE_FAILED",
                    message=f"Could not read {name}: {e}",
                )
            )
            db.commit()
            continue

        for raw in claims:
            db.add(
                ExtractionRow(
                    job_id=job.id,
                    row_index=row_index,
                    source_file=name,
                    data=normalize_row(raw, fields),
                )
            )
            row_index += 1
        db.commit()

    job.status = JOB_RECONCILING
    job.status_message = "Reconciling"
    db.commit()

    issue_count = reconcile_job(db, job)
    job.status = JOB_READY
    job.status_message = f"Extracted {row_index} claims. Reconciliation flagged {issue_count} issues."
    job.completed_at = utcnow()
    job.claimed_by = None
    db.commit()


def fail_job(db: Session, job_id: str, message: str) -> None:
    job = db.get(ExtractionJob, job_id)
    if job is None:
        return
    job.status = JOB_ERROR
    job.status_message = message[:2000]
    job.claimed_by = None
    db.commit()

