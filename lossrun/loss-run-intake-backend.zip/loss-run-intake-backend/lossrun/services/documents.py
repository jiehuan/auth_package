"""Turn uploaded files into something an extractor can read."""

import csv
import io
from dataclasses import dataclass, field
from typing import Literal

DocKind = Literal["pdf", "sheet", "text"]

SHEET_EXTS = (".xlsx", ".xlsm", ".xls", ".csv")


def doc_kind(name: str, content_type: str = "") -> DocKind:
    lower = name.lower()
    ct = (content_type or "").lower()
    if ct == "application/pdf" or lower.endswith(".pdf"):
        return "pdf"
    if lower.endswith(SHEET_EXTS) or "spreadsheet" in ct or "excel" in ct or ct == "text/csv":
        return "sheet"
    return "text"


def _cell(v) -> str:
    if v is None:
        return ""
    if hasattr(v, "isoformat"):
        # datetime/date -> ISO date when there is no time part
        s = v.isoformat()
        return s[:10] if s.endswith("T00:00:00") or len(s) == 10 else s
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def read_sheets(data: bytes, name: str) -> dict[str, list[list[str]]]:
    """Return {sheet_name: rows} with every cell as a string (header row included)."""
    lower = name.lower()
    if lower.endswith(".csv"):
        text = data.decode("utf-8-sig", errors="replace")
        rows = [list(r) for r in csv.reader(io.StringIO(text, newline=""))]
        return {"Sheet1": rows}
    if lower.endswith(".xls"):
        import xlrd

        book = xlrd.open_workbook(file_contents=data)
        out: dict[str, list[list[str]]] = {}
        for sh in book.sheets():
            rows = []
            for r in range(sh.nrows):
                row = []
                for c in range(sh.ncols):
                    cell = sh.cell(r, c)
                    if cell.ctype == xlrd.XL_CELL_DATE:
                        row.append(_cell(xlrd.xldate.xldate_as_datetime(cell.value, book.datemode)))
                    else:
                        row.append(_cell(cell.value))
                rows.append(row)
            out[sh.name] = rows
        return out

    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    try:
        out = {}
        for ws in wb.worksheets:
            out[ws.title] = [[_cell(v) for v in row] for row in ws.iter_rows(values_only=True)]
        return out
    finally:
        wb.close()


def _trim(rows: list[list[str]]) -> list[list[str]]:
    rows = [r for r in rows if any(c.strip() for c in r)]
    width = max((max((i for i, c in enumerate(r) if c.strip()), default=-1) for r in rows), default=-1) + 1
    return [r[:width] + [""] * (width - len(r[:width])) for r in rows]


def _header_index(rows: list[list[str]]) -> int:
    """Loss runs often have title/as-of lines above the table: take the first row
    (within the first 30) that is about as wide as the widest row."""
    counts = [sum(1 for c in r if c.strip()) for r in rows[:30]]
    if not counts:
        return 0
    threshold = max(2, int(0.6 * max(counts)))
    return next((i for i, c in enumerate(counts) if c >= threshold), 0)


def sheet_records(rows: list[list[str]]) -> list[dict[str, str]]:
    """Detect the header row; returns list of {header: value} for the rows below it."""
    rows = _trim(rows)
    if not rows:
        return []
    h = _header_index(rows)
    header, seen = [], set()
    for i, name in enumerate(rows[h]):
        name = name.strip() or f"column_{i + 1}"
        while name in seen:
            name += "_"
        seen.add(name)
        header.append(name)
    return [dict(zip(header, r)) for r in rows[h + 1 :]]


def pdf_page_count(data: bytes) -> int:
    try:
        from pypdf import PdfReader

        return max(1, len(PdfReader(io.BytesIO(data)).pages))
    except Exception:
        return 1


def pdf_text(data: bytes, page: int | None = None, max_chars: int = 200_000) -> str:
    """Best-effort text layer extraction (scanned PDFs return little or nothing)."""
    try:
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        pages = reader.pages if page is None else [reader.pages[page - 1]]
        parts = []
        for i, p in enumerate(pages, start=1 if page is None else page):
            parts.append(f"--- Page {i} ---\n{p.extract_text() or ''}")
        return "\n".join(parts)[:max_chars]
    except Exception:
        return ""


def list_pages(data: bytes, name: str, content_type: str = "") -> list[str]:
    kind = doc_kind(name, content_type)
    if kind == "sheet":
        return list(read_sheets(data, name).keys()) or ["Sheet1"]
    if kind == "pdf":
        return [f"Page {i + 1}" for i in range(pdf_page_count(data))]
    return ["Document"]


def sheet_preview(data: bytes, name: str, sheet: str, limit: int = 50) -> tuple[list[list[str]], int]:
    sheets = read_sheets(data, name)
    if not sheets:
        return [], 0
    rows = _trim(sheets.get(sheet) or next(iter(sheets.values())))
    return rows[:limit], len(rows)


def sheet_as_text(data: bytes, name: str, sheet: str | None = None, limit: int = 500) -> str:
    """Compact JSON-ish text of one or all sheets, for LLM prompts."""
    import json

    sheets = read_sheets(data, name)
    selected = {sheet: sheets[sheet]} if sheet and sheet in sheets else sheets
    out = [f"# File: {name}"]
    for sname, rows in selected.items():
        recs = sheet_records(rows)
        out.append(f"\n## Sheet: {sname} ({len(recs)} rows)")
        out.append(json.dumps(recs[:limit], ensure_ascii=False))
        if len(recs) > limit:
            out.append(f"... ({len(recs) - limit} more rows truncated)")
    return "\n".join(out)


@dataclass
class Document:
    """What the LLM layer receives. ``data`` is always the raw bytes; ``text`` is a
    pre-rendered text view (sheets as JSON records, PDFs via their text layer)."""

    name: str
    content_type: str
    data: bytes
    kind: DocKind
    page: str | None = None  # restrict to one page/sheet (template inference)
    text: str = ""
    sheets: dict[str, list[list[str]]] = field(default_factory=dict)

    @classmethod
    def load(cls, name: str, content_type: str, data: bytes, page: str | None = None) -> "Document":
        kind = doc_kind(name, content_type)
        doc = cls(name=name, content_type=content_type, data=data, kind=kind, page=page)
        if kind == "sheet":
            doc.sheets = read_sheets(data, name)
            doc.text = sheet_as_text(data, name, page)
        elif kind == "pdf":
            page_no = None
            if page and page.lower().startswith("page "):
                try:
                    page_no = int(page.split()[1])
                except (IndexError, ValueError):
                    page_no = None
            doc.text = pdf_text(data, page_no)
        else:
            doc.text = data.decode("utf-8", errors="replace")[:200_000]
        return doc
