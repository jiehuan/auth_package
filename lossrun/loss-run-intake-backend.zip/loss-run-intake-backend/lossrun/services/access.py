"""Row-level visibility rules (formerly database RLS policies)."""

from fastapi import HTTPException
from sqlalchemy import Select, exists, or_, select
from sqlalchemy.orm import Session

from ..models import Client, ExtractionJob, Template, User, UserTemplateAccess


def visible_templates(user: User) -> Select:
    q = select(Template)
    if user.is_admin:
        return q
    granted = exists().where(
        UserTemplateAccess.template_id == Template.id, UserTemplateAccess.user_id == user.id
    )
    return q.where(or_(Template.is_system.is_(True), Template.owner_user_id == user.id, granted))


def visible_clients(user: User) -> Select:
    q = select(Client)
    return q if user.is_admin else q.where(Client.created_by == user.id)


def visible_jobs(user: User) -> Select:
    q = select(ExtractionJob)
    return q if user.is_admin else q.where(ExtractionJob.user_id == user.id)


def get_template_or_404(db: Session, user: User, template_id: str) -> Template:
    t = db.scalar(visible_templates(user).where(Template.id == template_id))
    if t is None:
        raise HTTPException(404, "Agent not found")
    return t


def get_job_or_404(db: Session, user: User, job_id: str) -> ExtractionJob:
    j = db.scalar(visible_jobs(user).where(ExtractionJob.id == job_id))
    if j is None:
        raise HTTPException(404, "Job not found")
    return j


def can_edit_template(user: User, t: Template) -> bool:
    return (not t.is_system) and (user.is_admin or t.owner_user_id == user.id)
