"""Demo dataset for an underwriter-friendly first run (admin only, idempotent)."""

import json
from pathlib import Path

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..models import (
    JOB_READY,
    Client,
    DataQualityIssue,
    ExtractionJob,
    ExtractionRow,
    LineOfBusiness,
    Template,
    User,
    utcnow,
)

DEMO_MARKER = "Acme Logistics Inc."
DEMO_CLIENTS = [DEMO_MARKER, "Northwind Manufacturing", "Coastal Restaurant Group", "Meridian Tech Holdings"]
DEMO_JOBS = {
    "auto": "Acme Logistics — Auto Loss Run 2022–2024",
    "wc": "Northwind Manufacturing — Workers Comp 3-yr",
    "gl": "Coastal Restaurant Group — GL Loss Run",
}
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _rows() -> dict[str, list[dict]]:
    return json.loads((Path(__file__).parent / "demo_rows.json").read_text(encoding="utf-8"))


def seed_demo(db: Session, user: User) -> dict:
    if db.scalar(select(Client.id).where(Client.name == DEMO_MARKER).limit(1)):
        return {"ok": True, "skipped": True}

    lob_by_slug = {l.slug: l.id for l in db.scalars(select(LineOfBusiness))}
    golden: dict[str, str] = {}
    for t in db.scalars(select(Template).where(Template.is_system.is_(True), Template.is_golden.is_(True))):
        golden[t.lob_id] = t.id
    lobs = {"auto": lob_by_slug.get("auto"), "wc": lob_by_slug.get("workers-comp"), "gl": lob_by_slug.get("general-liability")}
    if not all(lobs.values()) or not all(golden.get(l) for l in lobs.values()):
        raise ValueError("Missing golden agents for demo lines of business")

    clients = {name: Client(name=name, created_by=user.id) for name in DEMO_CLIENTS}
    db.add_all(clients.values())
    db.flush()

    now = utcnow()
    spec = {
        "auto": (
            DEMO_MARKER,
            [("acme_auto_2022.pdf", 184320), ("acme_auto_2023.pdf", 192840), ("acme_auto_2024.pdf", 201456)],
            "Extracted 12 claims. Reconciliation flagged 2 issues.",
        ),
        "wc": (
            "Northwind Manufacturing",
            [("northwind_wc_loss_run.xlsx", 78412)],
            "Extracted 15 claims. Reconciliation flagged 1 issue.",
        ),
        "gl": (
            "Coastal Restaurant Group",
            [("coastal_gl_2022_2024.pdf", 246800)],
            "Extracted 8 claims. Reconciliation flagged 1 issue.",
        ),
    }
    jobs: dict[str, ExtractionJob] = {}
    for key, (client_name, files, msg) in spec.items():
        jobs[key] = ExtractionJob(
            user_id=user.id,
            name=DEMO_JOBS[key],
            client_id=clients[client_name].id,
            template_id=golden[lobs[key]],
            lob_id=lobs[key],
            source_files=[
                {"name": n, "path": f"demo/{n}", "size": s, "type": XLSX if n.endswith(".xlsx") else "application/pdf"}
                for n, s in files
            ],
            status=JOB_READY,
            status_message=msg,
            completed_at=now,
        )
    db.add_all(jobs.values())
    db.flush()

    data = _rows()
    inserted: dict[str, list[ExtractionRow]] = {}
    for key, rows in data.items():
        out = []
        for i, d in enumerate(rows):
            if key == "auto":
                src = f"acme_auto_{2022 + min(2, i // 4)}.pdf"
            elif key == "wc":
                src = "northwind_wc_loss_run.xlsx"
            else:
                src = "coastal_gl_2022_2024.pdf"
            out.append(ExtractionRow(job_id=jobs[key].id, row_index=i, source_file=src, data=d))
        db.add_all(out)
        inserted[key] = out
    db.flush()

    def find(key: str, claim: str) -> list[ExtractionRow]:
        return [r for r in inserted[key] if r.data.get("claim_number") == claim]

    issues: list[DataQualityIssue] = []
    auto_id, wc_id, gl_id = jobs["auto"].id, jobs["wc"].id, jobs["gl"].id
    dup = find("auto", "AU-24-3055")
    for r in dup:
        issues.append(DataQualityIssue(job_id=auto_id, row_id=r.id, severity="error", code="DUPLICATE_CLAIM_NUMBER",
                                       field="claim_number",
                                       message="Claim number AU-24-3055 appears more than once across source files."))
    if dup:
        issues.append(DataQualityIssue(job_id=auto_id, row_id=dup[0].id, severity="error", code="NEGATIVE_RESERVE",
                                       field="reserve_indemnity",
                                       message="Reserve indemnity is negative (-1,500). Reserves should be zero or positive."))
    for r in find("auto", "AU-23-2071")[:1]:
        issues.append(DataQualityIssue(job_id=auto_id, row_id=r.id, severity="warning", code="INCURRED_DEVELOPMENT",
                                       field="incurred_total",
                                       message="Incurred developed materially across valuation dates (>30% increase). Review reserve adequacy."))
    for job_id, key, claim in ((gl_id, "gl", "GL-2024-0009"), (wc_id, "wc", "WC-23-6045")):
        for r in find(key, claim)[:1]:
            issues.append(DataQualityIssue(job_id=job_id, row_id=r.id, severity="warning", code="MISSING_DATE_REPORTED",
                                           field="date_reported",
                                           message="Missing date_reported — cannot compute lag-to-report."))
    db.add_all(issues)
    db.commit()
    return {
        "ok": True,
        "skipped": False,
        "clients": len(clients),
        "jobs": len(jobs),
        "rows": sum(len(v) for v in inserted.values()),
        "issues": len(issues),
    }


def clear_demo(db: Session) -> dict:
    job_ids = list(db.scalars(select(ExtractionJob.id).where(ExtractionJob.name.in_(DEMO_JOBS.values()))))
    if job_ids:
        db.execute(delete(DataQualityIssue).where(DataQualityIssue.job_id.in_(job_ids)))
        db.execute(delete(ExtractionRow).where(ExtractionRow.job_id.in_(job_ids)))
        db.execute(delete(ExtractionJob).where(ExtractionJob.id.in_(job_ids)))
    client_ids = list(db.scalars(select(Client.id).where(Client.name.in_(DEMO_CLIENTS))))
    if client_ids:
        # detach any real jobs that happen to reference a demo client name
        for j in db.scalars(select(ExtractionJob).where(ExtractionJob.client_id.in_(client_ids))):
            j.client_id = None
        db.execute(delete(Client).where(Client.id.in_(client_ids)))
    db.commit()
    return {"ok": True}
