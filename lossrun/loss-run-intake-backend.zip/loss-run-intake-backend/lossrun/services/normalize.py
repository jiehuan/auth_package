"""Coerce extracted values to the agent's field types, whatever the provider returned."""

import re
from datetime import date, datetime

DATE_FORMATS = (
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%m/%d/%Y",
    "%m/%d/%y",
    "%m-%d-%Y",
    "%d-%b-%Y",
    "%d %b %Y",
    "%b %d, %Y",
    "%B %d, %Y",
    "%Y%m%d",
)


def parse_date(v) -> date | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v).strip()
    if not s:
        return None
    s = s[:19] if "T" in s else s
    try:
        return datetime.fromisoformat(s).date()
    except ValueError:
        pass
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


_NUM_JUNK = re.compile(r"[,$€£¥\s]|USD|EUR|GBP", re.IGNORECASE)


def parse_number(v) -> float | int | None:
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    if not s or s in {"-", "—", "N/A", "n/a"}:
        return None
    neg = s.startswith("(") and s.endswith(")")
    s = _NUM_JUNK.sub("", s.strip("()"))
    try:
        n = float(s)
    except ValueError:
        return None
    n = -n if neg else n
    return int(n) if n.is_integer() else n


def parse_bool(v) -> bool | None:
    if v is None or isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {"y", "yes", "true", "1"}:
        return True
    if s in {"n", "no", "false", "0"}:
        return False
    return None


def normalize_row(raw: dict, fields: list[dict]) -> dict:
    out: dict = {}
    for f in fields:
        key = f.get("key")
        if not key:
            continue
        v = raw.get(key)
        if isinstance(v, str):
            v = v.strip() or None
        t = f.get("type") or "string"
        if v is None:
            out[key] = None
        elif t == "number":
            n = parse_number(v)
            out[key] = n if n is not None else v  # keep original so reconciliation can flag it
        elif t == "date":
            d = parse_date(v)
            out[key] = d.isoformat() if d else str(v)
        elif t == "boolean":
            b = parse_bool(v)
            out[key] = b if b is not None else v
        else:
            out[key] = v if isinstance(v, (str, int, float, bool)) else str(v)
    return out
