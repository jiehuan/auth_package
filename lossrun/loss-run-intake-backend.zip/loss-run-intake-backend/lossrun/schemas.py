"""Request bodies + response serializers."""

import re
from datetime import timezone
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from .models import (
    Client,
    DataQualityIssue,
    ExtractionJob,
    ExtractionRow,
    LineOfBusiness,
    Template,
    User,
)

_KEY_RE = re.compile(r"[^a-z0-9_]+")


class FieldIn(BaseModel):
    key: str = Field(min_length=1, max_length=100)
    label: str = Field(min_length=1, max_length=300)
    type: Literal["string", "number", "date", "boolean"] = "string"
    required: bool = False
    hint: str = ""
    value: str = ""

    @field_validator("key")
    @classmethod
    def _snake(cls, v: str) -> str:
        v = _KEY_RE.sub("_", v.strip().lower()).strip("_")
        if not v:
            raise ValueError("key must contain letters or digits")
        return v


class TemplateCreate(BaseModel):
    name: str = Field(min_length=1, max_length=300)
    lob_id: str
    fields: list[FieldIn] = []
    clone_from: str | None = None
    source_file_path: str | None = None
    label: Literal["System", "Custom", "Carrier"] | None = None


class TemplateUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=300)
    fields: list[FieldIn] | None = None


class TemplateLabel(BaseModel):
    label: Literal["System", "Custom", "Carrier"]


class InferRequest(BaseModel):
    path: str
    name: str
    type: str = ""
    page: str = Field(min_length=1)


class ClientCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)


class RowPatch(BaseModel):
    data: dict | None = None
    included_in_export: bool | None = None


class BulkInclude(BaseModel):
    included: bool
    row_ids: list[str] | None = None  # None = all rows in the job


class ExportRequest(BaseModel):
    selected_fields: list[str] | None = None


class RoleChange(BaseModel):
    role: Literal["admin", "member"]
    grant: bool


class MemberCreate(BaseModel):
    email: str = Field(min_length=3, max_length=320, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    display_name: str | None = Field(default=None, max_length=200)


class TemplateAccessUpdate(BaseModel):
    template_ids: list[str]


# ------------------------------------------------------------------ serializers


def dt(v):
    """ISO 8601 with offset. SQLite hands back naive datetimes; they are stored as UTC."""
    if not v:
        return None
    if v.tzinfo is None:
        v = v.replace(tzinfo=timezone.utc)
    return v.isoformat()


def lob_out(l: LineOfBusiness | None) -> dict | None:
    return None if l is None else {"id": l.id, "name": l.name, "slug": l.slug}


def user_out(u: User) -> dict:
    return {
        "id": u.id,
        "email": u.email,
        "display_name": u.display_name,
        "roles": u.role_names,
        "is_admin": u.is_admin,
        "is_active": u.is_active,
        "created_at": dt(u.created_at),
        "last_seen_at": dt(u.last_seen_at),
    }


def client_out(c: Client) -> dict:
    return {"id": c.id, "name": c.name, "created_at": dt(c.created_at)}


def template_out(t: Template, can_edit: bool = False) -> dict:
    return {
        "id": t.id,
        "name": t.name,
        "lob_id": t.lob_id,
        "lob": lob_out(t.lob),
        "fields": t.fields or [],
        "is_golden": t.is_golden,
        "is_system": t.is_system,
        "label": t.label,
        "owner_user_id": t.owner_user_id,
        "can_edit": can_edit,
        "created_at": dt(t.created_at),
        "updated_at": dt(t.updated_at),
    }


def job_out(j: ExtractionJob, with_fields: bool = False) -> dict:
    tpl = {"id": j.template.id, "name": j.template.name} if j.template else None
    if tpl is not None and with_fields:
        tpl["fields"] = j.template.fields or []
    return {
        "id": j.id,
        "name": j.name,
        "user_id": j.user_id,
        "status": j.status,
        "status_message": j.status_message,
        "source_files": [
            {k: f.get(k) for k in ("name", "size", "type")} for f in (j.source_files or [])
        ],
        "client": {"id": j.client.id, "name": j.client.name} if j.client else None,
        "template": tpl,
        "lob": lob_out(j.lob),
        "attempts": j.attempts,
        "created_at": dt(j.created_at),
        "completed_at": dt(j.completed_at),
    }


def row_out(r: ExtractionRow) -> dict:
    return {
        "id": r.id,
        "row_index": r.row_index,
        "source_file": r.source_file,
        "data": r.data or {},
        "included_in_export": r.included_in_export,
    }


def issue_out(i: DataQualityIssue) -> dict:
    return {
        "id": i.id,
        "row_id": i.row_id,
        "severity": i.severity,
        "code": i.code,
        "field": i.field,
        "message": i.message,
    }
