"""File storage abstraction.

Keys are forward-slash paths such as ``uploads/<user_id>/<uuid>-<name>.pdf``.
``LocalStorage`` writes to a directory (a PVC on OpenShift). An Azure Blob / ADLS
backend can be added later by implementing the same four methods.
"""

import re
import uuid
from functools import lru_cache
from pathlib import Path
from typing import Protocol

from .config import get_settings


class Storage(Protocol):
    def put(self, key: str, data: bytes) -> None: ...
    def get(self, key: str) -> bytes: ...
    def delete(self, key: str) -> None: ...
    def exists(self, key: str) -> bool: ...


_SAFE = re.compile(r"[^A-Za-z0-9._-]+")


def safe_filename(name: str) -> str:
    base = Path(name).name or "file"
    cleaned = _SAFE.sub("_", base).strip("._") or "file"
    return cleaned[-150:]


def make_key(prefix: str, user_id: str, filename: str) -> str:
    return f"{prefix}/{user_id}/{uuid.uuid4().hex}-{safe_filename(filename)}"


class LocalStorage:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise ValueError("Invalid storage key")
        return p

    def put(self, key: str, data: bytes) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".part")
        tmp.write_bytes(data)
        tmp.replace(p)

    def get(self, key: str) -> bytes:
        p = self._path(key)
        if not p.is_file():
            raise FileNotFoundError(key)
        return p.read_bytes()

    def delete(self, key: str) -> None:
        self._path(key).unlink(missing_ok=True)

    def exists(self, key: str) -> bool:
        return self._path(key).is_file()


@lru_cache
def get_storage() -> Storage:
    settings = get_settings()
    if settings.storage_backend == "local":
        return LocalStorage(settings.storage_dir)
    raise NotImplementedError(
        f"STORAGE_BACKEND={settings.storage_backend!r} is not implemented yet (use 'local')"
    )
