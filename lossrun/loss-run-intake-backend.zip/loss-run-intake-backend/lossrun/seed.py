"""Reference data: lines of business + one golden system agent per line."""

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import LineOfBusiness, Template

LINES_OF_BUSINESS = [
    ("General Liability", "general-liability"),
    ("Property", "property"),
    ("Workers Compensation", "workers-comp"),
    ("Commercial Auto", "auto"),
    ("Cyber", "cyber"),
    ("Marine", "marine"),
    ("Professional Liability", "professional"),
    ("Umbrella / Excess", "umbrella"),
]


def _f(key: str, label: str, type_: str, required: bool = False, hint: str = "") -> dict:
    return {"key": key, "label": label, "type": type_, "required": required, "hint": hint, "value": ""}


GENERIC_LOSS_RUN_FIELDS = [
    _f("claim_number", "Claim Number", "string", True, "Unique claim identifier"),
    _f("policy_number", "Policy Number", "string"),
    _f("date_of_loss", "Date of Loss", "date", True, "YYYY-MM-DD"),
    _f("date_reported", "Date Reported", "date", False, "YYYY-MM-DD"),
    _f("claimant", "Claimant", "string"),
    _f("cause_of_loss", "Cause of Loss", "string"),
    _f("description", "Description", "string", False, "Loss description"),
    _f("status", "Status", "string", False, "Open/Closed/Reopened"),
    _f("paid_indemnity", "Paid Indemnity", "number", False, "Amount in USD"),
    _f("paid_expense", "Paid Expense", "number", False, "Amount in USD"),
    _f("reserve_indemnity", "Reserve Indemnity", "number", False, "Amount in USD"),
    _f("reserve_expense", "Reserve Expense", "number", False, "Amount in USD"),
    _f("incurred_total", "Total Incurred", "number", False, "Paid + Reserve"),
    _f("deductible", "Deductible", "number"),
    _f("currency", "Currency", "string", False, "ISO code, e.g. USD"),
]


def seed_reference_data(db: Session) -> None:
    existing = {l.slug: l for l in db.scalars(select(LineOfBusiness))}
    for name, slug in LINES_OF_BUSINESS:
        if slug not in existing:
            lob = LineOfBusiness(name=name, slug=slug)
            db.add(lob)
            existing[slug] = lob
    db.flush()

    for lob in existing.values():
        has_system = db.scalar(
            select(Template.id).where(Template.lob_id == lob.id, Template.is_system.is_(True)).limit(1)
        )
        if has_system:
            continue
        has_golden = db.scalar(
            select(Template.id).where(Template.lob_id == lob.id, Template.is_golden.is_(True)).limit(1)
        )
        db.add(
            Template(
                name=f"Generic {lob.name} Loss Run",
                lob_id=lob.id,
                fields=[dict(f) for f in GENERIC_LOSS_RUN_FIELDS],
                is_system=True,
                is_golden=not has_golden,
                label="System",
            )
        )
    db.flush()
