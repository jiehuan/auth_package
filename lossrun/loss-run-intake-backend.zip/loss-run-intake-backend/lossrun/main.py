"""BFF: JSON API under /api.

The React SPA lives in the separate frontend repo; its container serves the static
files and reverse-proxies /api to this service, so the browser sees one origin.
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from . import __version__
from .api import admin, jobs, reference, templates
from .config import get_settings
from .db import engine, init_db
from .llm import get_llm

settings = get_settings()
logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("lossrun.app")


@asynccontextmanager
async def lifespan(_: FastAPI):
    if settings.db_init_on_startup:
        init_db()
    log.info(
        "started v%s db=%s auth=%s llm=%s",
        __version__,
        engine.url.render_as_string(hide_password=True),
        settings.auth_mode,
        get_llm().name,
    )
    yield


app = FastAPI(title="Loss Run Extractor API", version=__version__, lifespan=lifespan, docs_url="/api/docs",
              openapi_url="/api/openapi.json", redoc_url=None)

if settings.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

for r in (reference.router, templates.router, jobs.router, admin.router):
    app.include_router(r)


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    log.exception("unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse({"detail": "Internal server error"}, status_code=500)


@app.get("/api/config", include_in_schema=False)
def public_config():
    """Unauthenticated runtime config for the SPA (same image in every environment)."""
    cfg: dict = {"auth_mode": settings.auth_mode}
    if settings.auth_mode == "entra":
        cfg["entra"] = {
            "client_id": settings.entra_spa_client_id or settings.entra_api_client_id,
            "authority": f"{settings.entra_authority_host}/{settings.entra_tenant_id}",
            "scopes": [settings.entra_scope_uri],
        }
    return cfg


@app.get("/healthz", include_in_schema=False)
def healthz():
    return {"status": "ok"}


@app.get("/readyz", include_in_schema=False)
def readyz():
    with engine.connect() as c:
        c.execute(text("SELECT 1"))
    return {"status": "ready"}
