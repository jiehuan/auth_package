# Loss Run Intake — Backend (API + worker)

Python backend for the loss run intake platform. One code base and **one image**
(`loss-run-intake-backend`) that runs in two roles:

* **api** (default command) — FastAPI BFF under `/api`. Stores uploads, writes a job row with
  status `queued`, and returns immediately. Also serves agents, reconciliation, Excel export,
  team admin and the public `/api/config` the SPA boots from.
* **worker** (command `python -m lossrun.worker`) — polls for `queued` jobs (atomic claim, safe with several
  workers), extracts each source file through the LLM intake interface, reconciles, and sets
  `ready` / `error`. Jobs whose worker died are re-queued after `WORKER_JOB_LEASE_SECONDS`;
  crashes retry up to 3×.

The React SPA is in **loss-run-intake-frontend**. Its container serves the static files and
reverse-proxies `/api` to this service, so the API Service has no Route of its own.

```
browser ─► Route ─► frontend ──/api──► api ──┐
                                             ├─► DB     (SQLite ─► Azure SQL)
                               worker ───────┘   files  (PVC ─► Blob/ADLS)
                                 └─► LLMIntake ─► company LLM API (TBD)
```

## Layout

```
Dockerfile         single image; the Deployment picks the role via command
lossrun/
  main.py          FastAPI app                       worker.py   job runner (--once, --check)
  config.py        all settings (env vars)           auth.py     dev | entra | header
  entra.py         Entra ID token validation         models.py   SQLAlchemy models
  db.py seed.py    engine, create_all, lines of business + system agents
  storage.py       file storage abstraction (local dir now)
  api/             routers: reference, templates (agents), jobs, admin
  services/        documents (file parsing), normalize, reconcile, extraction, export, demo, access
  llm/             base.py (interface) · prompts.py · heuristic.py · disabled.py · internal.py (TODO)
tests/             pytest: API + worker end-to-end, Entra token validation
deploy/openshift/  ConfigMap, Secret example, Service, sqlite/ and azure-sql/ variants
```

## Local development

```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env
uvicorn lossrun.main:app --reload --port 8080      # terminal 1
python -m lossrun.worker                           # terminal 2
pytest -q
```

API docs: `http://localhost:8080/api/docs`. Start the frontend with `npm run dev` in the
frontend repo (it proxies `/api` to :8080). As an admin, **Load demo data** on the dashboard
creates three sample jobs.

## Configuration

All settings are environment variables (see `.env.example` and
`deploy/openshift/configmap.yaml`). The important ones:

| Variable | Default | Notes |
|---|---|---|
| `DATABASE_URL` | `sqlite:////data/lossrun.db` | SQLAlchemy URL |
| `DB_INIT_ON_STARTUP` | `true` | API creates tables + seed data on start |
| `STORAGE_DIR` | `/data/files` | uploaded loss runs and agent samples |
| `AUTH_MODE` | `dev` | `dev`, `entra`, `header` |
| `ADMIN_EMAILS` | | always admin; otherwise the first user becomes admin |
| `LLM_PROVIDER` | `heuristic` | `heuristic`, `disabled`, `internal` |
| `WORKER_POLL_SECONDS` | `3` | |
| `WORKER_JOB_LEASE_SECONDS` | `900` | stale-job requeue and worker liveness window |
| `MAX_UPLOAD_MB` | `50` | per file |
| `WEB_CONCURRENCY` | `1` | uvicorn workers; keep 1 on SQLite |

## Authentication

| Mode | Use | How identity is resolved |
|---|---|---|
| `dev` | local / first deployment | every request is `DEV_USER_EMAIL` |
| `entra` | **target** | SPA signs in with MSAL (redirect flow), sends `Authorization: Bearer <access token>`; BFF validates signature (tenant JWKS), issuer, audience, expiry, tenant, and the `access_as_user` scope |
| `header` | alternative | trusts `X-Forwarded-Email` from an auth proxy (e.g. oauth2-proxy for Entra) placed in front of the frontend Route; the proxy must overwrite that header on every request |

The frontend reads `GET /api/config` at startup, so the same image works in every environment.

### Entra ID setup (one app registration for SPA + API is fine)

1. **App registrations → New registration**, single tenant. Note the *Application (client) ID*
   and *Directory (tenant) ID*.
2. **Authentication → Add a platform → Single-page application**, redirect URI
   `https://<frontend-route-host>/` (add `http://localhost:5173/` for local dev).
3. **Expose an API** → set Application ID URI to `api://<client-id>` → add scope
   `access_as_user` (admins and users can consent).
4. **API permissions** → add *My APIs → this app → access_as_user* → grant admin consent.
5. Optional **App roles** → create `LossRun.Admin` (allowed member types: Users/Groups) and
   assign it under *Enterprise applications → Users and groups*. Users with that role become
   admins on sign-in. Admins can also be toggled on the Team page.
6. Optional **Enterprise application → Properties → Assignment required = Yes** to restrict
   who can sign in at all (then set `AUTH_AUTO_PROVISION=true`); or keep assignment open and set
   `AUTH_AUTO_PROVISION=false` so only members pre-added on the Team page get in.
7. Configure the app:

   ```
   AUTH_MODE=entra
   ENTRA_TENANT_ID=<tenant id>
   ENTRA_API_CLIENT_ID=<client id>
   ENTRA_SPA_CLIENT_ID=<client id>      # a different id if you split SPA and API registrations
   ```

The pod needs outbound HTTPS to `login.microsoftonline.com` to fetch signing keys.
Users are keyed by Entra object id (`oid`); members pre-added by email are linked on their
first sign-in, and UPN changes are picked up automatically.

## LLM intake

Everything that needs a model goes through `lossrun/llm/base.py::LLMIntake`:

| Method | Used by |
|---|---|
| `recommend_page(doc, pages)` | agent builder step 2 |
| `infer_fields(doc, page)` | agent builder step 3 |
| `extract_claims(doc, fields)` | worker, once per source file |

`Document` carries the raw bytes plus a text view (sheets as JSON records, PDFs via their text
layer). Prompts and JSON schemas from the original app are in `llm/prompts.py`.

To connect the company LLM: implement `InternalLLM._complete_json()` in `llm/internal.py`
(send prompt + document, return JSON matching the schema), then set `LLM_PROVIDER=internal`,
`LLM_BASE_URL`, `LLM_MODEL` and the `LLM_API_KEY` secret. Nothing else changes.

Until then `heuristic` maps spreadsheet/CSV columns to agent fields by header name (with a
synonym list and header-row detection), so the whole flow is testable. PDFs fail with a clear
"LLM intake not configured" message; **Re-run extraction** on the job page re-queues them once
the provider is in place. Extracted values are normalised to each field's type (numbers,
dates → `YYYY-MM-DD`) regardless of provider.

## Moving to Azure SQL

1. Build the image with `--build-arg INSTALL_MSSQL_ODBC=true` (msodbcsql18 + pyodbc).
2. Put `DATABASE_URL=mssql+pyodbc://…?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=yes` in the secret.
3. Deploy `deploy/openshift/azure-sql/deployments.yaml`: api and worker become separate,
   scalable Deployments. Uploaded files need a ReadWriteMany volume (e.g. Azure Files) until a
   Blob/ADLS backend is added to `storage.py` (implement `put/get/delete/exists`).

The models are already SQL-Server safe: string UUID keys, JSON as `NVARCHAR(max)`, filtered
unique index for "one golden agent per line of business", and no multi-path cascades (child
rows are deleted in code). Tables are created with `create_all` when the API starts; before running
several API replicas against a shared database, move schema changes to Alembic (run as a
pre-deploy job) and set `DB_INIT_ON_STARTUP=false`. Data is not migrated from SQLite automatically.

## Deploying on OpenShift (Harness)

```bash
docker build -t loss-run-intake-backend .
#   --build-arg PYTHON_IMAGE=<artifactory>/python:3.12-slim-bookworm
#   --build-arg PIP_INDEX_URL=https://<artifactory>/api/pypi/pypi-remote/simple
#   --build-arg INSTALL_MSSQL_ODBC=true        # Azure SQL phase
```

One Harness build per commit produces `loss-run-intake-backend:<tag>`. Both the api and the
worker containers use that tag, so they can never drift apart; the worker container only
overrides the command (`python -m lossrun.worker`). The image is based on
`python:3.12-slim-bookworm`, runs as an arbitrary non-root UID in group 0, and listens on 8080
in the api role.

**SQLite phase** (`deploy/openshift/sqlite/`): api and worker are two containers in one pod on
a single ReadWriteOnce block volume, `replicas: 1`, `strategy: Recreate`. SQLite runs in WAL
mode so both processes can use the file, but it must not sit on NFS/Azure Files or be opened
from two pods.

```bash
oc apply -f deploy/openshift/configmap.yaml
oc create secret generic loss-run-intake-secrets --from-literal=LLM_API_KEY=...   # or via Harness
oc apply -f deploy/openshift/sqlite/pvc.yaml -f deploy/openshift/sqlite/deployment.yaml
oc apply -f deploy/openshift/service.yaml
# then deploy the frontend repo (its Route is the public entry point)
```

Probes: api `GET /readyz` (DB reachable) and `GET /healthz`; worker
`python -m lossrun.worker --check` (heartbeat file freshness). The worker does not create
tables; if it starts before the API it just logs and retries.

## API overview

| | |
|---|---|
| `GET /api/config` | public runtime config (auth mode, Entra client settings) |
| `GET /api/me` · `GET /api/lobs` · `GET/POST/DELETE /api/clients` | reference data |
| `GET/POST /api/templates` · `GET/PATCH/DELETE /api/templates/{id}` · `POST …/copy` · `PUT …/label` | agents |
| `POST /api/template-sources` · `GET …/preview` · `POST …/infer` | agent builder |
| `GET/POST /api/jobs` · `GET/DELETE /api/jobs/{id}` · `GET …/status` | jobs (POST is multipart upload) |
| `POST /api/jobs/{id}/run` · `…/reconcile` · `…/export` | re-queue, reconcile, Excel download |
| `PATCH /api/jobs/{id}/rows/{row}` · `POST /api/jobs/{id}/rows/include` | row edits / include-in-export |
| `/api/admin/users…` · `/api/admin/users/{id}/template-access` · `/api/admin/demo/{seed,clear}` | admin |

Visibility: members see their own jobs and carriers, system agents, their own agents and agents
granted to them (`user_template_access`, via the admin API); admins see everything. System
agents are read-only (copy to edit). Agents used by a job cannot be deleted.

## Data quality checks

Per row: missing required fields (error), negative paid/reserve amounts, unparseable dates.
Across rows with the same claim number (ordered by report date): decreasing paid / incurred
amounts, Closed → Open status changes, claim numbers appearing more than five times.
Extraction failures are recorded as `EXTRACTION_*` issues and survive re-reconciliation.
