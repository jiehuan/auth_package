"""AUTH_MODE=entra with locally signed tokens (JWKS lookup is stubbed)."""

import time
import uuid

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

TENANT = "11111111-1111-1111-1111-111111111111"
API_ID = "22222222-2222-2222-2222-222222222222"
KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)


def token(**over) -> str:
    now = int(time.time())
    claims = {
        "iss": f"https://login.microsoftonline.com/{TENANT}/v2.0",
        "aud": f"api://{API_ID}",
        "tid": TENANT,
        "oid": over.pop("oid", str(uuid.uuid4())),
        "preferred_username": "Jane.Doe@corp.example",
        "name": "Jane Doe",
        "scp": "access_as_user",
        "iat": now,
        "nbf": now,
        "exp": now + 3600,
    }
    claims.update(over)
    claims = {k: v for k, v in claims.items() if v is not None}
    return jwt.encode(claims, KEY, algorithm="RS256", headers={"kid": "test"})


class _Key:
    key = KEY.public_key()


class _Jwks:
    def get_signing_key_from_jwt(self, _):
        return _Key()


@pytest.fixture
def entra(monkeypatch, client):
    from lossrun import entra as entra_mod
    from lossrun.config import get_settings

    s = get_settings()
    for k, v in dict(auth_mode="entra", entra_tenant_id=TENANT, entra_api_client_id=API_ID).items():
        monkeypatch.setattr(s, k, v)
    monkeypatch.setattr(entra_mod, "_jwks_client", lambda: _Jwks())
    return client


def hdr(t: str) -> dict:
    return {"Authorization": f"Bearer {t}"}


def test_config_endpoint(entra):
    cfg = entra.get("/api/config").json()
    assert cfg["auth_mode"] == "entra"
    assert cfg["entra"]["scopes"] == [f"api://{API_ID}/access_as_user"]


def test_valid_token_and_linking(entra):
    # an admin pre-provisions Jane by email; her first Entra sign-in links the account by oid
    from lossrun.config import get_settings

    s = get_settings()
    s.auth_mode = "header"
    admin = {"X-Forwarded-Email": "admin@example.com"}
    entra.get("/api/me", headers=admin)
    r = entra.post("/api/admin/users", headers=admin, json={"email": "jane.doe@corp.example"})
    s.auth_mode = "entra"
    assert r.status_code == 201
    oid = str(uuid.uuid4())

    me = entra.get("/api/me", headers=hdr(token(oid=oid))).json()
    assert me["id"] == r.json()["id"]
    assert me["email"] == "jane.doe@corp.example" and me["display_name"] == "Jane Doe"
    assert me["is_admin"] is False
    # renamed UPN, same oid -> same user
    me2 = entra.get("/api/me", headers=hdr(token(oid=oid, preferred_username="jane.smith@corp.example"))).json()
    assert me2["id"] == me["id"] and me2["email"] == "jane.smith@corp.example"


def test_app_role_grants_admin(entra):
    me = entra.get(
        "/api/me", headers=hdr(token(preferred_username="boss@corp.example", roles=["LossRun.Admin"]))
    ).json()
    assert me["is_admin"] is True


@pytest.mark.parametrize(
    "over,status",
    [
        ({"aud": "api://someone-else"}, 401),
        ({"iss": "https://login.microsoftonline.com/evil/v2.0"}, 401),
        ({"exp": int(time.time()) - 3600}, 401),
        ({"scp": "User.Read"}, 403),
        ({"tid": "33333333-3333-3333-3333-333333333333"}, 401),
    ],
)
def test_rejected_tokens(entra, over, status):
    assert entra.get("/api/me", headers=hdr(token(**over))).status_code == status


def test_missing_token(entra):
    assert entra.get("/api/me").status_code == 401
