import os
import sys
import tempfile
from pathlib import Path

import pytest

_tmp = Path(tempfile.mkdtemp(prefix="lossrun-test-"))
os.environ.update(
    DATABASE_URL=f"sqlite:///{_tmp / 'test.db'}",
    STORAGE_DIR=str(_tmp / "files"),
    AUTH_MODE="header",
    AUTH_AUTO_PROVISION="true",
    LLM_PROVIDER="heuristic",
    WORKER_HEARTBEAT_FILE=str(_tmp / "hb"),
)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture(scope="session")
def client():
    from fastapi.testclient import TestClient

    from lossrun.main import app

    with TestClient(app) as c:
        yield c


ADMIN = {"X-Forwarded-Email": "admin@example.com"}
MEMBER = {"X-Forwarded-Email": "member@example.com"}
