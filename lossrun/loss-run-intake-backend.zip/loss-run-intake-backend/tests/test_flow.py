"""End-to-end: upload a CSV loss run, let the worker extract it, reconcile, export."""

import io

from openpyxl import load_workbook

from .conftest import ADMIN, MEMBER

CSV = (
    "Claim #,Policy No,Loss Date,Reported Date,Claimant,Status,Paid Loss,Expense Paid,Loss Reserve,Total Incurred\n"
    "C-1,P-1,01/15/2023,01/20/2023,Smith,Closed,1000,200,0,1200\n"
    "C-2,P-1,2023-03-02,,Jones,Open,\"$2,500.00\",300,5000,7800\n"
    ",P-1,2023-04-10,2023-04-11,Doe,Open,10,0,-50,-40\n"
)


def test_first_user_is_admin(client):
    me = client.get("/api/me", headers=ADMIN).json()
    assert me["is_admin"] is True
    me2 = client.get("/api/me", headers=MEMBER).json()
    assert me2["is_admin"] is False


def test_unauthenticated(client):
    assert client.get("/api/me").status_code == 401


def test_extraction_flow(client):
    from lossrun.worker import run

    lobs = client.get("/api/lobs", headers=MEMBER).json()
    gl = next(l for l in lobs if l["slug"] == "general-liability")
    tpl = next(t for t in client.get("/api/templates", headers=MEMBER).json() if t["lob_id"] == gl["id"])
    assert tpl["is_system"] and not tpl["can_edit"]

    r = client.post(
        "/api/jobs",
        headers=MEMBER,
        data={"carrier_name": "Travelers", "lob_id": gl["id"], "template_id": tpl["id"]},
        files=[("files", ("loss_run.csv", CSV.encode(), "text/csv"))],
    )
    assert r.status_code == 201, r.text
    job = r.json()
    assert job["status"] == "queued"

    run(once=True)

    detail = client.get(f"/api/jobs/{job['id']}", headers=MEMBER).json()
    assert detail["job"]["status"] == "ready", detail["job"]
    rows = detail["rows"]
    assert len(rows) == 3
    assert rows[0]["data"]["date_of_loss"] == "2023-01-15"
    assert rows[1]["data"]["paid_indemnity"] == 2500
    codes = {i["code"] for i in detail["issues"]}
    assert "MISSING_REQUIRED" in codes and "NEGATIVE_AMOUNT" in codes

    # other users can't see it; admin can
    assert client.get(f"/api/jobs/{job['id']}", headers={"X-Forwarded-Email": "x@example.com"}).status_code == 404
    assert client.get(f"/api/jobs/{job['id']}", headers=ADMIN).status_code == 200

    # exclude one row, export two fields
    client.patch(f"/api/jobs/{job['id']}/rows/{rows[2]['id']}", headers=MEMBER, json={"included_in_export": False})
    x = client.post(
        f"/api/jobs/{job['id']}/export", headers=MEMBER, json={"selected_fields": ["claim_number", "paid_indemnity"]}
    )
    assert x.status_code == 200
    wb = load_workbook(io.BytesIO(x.content))
    assert wb.sheetnames == ["Summary", "Claims", "Data Quality"]
    claims = list(wb["Claims"].values)
    assert claims[0] == ("Source File", "Claim Number", "Paid Indemnity")
    assert len(claims) == 3

    assert client.post(f"/api/jobs/{job['id']}/reconcile", headers=MEMBER).json()["ok"]


def test_agent_builder(client):
    lobs = client.get("/api/lobs", headers=MEMBER).json()
    r = client.post(
        "/api/template-sources", headers=MEMBER, files={"file": ("sample.csv", CSV.encode(), "text/csv")}
    )
    assert r.status_code == 201, r.text
    src = r.json()
    assert src["pages"] == ["Sheet1"]
    prev = client.get(
        "/api/template-sources/preview", headers=MEMBER, params={"path": src["path"], "name": src["name"], "page": "Sheet1"}
    ).json()
    assert prev["total_rows"] == 4
    inf = client.post(
        "/api/template-sources/infer",
        headers=MEMBER,
        json={"path": src["path"], "name": src["name"], "type": src["type"], "page": "Sheet1"},
    ).json()
    keys = {f["key"]: f for f in inf["fields"]}
    assert keys["claim_number"]["value"] == "C-1"
    assert keys["date_of_loss"]["type"] == "date"
    # someone else can't read my source
    assert (
        client.post("/api/template-sources/infer", headers=ADMIN,
                    json={"path": src["path"], "name": src["name"], "page": "Sheet1"}).status_code == 404
    )
    t = client.post(
        "/api/templates",
        headers=MEMBER,
        json={"name": "Travelers GL", "lob_id": lobs[0]["id"], "fields": inf["fields"], "source_file_path": src["path"]},
    ).json()
    assert t["can_edit"]
    u = client.patch(f"/api/templates/{t['id']}", headers=MEMBER, json={"name": "Renamed"}).json()
    assert u["name"] == "Renamed"
    assert client.delete(f"/api/templates/{t['id']}", headers=MEMBER).json()["ok"]


def test_pdf_without_llm_fails_cleanly(client):
    from lossrun.worker import run

    lobs = client.get("/api/lobs", headers=MEMBER).json()
    tpl = next(t for t in client.get("/api/templates", headers=MEMBER).json() if t["lob_id"] == lobs[0]["id"])
    job = client.post(
        "/api/jobs",
        headers=MEMBER,
        data={"carrier_name": "travelers", "lob_id": lobs[0]["id"], "template_id": tpl["id"]},
        files=[("files", ("x.pdf", b"%PDF-1.4 fake", "application/pdf"))],
    ).json()
    assert job["client"]["name"] == "Travelers"  # carrier resolved case-insensitively
    run(once=True)
    j = client.get(f"/api/jobs/{job['id']}", headers=MEMBER).json()["job"]
    assert j["status"] == "error" and "LLM" in j["status_message"]
    assert client.post(f"/api/jobs/{job['id']}/run", headers=MEMBER).json()["status"] == "queued"


def test_admin_team_and_demo(client):
    assert client.get("/api/admin/users", headers=MEMBER).status_code == 403
    r = client.post("/api/admin/users", headers=ADMIN, json={"email": "New.Person@example.com"})
    assert r.status_code == 201
    uid = r.json()["id"]
    assert client.post("/api/admin/users", headers=ADMIN, json={"email": "new.person@example.com"}).status_code == 409
    client.put(f"/api/admin/users/{uid}/roles", headers=ADMIN, json={"role": "admin", "grant": True})
    me = client.get("/api/me", headers={"X-Forwarded-Email": "new.person@example.com"}).json()
    assert me["is_admin"]

    s = client.post("/api/admin/demo/seed", headers=ADMIN).json()
    assert s == {"ok": True, "skipped": False, "clients": 4, "jobs": 3, "rows": 35, "issues": 6}
    assert client.post("/api/admin/demo/seed", headers=ADMIN).json()["skipped"] is True
    assert client.post("/api/admin/demo/clear", headers=ADMIN).json()["ok"]


def test_stale_requeue():
    from datetime import timedelta

    from lossrun.db import SessionLocal
    from lossrun.models import ExtractionJob, utcnow
    from lossrun.worker import requeue_stale

    db = SessionLocal()
    job = db.query(ExtractionJob).first()
    job.status = "extracting"
    job.claimed_at = utcnow() - timedelta(hours=2)
    db.commit()
    assert requeue_stale(db) >= 1
    db.refresh(job)
    assert job.status == "queued"
    job.status = "extracting"
    job.claimed_at = utcnow()
    db.commit()
    assert requeue_stale(db) == 0
    db.close()
