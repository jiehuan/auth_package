import { createFileRoute } from "@tanstack/react-router";

import { countContractors } from "@/server/contractors.server";
import { handlePublic, json } from "@/server/http.server";

// Readiness/liveness probe. Touches the database, so a broken or unmounted
// volume shows up as a failing probe instead of a half-working app.
export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: handlePublic(() => json({ status: "ok", contractors: countContractors() })),
    },
  },
});
