#!/usr/bin/env node
// Prints an APP_USERS entry ("username:scrypt$...") for one account.
// Prompts go to stderr, so stdout is only the entry.
//
//   npm run hash-password -- hr1
//
// The password is read without echoing it. Put the entries for both accounts,
// separated by ";", into the APP_USERS secret.
import { randomBytes, scryptSync } from "node:crypto";
import { stdin, stderr, exit, argv } from "node:process";

const username = argv[2];
if (!username || !/^[A-Za-z0-9._@-]{1,100}$/.test(username)) {
  console.error("Usage: npm run hash-password -- <username>   (letters, digits, . _ @ -)");
  exit(1);
}

function ask(prompt) {
  return new Promise((resolve) => {
    stderr.write(prompt);
    if (!stdin.isTTY) {
      // piped input: echo "secret" | npm run hash-password -- hr1
      let data = "";
      stdin.setEncoding("utf8");
      stdin.on("data", (c) => (data += c));
      stdin.on("end", () => resolve(data.split(/\r?\n/)[0]));
      return;
    }
    let value = "";
    stdin.setRawMode(true);
    stdin.resume();
    stdin.setEncoding("utf8");
    const onData = (ch) => {
      if (ch === "\r" || ch === "\n" || ch === "\u0004") {
        stdin.setRawMode(false);
        stdin.pause();
        stdin.off("data", onData);
        stderr.write("\n");
        resolve(value);
      } else if (ch === "\u0003") {
        stderr.write("\n");
        exit(130);
      } else if (ch === "\u007f" || ch === "\b") {
        value = value.slice(0, -1);
      } else {
        value += ch;
      }
    };
    stdin.on("data", onData);
  });
}

const password = await ask(`Password for ${username}: `);
if (password.length < 10) {
  console.error("Use at least 10 characters.");
  exit(1);
}
if (stdin.isTTY) {
  const again = await ask("Repeat password: ");
  if (again !== password) {
    console.error("Passwords don't match.");
    exit(1);
  }
}

// Same parameters as src/server/auth.server.ts
const N = 16384,
  r = 8,
  p = 1;
const salt = randomBytes(16);
const hash = scryptSync(password, salt, 32, { N, r, p });
console.log(
  `${username}:scrypt$${N}$${r}$${p}$${salt.toString("base64")}$${hash.toString("base64")}`,
);
