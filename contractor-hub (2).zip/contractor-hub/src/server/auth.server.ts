// Sign-in for a fixed set of accounts.
//
// Accounts come from the APP_USERS environment variable (the
// contractor-hub-auth Secret in the cluster), one entry per account separated by ";":
//
//   APP_USERS="hr1:scrypt$16384$8$1$<salt>$<hash>;hr2:scrypt$...$..."
//
// Generate an entry with `npm run hash-password -- <username>`. Passwords are
// never stored in plain text. There is no user management in the app: to add,
// remove or change an account, edit the Secret and restart the pod.
//
// Sessions are server-side: the browser holds a random token in an HttpOnly
// cookie and the database stores only its SHA-256 hash, so signing out really
// ends the session.
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

import { ApiError } from "./contractors.server";
import { getDb } from "./db.server";

export const SESSION_COOKIE = "ch_session";
const SESSION_HOURS = 12;

type Account = { username: string; hash: string };

/* --------------------------------- accounts ------------------------------- */

function parseAccounts(raw: string): Map<string, Account> {
  const accounts = new Map<string, Account>();
  for (const entry of raw
    .split(";")
    .map((e) => e.trim())
    .filter(Boolean)) {
    const i = entry.indexOf(":");
    const username = entry.slice(0, i).trim();
    const hash = entry.slice(i + 1).trim();
    if (i < 1 || !hash.startsWith("scrypt$")) {
      throw new Error(`APP_USERS: entry "${entry.slice(0, 20)}…" is not "username:scrypt$…"`);
    }
    accounts.set(username.toLowerCase(), { username, hash });
  }
  return accounts;
}

let accounts: Map<string, Account> | undefined;

function getAccounts(): Map<string, Account> {
  if (accounts) return accounts;
  const raw = process.env["APP_USERS"]?.trim();
  if (raw?.includes("${secretDelegate")) {
    // Harness put its secret placeholder into the pod instead of the value.
    accounts = new Map();
    console.error(
      "[auth] APP_USERS contains an unresolved Harness secret placeholder — nobody can sign in. " +
        "Put the real value in the contractor-hub-auth Secret (see README, Sign-in).",
    );
  } else if (raw) {
    try {
      accounts = parseAccounts(raw);
      console.log(
        `[auth] ${accounts.size} account(s): ${[...accounts.values()].map((a) => a.username).join(", ")}`,
      );
    } catch (err) {
      accounts = new Map();
      console.error(`[auth] ${(err as Error).message} — nobody can sign in`);
    }
  } else if (process.env["NODE_ENV"] !== "production") {
    // Local development only: dev / dev
    accounts = new Map([["dev", { username: "dev", hash: hashPassword("dev") }]]);
    console.warn("[auth] APP_USERS is not set — using the local dev account dev / dev");
  } else {
    accounts = new Map();
    console.error("[auth] APP_USERS is not set — nobody can sign in");
  }
  return accounts;
}

/** Number of usable accounts (shown by /api/health, logs any configuration problem). */
export function accountCount(): number {
  return getAccounts().size;
}

/* -------------------------------- passwords ------------------------------- */

const N = 16384;
const R = 8;
const P = 1;
const KEYLEN = 32;

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, KEYLEN, { N, r: R, p: P });
  return `scrypt$${N}$${R}$${P}$${salt.toString("base64")}$${hash.toString("base64")}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [scheme, n, r, p, salt, hash] = stored.split("$");
  if (scheme !== "scrypt" || !n || !r || !p || !salt || !hash) return false;
  const expected = Buffer.from(hash, "base64");
  const actual = scryptSync(password, Buffer.from(salt, "base64"), expected.length, {
    N: Number(n),
    r: Number(r),
    p: Number(p),
  });
  return timingSafeEqual(actual, expected);
}

// Compared against when the username doesn't exist, so a wrong username takes
// as long as a wrong password and doesn't reveal which accounts exist.
const DUMMY_HASH = hashPassword(randomBytes(16).toString("hex"));

/* -------------------------- failed-login throttle ------------------------- */

const MAX_FAILURES = 5;
const LOCK_MINUTES = 15;
const failures = new Map<string, { count: number; until: number }>();

function assertNotLocked(key: string) {
  const f = failures.get(key);
  if (f && f.count >= MAX_FAILURES && f.until > Date.now()) {
    throw new ApiError(429, `Too many failed attempts. Try again in ${LOCK_MINUTES} minutes.`);
  }
}

function recordFailure(key: string) {
  const f = failures.get(key);
  const fresh = !f || f.until <= Date.now();
  failures.set(key, {
    count: fresh ? 1 : f.count + 1,
    until: Date.now() + LOCK_MINUTES * 60_000,
  });
}

/* --------------------------------- sessions ------------------------------- */

const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");

/** Checks the credentials and returns a new session token, or throws 401. */
export function signIn(
  usernameInput: string,
  password: string,
): { token: string; username: string } {
  const key = usernameInput.trim().toLowerCase();
  assertNotLocked(key);
  const account = getAccounts().get(key);
  const ok = verifyPassword(password, account?.hash ?? DUMMY_HASH) && account !== undefined;
  if (!ok || !account) {
    recordFailure(key);
    throw new ApiError(401, "Incorrect username or password");
  }
  failures.delete(key);

  const db = getDb();
  const now = new Date();
  db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(now.toISOString());
  const token = randomBytes(32).toString("base64url");
  const expires = new Date(now.getTime() + SESSION_HOURS * 3_600_000);
  db.prepare(
    "INSERT INTO sessions (token_hash, username, created_at, expires_at) VALUES (?, ?, ?, ?)",
  ).run(sha256(token), account.username, now.toISOString(), expires.toISOString());
  return { token, username: account.username };
}

export function signOut(token: string | undefined) {
  if (token) getDb().prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha256(token));
}

/** The username for a session token, or null if it's missing, expired, or the account was removed. */
export function sessionUser(token: string | undefined): string | null {
  if (!token) return null;
  const row = getDb()
    .prepare("SELECT username, expires_at FROM sessions WHERE token_hash = ?")
    .get(sha256(token)) as { username: string; expires_at: string } | undefined;
  if (!row || row.expires_at < new Date().toISOString()) return null;
  // Removing an account from APP_USERS ends its sessions at the next request.
  if (!getAccounts().has(row.username.toLowerCase())) return null;
  return row.username;
}

/* --------------------------------- cookies -------------------------------- */

export function readSessionCookie(request: Request): string | undefined {
  const header = request.headers.get("cookie");
  if (!header) return undefined;
  for (const part of header.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (name === SESSION_COOKIE) return rest.join("=") || undefined;
  }
  return undefined;
}

/**
 * HttpOnly so page scripts can't read it; SameSite=Lax so other sites can't
 * send it on background requests; Secure when the request came in over HTTPS
 * (the OpenShift route terminates TLS and sets X-Forwarded-Proto).
 */
export function sessionCookie(request: Request, token: string | null): string {
  const secure =
    request.headers.get("x-forwarded-proto") === "https" ||
    new URL(request.url).protocol === "https:";
  const parts = [
    `${SESSION_COOKIE}=${token ?? ""}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${token ? SESSION_HOURS * 3600 : 0}`,
  ];
  if (secure) parts.push("Secure");
  return parts.join("; ");
}
