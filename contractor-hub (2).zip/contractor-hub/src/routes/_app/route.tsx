import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";

import { api } from "@/lib/api";

// The dashboard loads its data from /api in the browser, so it renders
// client-side. Every /api call is also checked on the server; this redirect
// just sends signed-out visitors to the sign-in page.
export const Route = createFileRoute("/_app")({
  ssr: false,
  beforeLoad: async () => {
    const me = await api.me();
    if (!me.id) throw redirect({ to: "/login" });
    return { user: me.id };
  },
  component: () => <Outlet />,
});
