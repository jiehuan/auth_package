import { createFileRoute } from "@tanstack/react-router";

import { readSessionCookie, sessionCookie, signOut } from "@/server/auth.server";
import { assertSameSiteWrite, handlePublic } from "@/server/http.server";

// Ends the session on the server and clears the cookie.
export const Route = createFileRoute("/api/auth/logout")({
  server: {
    handlers: {
      POST: handlePublic(({ request }: { request: Request }) => {
        assertSameSiteWrite(request);
        signOut(readSessionCookie(request));
        return new Response(null, {
          status: 204,
          headers: { "set-cookie": sessionCookie(request, null) },
        });
      }),
    },
  },
});
