import { createFileRoute } from "@tanstack/react-router";

import { sessionCookie, signIn } from "@/server/auth.server";
import { ApiError } from "@/server/contractors.server";
import { handlePublic, json, readJson } from "@/server/http.server";

// Body: { username, password }. Sets the session cookie.
export const Route = createFileRoute("/api/auth/login")({
  server: {
    handlers: {
      POST: handlePublic(async ({ request }: { request: Request }) => {
        const body = (await readJson(request)) as { username?: unknown; password?: unknown };
        if (typeof body.username !== "string" || typeof body.password !== "string") {
          throw new ApiError(400, "Username and password are required");
        }
        if (body.username.length > 100 || body.password.length > 200) {
          throw new ApiError(401, "Incorrect username or password");
        }
        const { token, username } = signIn(body.username, body.password);
        const res = json({ id: username });
        res.headers.append("set-cookie", sessionCookie(request, token));
        return res;
      }),
    },
  },
});
