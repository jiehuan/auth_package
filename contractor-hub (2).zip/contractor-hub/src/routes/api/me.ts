import { createFileRoute } from "@tanstack/react-router";

import { currentUserId, handlePublic, json } from "@/server/http.server";

// The signed-in user: { id: "<username>" }, or { id: null } when signed out.
export const Route = createFileRoute("/api/me")({
  server: {
    handlers: {
      GET: handlePublic(({ request }: { request: Request }) =>
        json({ id: currentUserId(request) }),
      ),
    },
  },
});
