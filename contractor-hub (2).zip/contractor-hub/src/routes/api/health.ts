import { createFileRoute } from "@tanstack/react-router";

import { accountCount } from "@/server/auth.server";
import { countContractors } from "@/server/contractors.server";
import { handlePublic, json } from "@/server/http.server";

// Readiness/liveness probe. Touches the database, so a broken or unmounted
// volume shows up as a failing probe instead of a half-working app. Also
// reports how many sign-in accounts loaded, so a bad APP_USERS is logged as
// soon as the pod starts (the startup probe calls this).
export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: handlePublic(() =>
        json({ status: "ok", contractors: countContractors(), accounts: accountCount() }),
      ),
    },
  },
});
