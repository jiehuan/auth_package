# Contractor Hub

A dashboard for HR to track contractors and FTEs, behind a sign-in. Upload Excel/CSV lists, see who is expiring or still active in the internal system, resolve conflicting details, save filtered views as reports, and export to Excel.

Stack: TanStack Start (React 19, SSR), Tailwind v4, shadcn/ui, recharts and SheetJS, built with Nitro's `node-server` preset.
**The pages and the API run in the same Node server**, so there is no separate backend. Data is stored in SQLite through Node's built-in `node:sqlite`, on a persistent volume.

## Features

- KPI cards (total, active, ending within 90 / 180 days, SoW ended but still in the system, monthly spend). Click a card to filter the table.
- Charts: monthly resource count by vendor, headcount trend, spend by vendor, terminations, upcoming expiries, splits by function and country.
- Everyone / Contractors / FTEs switch that applies to every card, chart and the table.
- Column chooser and widget chooser, remembered per browser.
- Saved reports (filters + columns), shared by all users, and a multi-sheet report download (Summary, Breakdown, Details).
- Upload with automatic column matching, a conflict screen, and an upload history with the original rows.
- Sign-in with a fixed set of accounts (two today). There is no user administration in the app.

## Project layout

```
src/routes/login.tsx               Sign-in page
src/routes/_app/route.tsx          Sends signed-out visitors to /login
src/routes/_app/index.tsx          Dashboard page (KPIs, charts, table, filters, reports, history)
src/components/contractors/        Upload dialog (incl. conflict screen) and edit side panel
src/lib/contractors.ts             Types, status rules, Excel parsing and export (browser)
src/lib/api.ts                     Browser client for /api
src/routes/api/                    API routes (server only)
src/server/db.server.ts            SQLite connection and schema migrations (PRAGMA user_version)
src/server/contractors.server.ts   Contractor data access, validation and import transaction
src/server/history.server.ts       Upload history and saved reports
src/server/auth.server.ts          Accounts, password check, sessions, cookie
src/server/http.server.ts          JSON responses, write-header check, sign-in check, error handling
scripts/hash-password.mjs          Generates an APP_USERS entry for one account (Node)
scripts/hash_password.py           Same, in Python
```

Files named `*.server.ts` are never included in the browser bundle.

## Data model

| Table | Contents |
|---|---|
| `contractors` | One row per person, contractors and FTEs alike. `work_type` is `Contractor` or `FTE` (default `Contractor`). `manager` is shown as "Direct Manager". There is no separate project end date: "SoW / Project End Date" is `sow_end_date`. |
| `saved_reports` | Name, filters (JSON), columns (JSON), `created_by` |
| `upload_history` | File name, work type, counts, conflict choices (JSON), the original file rows (JSON), `created_by` |
| `sessions` | SHA-256 hash of each session token, username, expiry |

The schema is versioned with `PRAGMA user_version` and migrated automatically when the server starts. Upgrading keeps all existing records. From v1, records get `work_type = 'Contractor'` and empty role / contract type. Reports and uploads saved before sign-in existed have no owner (`created_by` is null).

## API

| Method | Path | Description |
|---|---|---|
| GET | `/api/health` | Health probe; opens the database and returns the record count. No sign-in needed. |
| GET | `/api/me` | Current user: `{ id: "<username>" }`, or `{ id: null }` when signed out. No sign-in needed. |
| POST | `/api/auth/login` | `{ username, password }`; sets the session cookie |
| POST | `/api/auth/logout` | Ends the session and clears the cookie |
| GET | `/api/contractors` | All records, sorted by SoW end date |
| POST | `/api/contractors` | Create one record |
| GET / PUT / DELETE | `/api/contractors/:id` | Read, replace or delete one record |
| POST | `/api/contractors/import` | Apply an upload in a single transaction (see below) |
| GET | `/api/uploads` | Latest 50 uploads, without the stored rows |
| GET | `/api/uploads/:id` | One upload with its original rows and conflict choices |
| GET / POST | `/api/reports` | List or save reports |
| DELETE | `/api/reports/:id` | Delete a report |

Every other endpoint returns 401 without a valid session. POST, PUT and DELETE requests must also send the `X-Requested-With: fetch` header; the frontend adds it to every request.

### How an upload works

The browser parses the file, matches columns, and compares it with the current records:

1. **Work type.** The user picks whether the file is a list of contractors or FTEs. Rows without a Work Type value get that choice.
2. **Duplicates in the file.** Rows for the same person (same email, or same name when there is no email) are collapsed into one.
3. **Matching.** Each person is matched to an existing record by email. Name is used only when one side has no email.
4. **Conflicts.** If a matched person has different non-empty values in the file, a conflict screen shows each field side by side. The user picks per field, or uses "Keep all current" / "Use all from file". Current values are kept by default.
5. **Writing.** Empty cells in the file never overwrite saved data. If the SoW end date moves later, the renewal count goes up by one.

The browser then sends one request to `/api/contractors/import`:

```json
{
  "inserts": [ { "name": "...", "work_type": "FTE", "...": "..." } ],
  "updates": [ { "id": "...", "changes": { "role": "...", "renewal_count": 2 } } ],
  "log": { "file_name": "...", "work_type": "FTE", "row_count": 3, "conflict_count": 1, "overrides": [], "rows": [] }
}
```

The server validates every row and writes the new records, the changed fields and the upload-history entry in one transaction. Either all of it is saved or none of it. If a record was deleted while the upload screen was open, the import is rejected and nothing is written.

### Status

Status is computed from the dates on every read and is not stored.

| Status | Rule |
|---|---|
| Terminated | Termination date has passed |
| Expired | SoW end date has passed |
| Expiring | SoW ends within 180 days |
| Active | Everything else, including FTEs with no SoW end date |

## Local development

```bash
npm ci
npm run dev          # http://localhost:3000; data goes to ./data/contractor-hub.db
```

Without `APP_USERS`, `npm run dev` signs in with **dev / dev**. The production build never has that fallback: without `APP_USERS` nobody can sign in.

| Command | Purpose |
|---|---|
| `npm run typecheck` | TypeScript check |
| `npm run lint` | ESLint |
| `npm run build` | Production build into `.output/` |
| `npm start` | Run the production build |
| `npm run hash-password -- <username>` | Print an `APP_USERS` entry for one account |

Requires Node 22.13 or later for `node:sqlite`.

When updating dependencies, regenerate `package-lock.json` with **npm 12 or later**. A lockfile written by npm 10 makes `npm ci` fail with EUSAGE.

## Environment variables

| Variable | Default | Notes |
|---|---|---|
| `PORT` / `HOST` | `3000` / `localhost` | The image sets `8080` / `0.0.0.0` |
| `DATA_DIR` | `./data` | Directory for the SQLite file; the image sets `/data` |
| `DB_PATH` | `$DATA_DIR/contractor-hub.db` | Override the database file path if needed |
| `APP_USERS` | none | Sign-in accounts, `user:scrypt$…;user:scrypt$…`. Comes from the `contractor-hub-auth` Secret. |

## Deployment

| File | Purpose |
|---|---|
| `harness/build-stage.yaml` | CI stage: `npm ci`, typecheck, build, `cp -r .output dist`, then buildah packages the image |
| `Dockerfile` | Only copies `dist/`; no `RUN` steps, and no npm or `node_modules` at runtime |
| `openshift/deployment.yaml` | ConfigMap, Secret (`APP_USERS`), PVC, Deployment, Service and Route (Harness Go template) |
| `openshift/values-dev.yaml` | DEV environment values |

Deployment notes:

- **One replica with the Recreate strategy.** SQLite allows one writer, and a ReadWriteOnce volume cannot be mounted by two pods at once, so a rolling update would hang.
- **The PVC has the `harness.io/skip-versioning` annotation.** Without it, Harness renames the claim on every deploy and the pod starts on a new, empty volume.
- **Probes.**
  - Startup and readiness use `/api/health`, which opens the database (and runs any pending migration), so the pod receives no traffic if the volume is missing.
  - Liveness uses the static `/healthz.json`, so a slow query never restarts the pod.
- **Backups.** All data is one SQLite file on the PVC. Copy it periodically with `oc rsync <pod>:/data ./backup`, or ask the platform team to snapshot the volume. Upload history stores every file's rows, so the file grows with each upload.
- **Build the image locally:**
  ```bash
  npm run build && rm -rf dist && cp -r .output dist && docker build -t contractor-hub:dev .
  ```

## Sign-in

Accounts are defined in configuration, not in the app. There is no screen to add users or reset passwords; edit the secret and redeploy instead.

### Setting up the two accounts

1. For each account, generate an entry. The password is typed without echo and must be at least 10 characters:
   ```bash
   npm run hash-password -- hr1
   npm run hash-password -- hr2
   ```
   Each prints one line like `hr1:scrypt$16384$8$1$<salt>$<hash>`.

   Without Node (e.g. on a Mac), the Python script produces the same format using only the standard library:
   ```bash
   python3 scripts/hash_password.py hr1
   python3 scripts/hash_password.py hr2
   ```
   Apple's built-in `/usr/bin/python3` has no scrypt; use Homebrew or python.org Python, or first run `python3 -m pip install --user cryptography`.
2. Join the two lines with `;` into one value:
   ```
   hr1:scrypt$...;hr2:scrypt$...
   ```
3. Create the Secret **once** in the namespace. The pipeline does not create it, and the pod won't start until it exists.
   - **Web console:** Secrets → Create → Key/value secret. Name `contractor-hub-auth`, key `APP_USERS`, value = the line from step 2. If a `contractor-hub-auth` Secret already exists, edit its `APP_USERS` value instead.
   - **CLI:**
     ```bash
     oc create secret generic contractor-hub-auth -n <namespace> \
       --from-literal=APP_USERS='hr1:scrypt$...;hr2:scrypt$...'
     ```
     Keep the single quotes so the shell doesn't expand the `$` signs.
4. Deploy (or restart the pod). The pod log shows `[auth] 2 account(s): hr1, hr2`, and `/api/health` returns `"accounts": 2`.

To change a password, remove an account or add one, edit `APP_USERS` in the Secret and restart the pod (delete it in the console, or `oc rollout restart deployment/contractor-hub-deployment`). A Secret change alone does not restart the pod. Sessions of a removed account stop working as soon as the new pod is up.

**Why not a Harness secret in `values.yaml`?** That was the first approach. Harness rendered it as a `${secretDelegate.obtain(...)}` placeholder that reached the pod unresolved. Keeping the Secret in the namespace avoids that and keeps the password hashes out of the pipeline. If `APP_USERS` ever contains such a placeholder again, the pod log says so and nobody can sign in.

### How it works

- **Passwords** are stored only as scrypt hashes. A wrong username and a wrong password get the same message and take the same time.
- **Lockout.** After 5 failed attempts, that username is locked for 15 minutes. The counter is in memory, so restarting the pod clears it.
- **Sessions** last 12 hours. The browser holds a random token in an `HttpOnly`, `SameSite=Lax` cookie (`Secure` over HTTPS). The database stores only the token's SHA-256 hash, so signing out ends the session on the server.
- **Ownership.** Saved reports and uploads record who created them. Only the creator can delete a report; reports saved before sign-in existed can be deleted by anyone.
- **Where it's checked.** Every API handler is wrapped by `handle()` in `src/server/http.server.ts`, which returns 401 without a valid session. `handlePublic()` is used only for `/api/health`, `/api/me` and the sign-in endpoints. The page guard in `src/routes/_app/route.tsx` only redirects; the API check is what protects the data.
