# Team Pulse — Frontend

团队容量与项目分配看板。React 19 + TanStack Start (SSR) + Tailwind v4 + shadcn/ui,
Nitro 打包成自包含 Node 服务,部署在 OpenShift。

数据来自独立的后端服务(见 `team-pulse-backend`),前端通过同源的 `/api` 访问。

## 快速开始

```bash
npm ci

# 后端要先起来(默认 localhost:8080)
npm run dev          # http://localhost:5173
```

`vite.config.ts` 里已经配好 dev proxy,`/api` 会转发到 `http://localhost:8080`。
后端在别的地址就设 `API_PROXY_TARGET`:

```bash
API_PROXY_TARGET=http://10.0.0.5:8080 npm run dev
```

## 脚本

| 命令 | 作用 |
|---|---|
| `npm run dev` | 开发服务器,带 HMR |
| `npm run build` | 构建到 `.output/`(Nitro node-server preset) |
| `npm run preview` | 本地跑构建产物,`http://localhost:3000` |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint |
| `npm run format` | Prettier |

## 构建产物

`npm run build` 产出的**不是 `dist/`,而是 `.output/`**:

```
.output/
  server/index.mjs    # Node SSR 服务入口
  public/             # 客户端资源 + favicon + healthz.json
  nitro.json
```

完全自包含,**运行时不需要 `node_modules`**。直接 `node .output/server/index.mjs` 就能跑,
监听 `PORT`(默认 3000,容器里设成 8080)。

## 目录结构

```
src/
  routes/
    __root.tsx        # 根布局、head、error/404 边界
    index.tsx         # 看板主页
    admin.tsx         # 管理页(项目/人员/分配)
  components/
    capacity/         # 业务组件
    ui/               # shadcn/ui 基础组件
  lib/
    capacity-store.tsx   # 全局状态 + API 调用
    capacity-types.ts    # 类型定义与计算函数
    capacity-seed.ts     # 前端兜底种子数据
    capacity-excel.ts    # Excel 导入导出
  server.ts           # SSR 错误包装入口
  start.ts            # CSRF middleware
public/
  healthz.json        # k8s 探针用的静态文件,必须在 build 前存在
```

## 状态管理

`src/lib/capacity-store.tsx` 是唯一和后端通信的地方。设计要点:

- **服务端是权威。** 每个写操作都返回完整的 `CapacityData` 快照,前端整体替换 state,
  不做乐观更新 —— 容量校验规则在服务端,被拒绝的写入不应该在界面上留下幽灵记录。
- **`addAllocation` 保持同步签名** `(a) => string | null`。`admin.tsx` 里是
  `const error = addAllocation(...)` 这样用的,改成 async 会让 `if (error)` 永远为真。
  客户端做即时预校验,服务端再校验一次防并发。
- **首次加载完成前 Provider 渲染 loading 态**,因为部分组件在 mount 时从 `data` 取初值
  (如分配表单的默认选项),空数组会让下拉框永远空着。

## 部署

见 `openshift/`。要点:

- 端口 8080,非 root(OpenShift 会分配任意 UID,镜像用 group 0 + `g=u` 适配)
- 探针打 `/healthz.json` 静态文件,不触发 SSR 渲染
- `route.yaml` 里两个 Route **必须填同一个 host**,靠 path 分流 `/api` 到后端;
  留空让 OpenShift 自动生成的话会拿到不同 host,分流会静默失效

```bash
docker build -t <registry>/<ns>/team-pulse:1.0.0 .
docker push <registry>/<ns>/team-pulse:1.0.0

oc apply -f openshift/service.yaml
oc apply -f openshift/deployment.yaml
oc apply -f openshift/route.yaml
```
