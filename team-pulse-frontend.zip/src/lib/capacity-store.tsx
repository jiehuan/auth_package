import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import {
  round1,
  statusFor,
  type Allocation,
  type CapacityData,
  type Person,
  type Project,
} from "./capacity-types";

// Same-origin by default: in OpenShift a Route with `path: /api` sends this to
// the backend Service, so no CORS and no build-time URL injection needed.
// For `vite dev`, vite.config.ts proxies /api to http://localhost:8080.
const API_BASE = "/api";

const EMPTY: CapacityData = { asOf: "", people: [], projects: [], allocations: [] };

/** Every mutation returns the full snapshot, so the client never drifts. */
async function request(path: string, init?: RequestInit): Promise<CapacityData> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "content-type": "application/json" },
    ...init,
  });

  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    /* empty or non-JSON response */
  }

  if (!res.ok) {
    const message =
      body && typeof body === "object" && "error" in body
        ? String((body as { error: unknown }).error)
        : `Request failed (${res.status})`;
    throw new Error(message);
  }
  return body as CapacityData;
}

const json = (method: string, payload?: unknown): RequestInit => ({
  method,
  ...(payload === undefined ? {} : { body: JSON.stringify(payload) }),
});

export interface ProjectRow {
  project: Project;
  /** FTE allocated from the People table. */
  fteAllocated: number;
  /** FTC allocated, recorded on the project. */
  ftcAllocated: number;
  /** Total allocated = FTE + FTC. */
  assigned: number;
  headcount: number;
  needed: number;
  ftcNeeded: number;
  /** needed − allocated (positive = shortfall). */
  gap: number;
  status: ReturnType<typeof statusFor>;
}

export interface Totals {
  capacity: number;
  allocated: number;
  fte: number;
  ftc: number;
  needed: number;
  gap: number;
  projects: number;
}

interface Store {
  data: CapacityData;
  rows: ProjectRow[];
  totals: Totals;
  peopleWithLoad: Array<Person & { allocated: number }>;
  addPerson: (p: Omit<Person, "id">) => string;
  updatePerson: (id: string, p: Partial<Person>) => void;
  removePerson: (id: string) => void;
  addProject: (p: Omit<Project, "id">) => void;
  updateProject: (id: string, p: Partial<Project>) => void;
  removeProject: (id: string) => void;
  addAllocation: (a: Omit<Allocation, "id">) => string | null;
  updateAllocation: (id: string, a: Partial<Allocation>) => void;
  removeAllocation: (id: string) => void;
  replaceAll: (data: CapacityData) => void;
}

const CapacityContext = createContext<Store | null>(null);

const uid = () => Math.random().toString(36).slice(2, 10);

export function totalsFor(
  rows: ProjectRow[],
  allocations: Allocation[],
  people?: Person[],
): Totals {
  const fte = round1(rows.reduce((s, r) => s + r.fteAllocated, 0));
  const ftc = round1(rows.reduce((s, r) => s + r.ftcAllocated, 0));
  const allocated = round1(fte + ftc);

  // Total capacity = distinct people working on these projects + FTC allocated.
  //
  // Distinct by NAME, not by id: somebody entered twice (an Excel import plus a
  // manual add, say) is still one human. Deduping on personId alone would count
  // them twice. Falls back to personId when the people list is not supplied.
  const projectIds = new Set(rows.map((r) => r.project.id));
  const visible = allocations.filter((a) => projectIds.has(a.projectId));
  const uniquePeople = people
    ? new Set(
        visible
          .map((a) => people.find((p) => p.id === a.personId))
          .filter((p): p is Person => Boolean(p))
          .map((p) => p.name.trim().toLowerCase()),
      ).size
    : new Set(visible.map((a) => a.personId)).size;
  const capacity = round1(uniquePeople + ftc);
  const needed = round1(rows.reduce((s, r) => s + r.needed, 0));
  return {
    capacity,
    allocated,
    fte,
    ftc,
    needed,
    gap: round1(needed - capacity),
    projects: rows.length,
  };
}

export function CapacityProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<CapacityData>(EMPTY);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [loadError, setLoadError] = useState("");

  // Mutations are chained rather than fired in parallel. The admin form calls
  // addPerson() then addAllocation() in the same tick; without ordering the
  // allocation POST could reach the server before the person exists.
  const queue = useRef<Promise<unknown>>(Promise.resolve());

  const load = useCallback(() => {
    setStatus("loading");
    request("/capacity")
      .then((d) => {
        setData(d);
        setStatus("ready");
      })
      .catch((err: Error) => {
        setLoadError(err.message);
        setStatus("error");
      });
  }, []);

  useEffect(load, [load]);

  /**
   * Queue a mutation and adopt whatever the server returns. No optimistic
   * update: the server validates, so a rejected write must not leave a
   * phantom row on screen.
   */
  const run = useCallback((path: string, init: RequestInit) => {
    queue.current = queue.current
      .then(() => request(path, init))
      .then(setData)
      .catch((err: Error) => {
        toast.error(err.message);
        return request("/capacity")
          .then(setData)
          .catch(() => {
            /* keep the last good state */
          });
      });
  }, []);

  const value = useMemo<Store>(() => {
    const peopleWithLoad = data.people.map((p) => ({
      ...p,
      allocated: round1(data.allocations.filter((a) => a.personId === p.id).reduce((s, a) => s + a.fte, 0)),
    }));

    const rows: ProjectRow[] = [...data.projects]
      .sort((a, b) => a.priority - b.priority)
      .map((project) => {
        const allocs = data.allocations.filter((a) => a.projectId === project.id);
        const fteAllocated = round1(allocs.reduce((s, a) => s + a.fte, 0));
        const ftcAllocated = round1(project.ftcAllocated || 0);
        const assigned = round1(fteAllocated + ftcAllocated);
        const needed = round1(project.resourceNeeded || 0);
        const gap = round1(needed - assigned);
        return {
          project,
          fteAllocated,
          ftcAllocated,
          assigned,
          headcount: allocs.length,
          needed,
          ftcNeeded: round1(project.ftcNeeded || 0),
          gap,
          status: statusFor(gap),
        };
      });

    return {
      data,
      rows,
      peopleWithLoad,
      totals: totalsFor(rows, data.allocations, data.people),

      // Returns the id synchronously so the caller can allocate against it in
      // the same tick; the POST is queued behind whatever is already running.
      addPerson: (p) => {
        const id = uid();
        run("/people", json("POST", { ...p, id }));
        return id;
      },
      updatePerson: (id, patch) => run(`/people/${id}`, json("PATCH", patch)),
      // Allocations cascade server-side.
      removePerson: (id) => run(`/people/${id}`, json("DELETE")),

      addProject: (p) => run("/projects", json("POST", p)),
      updateProject: (id, patch) => run(`/projects/${id}`, json("PATCH", patch)),
      removeProject: (id) => run(`/projects/${id}`, json("DELETE")),

      // Stays synchronous so callers can keep doing `const err = addAllocation(...)`.
      // A person created earlier in this same tick is not in `data` yet, so the
      // existence checks are left to the server.
      addAllocation: (a) => {
        if (a.fte <= 0) return "Allocation must be greater than 0";
        run("/allocations", json("POST", { ...a, id: uid() }));
        return null;
      },
      updateAllocation: (id, patch) => run(`/allocations/${id}`, json("PATCH", patch)),
      removeAllocation: (id) => run(`/allocations/${id}`, json("DELETE")),

      replaceAll: (next) => run("/capacity", json("PUT", next)),
    };
  }, [data, run]);

  // Gate on the first load so components that seed local state from `data` on
  // mount (e.g. the admin form's default project selection) still work.
  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-sm text-muted-foreground">Loading team data…</p>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="max-w-md text-center">
          <h1 className="text-xl font-semibold text-foreground">Cannot reach the server</h1>
          <p className="mt-2 text-sm text-muted-foreground">{loadError}</p>
          <button
            onClick={load}
            className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  return <CapacityContext.Provider value={value}>{children}</CapacityContext.Provider>;
}

export function useCapacity() {
  const ctx = useContext(CapacityContext);
  if (!ctx) throw new Error("useCapacity must be used inside CapacityProvider");
  return ctx;
}
