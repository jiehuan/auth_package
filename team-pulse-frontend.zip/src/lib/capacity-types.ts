export type ImpactLevel = "High" | "Medium" | "Low";
export type ProjectStatus = "On Track" | "At Risk" | "Gap";

export interface Person {
  id: string;
  name: string;
  role: string;
}

export interface Project {
  id: string;
  name: string;
  sponsor: string;
  description: string;
  icon: string;
  priority: number;
  /** Total resource needed (FTE + FTC). */
  resourceNeeded: number;
  /** Portion of the need expected to be covered by FTC. */
  ftcNeeded: number;
  /** FTC capacity already allocated to this project. */
  ftcAllocated: number;
  impactIfDelayed: string;
  impactLevel: ImpactLevel;
}

/** FTE allocation of a named person to a project. */
export interface Allocation {
  id: string;
  personId: string;
  projectId: string;
  fte: number;
}

export interface CapacityData {
  asOf: string;
  people: Person[];
  projects: Project[];
  allocations: Allocation[];
}

export const ROLES = [
  "Lead Data Scientist",
  "Data Scientist",
  "ML Engineer",
  "Data Engineer",
  "MLOps Engineer",
  "Analytics Lead",
  "Business Analyst",
  "Product Owner",
];

export const PROJECT_ICONS = [
  "rocket",
  "trending-up",
  "shield",
  "file-text",
  "server",
  "users",
  "brain",
  "database",
];

export const round1 = (n: number) => Math.round(n * 10) / 10;

export const clampPriority = (p: number) => Math.min(5, Math.max(1, Math.round(p || 5)));

/** gap = resource needed − resource allocated (positive = shortfall). */
export function statusFor(gap: number): ProjectStatus {
  if (gap <= 0) return "On Track";
  if (gap <= 0.5) return "At Risk";
  return "Gap";
}
