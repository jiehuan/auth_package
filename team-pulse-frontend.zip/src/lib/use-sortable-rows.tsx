import { useMemo, useState } from "react";

export type SortDirection = "asc" | "desc";

/**
 * Click-to-sort table state.
 *
 * Text sorts alphabetically (locale-aware and case-insensitive, so "apple"
 * and "Apple" land together) and numbers sort numerically — sorting "10"
 * before "9" because "1" < "9" is the classic version of this bug.
 *
 * Clicking the active column flips direction; clicking a different column
 * starts it ascending. Rows are never mutated: sorting returns a new array.
 */
export function useSortableRows<T>(
  rows: T[],
  accessors: Record<string, (row: T) => string | number | null | undefined>,
  initialKey?: string,
) {
  const [key, setKey] = useState<string | null>(initialKey ?? null);
  const [direction, setDirection] = useState<SortDirection>("asc");

  const toggle = (nextKey: string) => {
    if (nextKey === key) {
      setDirection((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setKey(nextKey);
      setDirection("asc");
    }
  };

  const sorted = useMemo(() => {
    if (!key) return rows;
    const accessor = accessors[key];
    if (!accessor) return rows;

    const factor = direction === "asc" ? 1 : -1;
    return [...rows].sort((a, b) => {
      const av = accessor(a);
      const bv = accessor(b);

      // Blanks sink to the bottom in both directions; a column of mostly
      // empty sponsors should not push the real values off screen.
      const aEmpty = av === null || av === undefined || av === "";
      const bEmpty = bv === null || bv === undefined || bv === "";
      if (aEmpty && bEmpty) return 0;
      if (aEmpty) return 1;
      if (bEmpty) return -1;

      if (typeof av === "number" && typeof bv === "number") {
        return (av - bv) * factor;
      }
      return String(av).localeCompare(String(bv), undefined, { sensitivity: "base" }) * factor;
    });
  }, [rows, key, direction, accessors]);

  return { sorted, sortKey: key, direction, toggle };
}

/** Arrow shown in a sortable header. Neutral until the column is active. */
export function SortIndicator({
  active,
  direction,
}: {
  active: boolean;
  direction: SortDirection;
}) {
  return (
    <span
      aria-hidden
      className={active ? "text-foreground" : "text-muted-foreground/40"}
    >
      {active ? (direction === "asc" ? "▲" : "▼") : "↕"}
    </span>
  );
}

/**
 * Sortable <th>. Keeps the header cell's own padding/alignment classes so it
 * drops into an existing table without changing its layout.
 */
export function SortableTh({
  label,
  columnKey,
  sortKey,
  direction,
  onToggle,
  className,
  align = "left",
}: {
  label: string;
  columnKey: string;
  sortKey: string | null;
  direction: SortDirection;
  onToggle: (key: string) => void;
  className?: string;
  align?: "left" | "center";
}) {
  const active = sortKey === columnKey;
  return (
    <th
      className={className}
      aria-sort={active ? (direction === "asc" ? "ascending" : "descending") : "none"}
    >
      <button
        type="button"
        onClick={() => onToggle(columnKey)}
        className={[
          "inline-flex items-center gap-1.5 uppercase transition-colors hover:text-foreground",
          align === "center" ? "justify-center" : "",
          active ? "text-foreground" : "",
        ]
          .filter(Boolean)
          .join(" ")}
      >
        {label}
        <SortIndicator active={active} direction={direction} />
      </button>
    </th>
  );
}
