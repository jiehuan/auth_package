import { useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Pencil, Plus, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTransfer } from "@/components/capacity/DataTransfer";
import { useCapacity } from "@/lib/capacity-store";
import { SortableTh, useSortableRows } from "@/lib/use-sortable-rows";
import { PROJECT_ICONS, ROLES, clampPriority, round1, type ImpactLevel } from "@/lib/capacity-types";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Manage Team Allocation Data — Admin" },
      {
        name: "description",
        content: "Add or edit projects and resource assignments, and move the dataset in and out of Excel.",
      },
      { property: "og:title", content: "Manage Team Allocation Data — Admin" },
      {
        property: "og:description",
        content: "Add projects and resources, edit allocations, download and upload Excel.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});

const selectClass = "h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="font-display text-lg text-foreground">{title}</h3>
      <div className="mt-4">{children}</div>
    </div>
  );
}

function TotalsStrip() {
  const { totals, data } = useCapacity();
  const items = [
    ["Allocated", `${totals.allocated.toFixed(1)}`],
    ["FTE / FTC", `${totals.fte.toFixed(1)} / ${totals.ftc.toFixed(1)}`],
    ["Resource needed", `${totals.needed.toFixed(1)}`],
    ["Gap", totals.gap.toFixed(1)],
    ["People", String(data.people.length)],
    ["Work areas", String(totals.projects)],
  ] as const;
  return (
    <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
      {items.map(([label, value]) => (
        <div key={label} className="rounded-xl border border-border bg-card px-4 py-3">
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          <p className="font-display text-xl text-foreground">{value}</p>
        </div>
      ))}
    </div>
  );
}

const emptyForm = {
  name: "",
  sponsor: "",
  description: "",
  icon: PROJECT_ICONS[0]!,
  priority: 5,
  impact: "",
  impactLevel: "Medium" as ImpactLevel,
  resourceNeeded: 1,
  ftcNeeded: 0,
  ftcAllocated: 0,
};

function ProjectsTab() {
  const { data, rows, addProject, removeProject, updateProject } = useCapacity();
  const projectSort = useSortableRows(rows, {
    name: (r) => r.project.name,
    priority: (r) => r.project.priority,
    needed: (r) => r.needed,
    ftcNeeded: (r) => r.ftcNeeded,
    fteAllocated: (r) => r.fteAllocated,
    ftcAllocated: (r) => r.ftcAllocated,
    gap: (r) => r.gap,
  });
  const formRef = useRef<HTMLDivElement>(null);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...emptyForm, priority: Math.min(5, data.projects.length + 1) });

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  function reset() {
    setEditingId(null);
    setForm({ ...emptyForm, priority: Math.min(5, data.projects.length + 1) });
  }

  function startEdit(id: string) {
    const p = data.projects.find((x) => x.id === id);
    if (!p) return;
    setEditingId(id);
    setForm({
      name: p.name,
      sponsor: p.sponsor,
      description: p.description,
      icon: p.icon,
      priority: p.priority,
      impact: p.impactIfDelayed,
      impactLevel: p.impactLevel,
      resourceNeeded: p.resourceNeeded,
      ftcNeeded: p.ftcNeeded,
      ftcAllocated: p.ftcAllocated,
    });
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function submit() {
    if (!form.name.trim()) {
      toast.error("Project name is required");
      return;
    }
    const payload = {
      name: form.name.trim(),
      sponsor: form.sponsor.trim(),
      description: form.description.trim(),
      icon: form.icon,
      priority: clampPriority(Number(form.priority)),
      resourceNeeded: Math.max(0, round1(Number(form.resourceNeeded) || 0)),
      ftcNeeded: Math.max(0, round1(Number(form.ftcNeeded) || 0)),
      ftcAllocated: Math.max(0, round1(Number(form.ftcAllocated) || 0)),
      impactIfDelayed: form.impact.trim(),
      impactLevel: form.impactLevel,
    };
    if (editingId) {
      updateProject(editingId, payload);
      toast.success("Project updated");
    } else {
      addProject(payload);
      toast.success("Project added");
    }
    reset();
  }

  return (
    <div className="space-y-4">
      <div ref={formRef}>
        <Section title={editingId ? "Edit project" : "Add a project"}>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Project Name</Label>
              <Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Next Gen UW" />
            </div>
            <div className="space-y-1.5">
              <Label>Project Sponsor</Label>
              <Input
                value={form.sponsor}
                onChange={(e) => set("sponsor", e.target.value)}
                placeholder="Chief Underwriting Officer"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Project Description</Label>
              <Input
                value={form.description}
                onChange={(e) => set("description", e.target.value)}
                placeholder="Building new underwriting capabilities"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Icon</Label>
              <select className={selectClass} value={form.icon} onChange={(e) => set("icon", e.target.value)}>
                {PROJECT_ICONS.map((i) => (
                  <option key={i} value={i}>
                    {i}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Prioritization (1 = highest)</Label>
              <Input
                type="number"
                min={1}
                max={5}
                value={form.priority}
                onChange={(e) => set("priority", clampPriority(Number(e.target.value)))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Impact level if delayed</Label>
              <select
                className={selectClass}
                value={form.impactLevel}
                onChange={(e) => set("impactLevel", e.target.value as ImpactLevel)}
              >
                {(["High", "Medium", "Low"] as const).map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Resource needed (total)</Label>
              <Input
                type="number"
                step="0.1"
                min="0"
                value={form.resourceNeeded}
                onChange={(e) => set("resourceNeeded", Number(e.target.value))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>FTC needed</Label>
              <Input
                type="number"
                step="0.1"
                min="0"
                value={form.ftcNeeded}
                onChange={(e) => set("ftcNeeded", Number(e.target.value))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>FTC allocated</Label>
              <Input
                type="number"
                step="0.1"
                min="0"
                value={form.ftcAllocated}
                onChange={(e) => set("ftcAllocated", Number(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                FTE allocated is calculated from the People tab.
              </p>
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label>Impact if delayed</Label>
              <Input
                value={form.impact}
                onChange={(e) => set("impact", e.target.value)}
                placeholder="Launch slips a full quarter"
              />
            </div>
          </div>

          <div className="mt-5 flex gap-2">
            <Button onClick={submit}>
              <Plus className="size-4" /> {editingId ? "Save project" : "Add project"}
            </Button>
            {editingId ? (
              <Button variant="outline" onClick={reset}>
                <X className="size-4" /> Cancel
              </Button>
            ) : null}
          </div>
        </Section>
      </div>

      <Section title="Projects">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[52rem] text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase">
                {(
                  [
                    ["name", "Project", "py-2 pr-3", "left"],
                    ["priority", "Priority", "py-2 pr-3 text-center", "center"],
                    ["needed", "Needed", "py-2 pr-3 text-center", "center"],
                    ["ftcNeeded", "FTC needed", "py-2 pr-3 text-center", "center"],
                    ["fteAllocated", "FTE allocated", "py-2 pr-3 text-center", "center"],
                    ["ftcAllocated", "FTC allocated", "py-2 pr-3 text-center", "center"],
                    ["gap", "Gap", "py-2 pr-3 text-center", "center"],
                  ] as const
                ).map(([key, label, cls, align]) => (
                  <SortableTh
                    key={key}
                    columnKey={key}
                    label={label}
                    className={cls}
                    align={align}
                    sortKey={projectSort.sortKey}
                    direction={projectSort.direction}
                    onToggle={projectSort.toggle}
                  />
                ))}
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {projectSort.sorted.map((row) => (
                <tr key={row.project.id} className="border-b border-border last:border-0">
                  <td className="py-3 pr-3">
                    <p className="font-medium text-foreground">{row.project.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {row.project.sponsor || "—"} · {row.project.description}
                    </p>
                  </td>
                  <td className="py-3 pr-3 text-center">{row.project.priority}</td>
                  <td className="py-3 pr-3 text-center">{row.needed.toFixed(1)}</td>
                  <td className="py-3 pr-3 text-center">{row.ftcNeeded.toFixed(1)}</td>
                  <td className="py-3 pr-3 text-center">{row.fteAllocated.toFixed(1)}</td>
                  <td className="py-3 pr-3 text-center">{row.ftcAllocated.toFixed(1)}</td>
                  <td className={`py-3 pr-3 text-center ${row.gap > 0 ? "text-danger" : "text-success"}`}>
                    {row.gap.toFixed(1)}
                  </td>
                  <td className="py-3 text-right whitespace-nowrap">
                    <Button variant="ghost" size="icon" onClick={() => startEdit(row.project.id)} aria-label="Edit project">
                      <Pencil className="size-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        if (editingId === row.project.id) reset();
                        removeProject(row.project.id);
                      }}
                      aria-label="Remove project"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>
    </div>
  );
}

function PeopleTab() {
  const { data, addPerson, addAllocation, removeAllocation, updateAllocation, removePerson } = useCapacity();

  const [projectId, setProjectId] = useState(data.projects[0]?.id ?? "");
  const [name, setName] = useState("");
  const [role, setRole] = useState(ROLES[1]!);
  const [allocation, setAllocation] = useState(1);

  function submit() {
    if (!name.trim()) {
      toast.error("Resource name is required");
      return;
    }
    if (!projectId) {
      toast.error("Add a project first");
      return;
    }
    const existing = data.people.find((p) => p.name.toLowerCase() === name.trim().toLowerCase());
    const personId = existing ? existing.id : addPerson({ name: name.trim(), role });
    const error = addAllocation({ personId, projectId, fte: Number(allocation) });
    if (error) {
      toast.error(error);
      return;
    }
    setName("");
    setAllocation(1);
    toast.success("Resource assignment added");
  }

  const assignments = data.allocations.map((a) => ({
    allocation: a,
    person: data.people.find((p) => p.id === a.personId),
    project: data.projects.find((p) => p.id === a.projectId),
  }));
  const peopleSort = useSortableRows(assignments, {
    project: (r) => r.project?.name,
    person: (r) => r.person?.name,
    role: (r) => r.person?.role,
    allocation: (r) => r.allocation.fte,
  });

  return (
    <div className="space-y-4">
      <Section title="Add a resource assignment">
        <p className="-mt-2 mb-4 text-sm text-muted-foreground">
          People here are FTE. FTC capacity is recorded on the project in the Projects tab.
        </p>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1.5">
            <Label>Project Name</Label>
            <select className={selectClass} value={projectId} onChange={(e) => setProjectId(e.target.value)}>
              {data.projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Resource Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sarah Chen" />
          </div>
          <div className="space-y-1.5">
            <Label>Role</Label>
            <select className={selectClass} value={role} onChange={(e) => setRole(e.target.value)}>
              {ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Allocation</Label>
            <Input
              type="number"
              step="0.1"
              min="0"
              value={allocation}
              onChange={(e) => setAllocation(Number(e.target.value))}
            />
          </div>
        </div>
        <div className="mt-5">
          <Button onClick={submit}>
            <Plus className="size-4" /> Add assignment
          </Button>
        </div>
      </Section>

      <Section title="People">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[42rem] text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase">
                {(
                  [
                    ["project", "Project Name", "py-2 pr-3", "left"],
                    ["person", "Resource Name", "py-2 pr-3", "left"],
                    ["role", "Role", "py-2 pr-3", "left"],
                    ["allocation", "Allocation", "py-2 pr-3 text-center", "center"],
                  ] as const
                ).map(([key, label, cls, align]) => (
                  <SortableTh
                    key={key}
                    columnKey={key}
                    label={label}
                    className={cls}
                    align={align}
                    sortKey={peopleSort.sortKey}
                    direction={peopleSort.direction}
                    onToggle={peopleSort.toggle}
                  />
                ))}
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {peopleSort.sorted.map(({ allocation: a, person, project }) => (
                <tr key={a.id} className="border-b border-border last:border-0">
                  <td className="py-2 pr-3 text-foreground">{project?.name ?? "—"}</td>
                  <td className="py-2 pr-3 text-foreground">{person?.name ?? "—"}</td>
                  <td className="py-2 pr-3 text-muted-foreground">{person?.role ?? "—"}</td>
                  <td className="py-2 pr-3 text-center">
                    <Input
                      className="mx-auto w-24"
                      type="number"
                      step="0.1"
                      min="0"
                      value={a.fte}
                      onChange={(e) => updateAllocation(a.id, { fte: round1(Number(e.target.value)) })}
                      aria-label="Allocation"
                    />
                  </td>
                  <td className="py-2 text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        removeAllocation(a.id);
                        const other = data.allocations.filter(
                          (x) => x.personId === a.personId && x.id !== a.id,
                        );
                        if (other.length === 0 && person) removePerson(person.id);
                      }}
                      aria-label="Remove assignment"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>
    </div>
  );
}

function Admin() {
  return (
    <main className="min-h-screen bg-surface px-4 py-8 md:px-10 md:py-12">
      <div className="mx-auto max-w-6xl space-y-6">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl tracking-tight text-foreground">Manage capacity data</h1>
            <p className="mt-1 text-muted-foreground">
              Everything here feeds the executive dashboard directly.
            </p>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            <ArrowLeft className="size-4" /> Back to dashboard
          </Link>
        </header>

        <TotalsStrip />
        <DataTransfer />

        <Tabs defaultValue="projects">
          <TabsList>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="people">People</TabsTrigger>
          </TabsList>
          <TabsContent value="projects" className="mt-4">
            <ProjectsTab />
          </TabsContent>
          <TabsContent value="people" className="mt-4">
            <PeopleTab />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  );
}
