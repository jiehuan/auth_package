# Team Pulse — Backend API

Team Pulse 看板的数据服务。Node 22 + 内置 `node:sqlite`,**零 npm 依赖**。

## 为什么零依赖

`package.json` 的 `dependencies` 是空的,用的是 Node 22 内置的 `node:sqlite`:

- 镜像构建没有 `npm install` 步骤 —— 不依赖 Artifactory,不会有 peer dependency 冲突
- 没有 `better-sqlite3` 那种原生模块编译(在 alpine 上经常出问题)
- 供应链攻击面基本为零

代价:`node:sqlite` 上游标注为 experimental。我们只用 `DatabaseSync`,自 Node 22.5 起 API 稳定。
Dockerfile 把基础镜像钉到了 `node:22.22-alpine`,升级大版本前先在测试环境验证。

## 快速开始

```bash
node --version        # 需要 >= 22.5
npm run dev           # http://localhost:8080/api,带 --watch
```

首次启动数据库为空时会自动灌入种子数据。**之后重启不会覆盖已有数据**
(`seedIfEmpty()` 只在 people 表为空时才写)。

## 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| `PORT` | `8080` | 监听端口 |
| `HOST` | `0.0.0.0` | 监听地址 |
| `DB_PATH` | `./data/team-pulse.db` | SQLite 文件路径,容器里指向 PVC |
| `API_BASE_PATH` | `/api` | 路由前缀 |
| `CORS_ORIGIN` | 空 | 仅本地开发需要;生产靠同源 Route 分流,留空 |

## 文件

```
server.mjs     # HTTP 路由、请求校验、业务规则、优雅退出
db.mjs         # schema/建表、事务封装、增删改查、快照组装
seed.mjs       # 初始数据
```

## API

Base path `/api`。**所有写操作都返回完整的 `CapacityData` 快照**,
前端整体替换 state,不会出现局部更新导致的状态漂移。

| Method | Path | 说明 |
|---|---|---|
| GET | `/api/health` | 探针 |
| GET | `/api/capacity` | 完整快照 |
| PUT | `/api/capacity` | 整体替换(Excel 导入走这里) |
| POST | `/api/capacity/reset` | 重置为种子数据 |
| POST | `/api/people` | 新增人员 |
| PATCH | `/api/people/:id` | 部分更新 |
| DELETE | `/api/people/:id` | 删除(级联清理其分配) |
| POST/PATCH/DELETE | `/api/projects[/:id]` | 项目,同上 |
| POST/PATCH/DELETE | `/api/allocations[/:id]` | 分配,同上 |

错误统一 `{ "error": "..." }`,状态码 400 / 404 / 405 / 413 / 500。

### 服务端强制的业务规则

这两条**必须**在服务端,否则两个人同时编辑就能把同一个人超配:

1. **不能超出个人 capacity** —— `POST/PATCH /allocations` 校验
   `fte <= capacity - 已分配`(PATCH 会排除自己这条,避免原地保存报错)
2. **capacity 不能改到低于已分配量** —— `PATCH /people/:id` 校验,
   否则仪表盘会出现负的剩余量

所有写操作包在事务里,校验失败整体回滚。

## 数据库

```
meta(key, value)                     -- 存 asOf
people(id, name, role, employment_type, capacity, is_floating)
projects(id, name, description, icon, priority, impact_if_delayed, impact_level)
project_role_needs(project_id → projects, role, fte)   PK(project_id, role)
allocations(id, person_id → people, project_id → projects, fte, kind)
```

外键全部 `ON DELETE CASCADE`。CHECK 约束保证枚举值和正数。WAL 模式 + `busy_timeout=5000`。

## 部署

```bash
docker build -t <registry>/<ns>/team-pulse-api:1.0.0 .
docker push <registry>/<ns>/team-pulse-api:1.0.0

# 改 openshift/backend.yaml 里的 REGISTRY_HOST/PROJECT
oc apply -f openshift/backend.yaml
oc rollout status deploy/team-pulse-api
oc get pvc team-pulse-data      # 应该是 Bound
```

暴露给浏览器需要前端仓库里的 `openshift/route.yaml` —— 两个 Route 共用一个 host,
按 path 把 `/api` 分流到这个服务。

### 为什么只能 1 个副本

SQLite 单写入端,PVC 是 ReadWriteOnce。所以 `replicas: 1` 且
`strategy: Recreate`(新 pod 没法在旧 pod 还占着卷的时候挂载 RWO 卷)。
这也是后端和前端拆开部署的原因 —— 合在一起会把前端也锁死在单副本。

## 备份

PVC 里就一个 SQLite 文件。最简单可靠的做法是直接存 API 返回的 JSON:

```bash
curl -s https://<host>/api/capacity > backup-$(date +%F).json
```

恢复就是 `PUT /api/capacity` 把这份 JSON 发回去。建议做成每日定时任务。

直接拷文件也行,但 WAL 模式下还有 `-wal` / `-shm`,要拿一致快照没那么简单:

```bash
POD=$(oc get pod -l app=team-pulse-api -o name | head -1)
oc cp ${POD#pod/}:/data/team-pulse.db ./backup.db
```

## 后续

1. **没有认证。** 现在能访问 Route 的人都能改数据。团队容量数据在保险公司算敏感信息,
   正式给团队用之前建议加 `oauth-proxy` sidecar 或接内部 Azure AD 网关。
2. **没有审计日志。** 谁在什么时候把谁从哪个项目挪走了,过两个月一定会有人问。
   加一张 `audit_log` 表成本很低,建议早点加。
3. **换 Postgres 的话** `db.mjs` 是唯一需要改的文件,`server.mjs` 的路由和校验不用动。
