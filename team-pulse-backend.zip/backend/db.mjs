import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { randomUUID } from "node:crypto";

import { SEED_DATA } from "./seed.mjs";

const DB_PATH = process.env.DB_PATH ?? "./data/team-pulse.db";

mkdirSync(dirname(DB_PATH), { recursive: true });

export const db = new DatabaseSync(DB_PATH);

// WAL gives concurrent readers alongside the single writer; the busy timeout
// stops transient "database is locked" errors under parallel requests.
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");
db.exec("PRAGMA busy_timeout = 5000");

db.exec(`
  CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS people (
    id   TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    role TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS projects (
    id                TEXT PRIMARY KEY,
    name              TEXT    NOT NULL,
    sponsor           TEXT    NOT NULL DEFAULT '',
    description       TEXT    NOT NULL DEFAULT '',
    icon              TEXT    NOT NULL DEFAULT 'rocket',
    priority          INTEGER NOT NULL DEFAULT 5,
    resource_needed   REAL    NOT NULL DEFAULT 0 CHECK (resource_needed >= 0),
    ftc_needed        REAL    NOT NULL DEFAULT 0 CHECK (ftc_needed >= 0),
    ftc_allocated     REAL    NOT NULL DEFAULT 0 CHECK (ftc_allocated >= 0),
    impact_if_delayed TEXT    NOT NULL DEFAULT '',
    impact_level      TEXT    NOT NULL DEFAULT 'Medium'
                              CHECK (impact_level IN ('High','Medium','Low'))
  );

  CREATE TABLE IF NOT EXISTS allocations (
    id         TEXT PRIMARY KEY,
    person_id  TEXT NOT NULL REFERENCES people(id)   ON DELETE CASCADE,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    fte        REAL NOT NULL CHECK (fte > 0)
  );

  CREATE INDEX IF NOT EXISTS idx_alloc_person  ON allocations(person_id);
  CREATE INDEX IF NOT EXISTS idx_alloc_project ON allocations(project_id);
`);

/**
 * In-place migration from earlier schemas.
 *
 * `CREATE TABLE IF NOT EXISTS` is a no-op against an existing database, so a
 * volume created before the model changed keeps its old columns and every
 * write fails with an opaque constraint error. Reconcile instead of asking
 * anyone to wipe the volume — the data in there is real.
 *
 * The role-need model was replaced by three plain numbers on the project, so
 * the old project_role_needs rows are folded into resource_needed before the
 * table is dropped. Everything else is column add/drop.
 */
function migrate() {
  const tables = new Set(
    db
      .prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
      .all()
      .map((t) => t.name),
  );
  const columns = (table) =>
    new Set(db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name));

  const applied = [];

  const projects = columns("projects");
  for (const [col, ddl] of [
    ["sponsor", "TEXT NOT NULL DEFAULT ''"],
    ["resource_needed", "REAL NOT NULL DEFAULT 0"],
    ["ftc_needed", "REAL NOT NULL DEFAULT 0"],
    ["ftc_allocated", "REAL NOT NULL DEFAULT 0"],
  ]) {
    if (projects.size && !projects.has(col)) {
      db.exec(`ALTER TABLE projects ADD COLUMN ${col} ${ddl}`);
      applied.push(`projects.${col} added`);
    }
  }

  // Carry the old per-role needs across as a single total, then retire them.
  if (tables.has("project_role_needs")) {
    db.exec(`
      UPDATE projects SET resource_needed = COALESCE((
        SELECT SUM(fte) FROM project_role_needs WHERE project_id = projects.id
      ), resource_needed)
    `);
    db.exec("DROP TABLE project_role_needs");
    applied.push("project_role_needs folded into projects.resource_needed and dropped");
  }

  const people = columns("people");
  for (const col of ["capacity", "is_floating", "employment_type"]) {
    if (people.has(col)) {
      db.exec(`ALTER TABLE people DROP COLUMN ${col}`);
      applied.push(`people.${col} dropped`);
    }
  }

  if (columns("allocations").has("kind")) {
    db.exec("ALTER TABLE allocations DROP COLUMN kind");
    applied.push("allocations.kind dropped");
  }

  if (applied.length) console.log(`Schema migrated: ${applied.join(", ")}`);
}

migrate();

export const newId = () => randomUUID().replaceAll("-", "").slice(0, 12);

/** Run fn inside a transaction; rolls back on throw. */
export function tx(fn) {
  db.exec("BEGIN");
  try {
    const result = fn();
    db.exec("COMMIT");
    return result;
  } catch (err) {
    try {
      db.exec("ROLLBACK");
    } catch {
      /* already rolled back */
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Reads
// ---------------------------------------------------------------------------

export function getAsOf() {
  const row = db.prepare("SELECT value FROM meta WHERE key = 'asOf'").get();
  return row?.value ?? new Date().toISOString().slice(0, 10);
}

export function setAsOf(value) {
  db.prepare(
    "INSERT INTO meta (key, value) VALUES ('asOf', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
  ).run(String(value));
}

/**
 * Full snapshot in exactly the CapacityData shape the frontend expects.
 * Every mutation returns this so the client never drifts out of sync.
 */
export function getCapacity() {
  const people = db
    .prepare("SELECT * FROM people ORDER BY rowid")
    .all()
    .map((r) => ({ id: r.id, name: r.name, role: r.role }));

  const projects = db
    .prepare("SELECT * FROM projects ORDER BY priority, rowid")
    .all()
    .map((r) => ({
      id: r.id,
      name: r.name,
      sponsor: r.sponsor,
      description: r.description,
      icon: r.icon,
      priority: r.priority,
      resourceNeeded: r.resource_needed,
      ftcNeeded: r.ftc_needed,
      ftcAllocated: r.ftc_allocated,
      impactIfDelayed: r.impact_if_delayed,
      impactLevel: r.impact_level,
    }));

  const allocations = db
    .prepare("SELECT * FROM allocations ORDER BY rowid")
    .all()
    .map((r) => ({
      id: r.id,
      personId: r.person_id,
      projectId: r.project_id,
      fte: r.fte,
    }));

  return { asOf: getAsOf(), people, projects, allocations };
}

// ---------------------------------------------------------------------------
// Writes
// ---------------------------------------------------------------------------

export function insertPerson(p) {
  const id = p.id ?? newId();
  db.prepare("INSERT INTO people (id, name, role) VALUES (?, ?, ?)").run(id, p.name, p.role);
  return id;
}

export function updatePerson(id, patch) {
  const current = db.prepare("SELECT * FROM people WHERE id = ?").get(id);
  if (!current) return false;
  db.prepare("UPDATE people SET name = ?, role = ? WHERE id = ?").run(
    patch.name ?? current.name,
    patch.role ?? current.role,
    id,
  );
  return true;
}

export function insertProject(p) {
  const id = p.id ?? newId();
  db.prepare(
    `INSERT INTO projects
       (id, name, sponsor, description, icon, priority,
        resource_needed, ftc_needed, ftc_allocated, impact_if_delayed, impact_level)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    id,
    p.name,
    p.sponsor ?? "",
    p.description ?? "",
    p.icon ?? "rocket",
    p.priority ?? 5,
    p.resourceNeeded ?? 0,
    p.ftcNeeded ?? 0,
    p.ftcAllocated ?? 0,
    p.impactIfDelayed ?? "",
    p.impactLevel ?? "Medium",
  );
  return id;
}

export function updateProject(id, patch) {
  const c = db.prepare("SELECT * FROM projects WHERE id = ?").get(id);
  if (!c) return false;
  db.prepare(
    `UPDATE projects SET name = ?, sponsor = ?, description = ?, icon = ?, priority = ?,
       resource_needed = ?, ftc_needed = ?, ftc_allocated = ?,
       impact_if_delayed = ?, impact_level = ? WHERE id = ?`,
  ).run(
    patch.name ?? c.name,
    patch.sponsor ?? c.sponsor,
    patch.description ?? c.description,
    patch.icon ?? c.icon,
    patch.priority ?? c.priority,
    patch.resourceNeeded ?? c.resource_needed,
    patch.ftcNeeded ?? c.ftc_needed,
    patch.ftcAllocated ?? c.ftc_allocated,
    patch.impactIfDelayed ?? c.impact_if_delayed,
    patch.impactLevel ?? c.impact_level,
    id,
  );
  return true;
}

export function insertAllocation(a) {
  const id = a.id ?? newId();
  db.prepare(
    "INSERT INTO allocations (id, person_id, project_id, fte) VALUES (?, ?, ?, ?)",
  ).run(id, a.personId, a.projectId, a.fte);
  return id;
}

export function updateAllocation(id, patch) {
  const c = db.prepare("SELECT * FROM allocations WHERE id = ?").get(id);
  if (!c) return false;
  db.prepare(
    "UPDATE allocations SET person_id = ?, project_id = ?, fte = ? WHERE id = ?",
  ).run(patch.personId ?? c.person_id, patch.projectId ?? c.project_id, patch.fte ?? c.fte, id);
  return true;
}

export function removeRow(table, id) {
  return db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id).changes > 0;
}

/**
 * Wipe everything and load a full CapacityData payload. This is what an Excel
 * upload does: the workbook is the whole truth, so the database is rebuilt
 * from it rather than merged into.
 */
export function replaceAll(data) {
  return tx(() => {
    db.exec("DELETE FROM allocations");
    db.exec("DELETE FROM projects");
    db.exec("DELETE FROM people");

    setAsOf(data.asOf ?? new Date().toISOString().slice(0, 10));
    for (const p of data.people ?? []) insertPerson(p);
    for (const p of data.projects ?? []) insertProject(p);
    for (const a of data.allocations ?? []) insertAllocation(a);
    return getCapacity();
  });
}

/** First boot only — never overwrites an existing database. */
export function seedIfEmpty() {
  const { count } = db.prepare("SELECT COUNT(*) AS count FROM people").get();
  if (count > 0) return false;
  replaceAll(SEED_DATA);
  return true;
}
