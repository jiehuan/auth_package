import { createFileRoute } from "@tanstack/react-router";

import {
  deleteContractor,
  getContractor,
  parseInput,
  updateContractor,
} from "@/server/contractors.server";
import { assertSameSiteWrite, handle, json, readJson } from "@/server/http.server";

type Ctx = { request: Request; params: { id: string } };

export const Route = createFileRoute("/api/contractors/$id")({
  server: {
    handlers: {
      GET: handle(({ params }: Ctx) => json(getContractor(params.id))),
      // Full replacement of the editable fields (the edit panel always sends them all).
      PUT: handle(async ({ request, params }: Ctx) =>
        json(updateContractor(params.id, parseInput(await readJson(request)))),
      ),
      DELETE: handle(({ request, params }: Ctx) => {
        assertSameSiteWrite(request);
        deleteContractor(params.id);
        return new Response(null, { status: 204 });
      }),
    },
  },
});
