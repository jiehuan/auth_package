import { createFileRoute } from "@tanstack/react-router";

import { createContractor, listContractors, parseInput } from "@/server/contractors.server";
import { handle, json, readJson } from "@/server/http.server";

export const Route = createFileRoute("/api/contractors/")({
  server: {
    handlers: {
      GET: handle(() => json(listContractors())),
      POST: handle(async ({ request }: { request: Request }) =>
        json(createContractor(parseInput(await readJson(request))), 201),
      ),
    },
  },
});
