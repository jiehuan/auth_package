import { createFileRoute } from "@tanstack/react-router";

import {
  ApiError,
  MAX_IMPORT_ROWS,
  importContractors,
  parseInput,
} from "@/server/contractors.server";
import { handle, json, readJson } from "@/server/http.server";

// Body: { mode: "replace" | "merge", rows: ContractorInput[], fields?: string[] }
// `fields` lists the columns that were mapped in the upload; merge only
// overwrites those on existing records.
// The spreadsheet is parsed and column-mapped in the browser; this endpoint
// validates every row and writes them in a single transaction.
export const Route = createFileRoute("/api/contractors/import")({
  server: {
    handlers: {
      POST: handle(async ({ request }: { request: Request }) => {
        const body = (await readJson(request)) as {
          mode?: unknown;
          rows?: unknown;
          fields?: unknown;
        };
        if (body.mode !== "replace" && body.mode !== "merge") {
          throw new ApiError(400, 'mode must be "replace" or "merge"');
        }
        if (!Array.isArray(body.rows) || body.rows.length === 0) {
          throw new ApiError(400, "rows must be a non-empty array");
        }
        if (body.rows.length > MAX_IMPORT_ROWS) {
          throw new ApiError(400, `At most ${MAX_IMPORT_ROWS} rows per import`);
        }
        const rows = body.rows.map((row, i) => {
          try {
            return parseInput(row);
          } catch (err) {
            if (err instanceof ApiError) throw new ApiError(400, `Row ${i + 1}: ${err.message}`);
            throw err;
          }
        });
        const fields =
          Array.isArray(body.fields) && body.fields.every((f) => typeof f === "string")
            ? (body.fields as string[])
            : undefined;
        return json(importContractors(body.mode, rows, fields));
      }),
    },
  },
});
