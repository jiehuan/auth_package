import { createFileRoute, Outlet } from "@tanstack/react-router";

// The dashboard loads its data from /api in the browser, so it renders
// client-side. There is no sign-in yet; when authentication is added, the
// check goes here (beforeLoad) and in src/server/http.server.ts for the API.
export const Route = createFileRoute("/_app")({
  ssr: false,
  component: () => <Outlet />,
});
