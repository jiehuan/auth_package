// Small helpers shared by the /api route handlers.
import { ApiError } from "./contractors.server";

const MAX_BODY_BYTES = 25 * 1024 * 1024; // a large contractor import is a few MB

export function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

/**
 * Every state-changing call must carry `X-Requested-With: fetch`. A page on
 * another site can't add that header without a CORS preflight (which we never
 * allow), so it can't write to this API through a colleague's browser.
 */
function assertSameSiteWrite(request: Request) {
  if (request.headers.get("x-requested-with") !== "fetch") {
    throw new ApiError(403, "Missing X-Requested-With header");
  }
}

export async function readJson(request: Request): Promise<unknown> {
  assertSameSiteWrite(request);
  const length = Number(request.headers.get("content-length") ?? 0);
  if (length > MAX_BODY_BYTES) throw new ApiError(413, "Request body is too large");
  const raw = await request.text();
  if (raw.length > MAX_BODY_BYTES) throw new ApiError(413, "Request body is too large");
  try {
    return raw ? JSON.parse(raw) : {};
  } catch {
    throw new ApiError(400, "Body is not valid JSON");
  }
}

export { assertSameSiteWrite };

/** Wraps a handler: ApiError -> JSON error with its status, anything else -> 500. */
export function handle<A extends unknown[]>(fn: (...args: A) => Promise<Response> | Response) {
  return async (...args: A): Promise<Response> => {
    try {
      return await fn(...args);
    } catch (err) {
      if (err instanceof ApiError) return json({ error: err.message }, err.status);
      console.error(err);
      return json({ error: "Internal server error" }, 500);
    }
  };
}
