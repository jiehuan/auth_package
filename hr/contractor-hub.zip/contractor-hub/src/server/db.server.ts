// SQLite storage for contractor records.
//
// Uses Node's built-in `node:sqlite` (unflagged since Node 22.13), so there is
// no native npm module to compile and nothing extra in the image. The database
// lives on the PVC mounted at DATA_DIR (/data in the container).
//
// Single writer: run exactly one pod (Deployment uses replicas: 1 + Recreate).
import { mkdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";

const MIGRATIONS: string[] = [
  // v1 — same columns as the original contractors table
  `
  CREATE TABLE contractors (
    id               TEXT PRIMARY KEY,
    name             TEXT NOT NULL,
    email            TEXT,
    department       TEXT,
    function         TEXT,
    country          TEXT,
    vendor           TEXT,
    monthly_rate     REAL,
    currency         TEXT,
    renewal_count    INTEGER NOT NULL DEFAULT 0,
    sow_name         TEXT,
    sow_start_date   TEXT,
    sow_end_date     TEXT,
    termination_date TEXT,
    addis_status     TEXT,
    manager          TEXT,
    notes            TEXT,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
  );
  CREATE INDEX idx_contractors_email ON contractors (lower(email));
  CREATE INDEX idx_contractors_sow_end_date ON contractors (sow_end_date);
  CREATE INDEX idx_contractors_vendor ON contractors (vendor);
  `,
];

function open(): DatabaseSync {
  const dataDir = resolve(process.env["DATA_DIR"] ?? "./data");
  const dbPath = process.env["DB_PATH"] ?? join(dataDir, "contractor-hub.db");
  mkdirSync(dataDir, { recursive: true });

  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA synchronous = NORMAL;");
  db.exec("PRAGMA busy_timeout = 5000;");
  db.exec("PRAGMA foreign_keys = ON;");

  const row = db.prepare("PRAGMA user_version").get() as { user_version: number };
  for (let v = row.user_version; v < MIGRATIONS.length; v++) {
    db.exec("BEGIN");
    try {
      db.exec(MIGRATIONS[v] ?? "");
      db.exec(`PRAGMA user_version = ${v + 1}`);
      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  }
  console.log(`[db] ${dbPath} (schema v${MIGRATIONS.length})`);
  return db;
}

let instance: DatabaseSync | undefined;

/** Opened lazily on first use, so building/prerendering never touches disk. */
export function getDb(): DatabaseSync {
  instance ??= open();
  return instance;
}

/** Runs `fn` inside one transaction; rolls back if it throws. */
export function transaction<T>(fn: (db: DatabaseSync) => T): T {
  const db = getDb();
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = fn(db);
    db.exec("COMMIT");
    return result;
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
