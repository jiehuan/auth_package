// Contractor data access and validation. Only server route handlers import
// this file (the `.server.ts` suffix keeps it out of the browser bundle).
import { randomUUID } from "node:crypto";

import type { Contractor, ContractorInput } from "@/lib/contractors";
import { getDb, transaction } from "./db.server";

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

const TEXT_FIELDS = [
  "name",
  "email",
  "department",
  "function",
  "country",
  "vendor",
  "currency",
  "sow_name",
  "addis_status",
  "manager",
  "notes",
] as const;
const DATE_FIELDS = ["sow_start_date", "sow_end_date", "termination_date"] as const;
const COLUMNS = [...TEXT_FIELDS, ...DATE_FIELDS, "monthly_rate", "renewal_count"] as const;

const MAX_TEXT = 500;
const MAX_NOTES = 5000;
export const MAX_IMPORT_ROWS = 20000;

function text(value: unknown, field: string): string | null {
  if (value === null || value === undefined) return null;
  if (typeof value !== "string" && typeof value !== "number") {
    throw new ApiError(400, `${field} must be text`);
  }
  const s = String(value).trim();
  if (!s) return null;
  const max = field === "notes" ? MAX_NOTES : MAX_TEXT;
  if (s.length > max) throw new ApiError(400, `${field} is longer than ${max} characters`);
  return s;
}

function date(value: unknown, field: string): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new ApiError(400, `${field} must be a date (YYYY-MM-DD)`);
  }
  const d = new Date(`${value}T00:00:00Z`);
  if (isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== value) {
    throw new ApiError(400, `${field} is not a valid date`);
  }
  return value;
}

function num(value: unknown, field: string): number | null {
  if (value === null || value === undefined || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n) || n < 0)
    throw new ApiError(400, `${field} must be a non-negative number`);
  return n;
}

/** Validates a full record (create / import). Unknown keys are ignored. */
export function parseInput(body: unknown): ContractorInput {
  if (!body || typeof body !== "object") throw new ApiError(400, "Expected a JSON object");
  const b = body as Record<string, unknown>;
  const out = {} as Record<string, unknown>;
  for (const f of TEXT_FIELDS) out[f] = text(b[f], f);
  for (const f of DATE_FIELDS) out[f] = date(b[f], f);
  const rate = num(b["monthly_rate"], "monthly_rate");
  out["monthly_rate"] = rate === null ? null : Math.round(rate * 100) / 100;
  out["renewal_count"] = Math.floor(num(b["renewal_count"], "renewal_count") ?? 0);
  if (!out["name"]) throw new ApiError(400, "Name is required");
  return out as ContractorInput;
}

function rowToContractor(row: Record<string, unknown>): Contractor {
  return row as unknown as Contractor;
}

const now = () => new Date().toISOString();

export function listContractors(): Contractor[] {
  return getDb()
    .prepare(
      // Same order as before: soonest SoW end first, records without an end date last.
      "SELECT * FROM contractors ORDER BY sow_end_date IS NULL, sow_end_date, lower(name)",
    )
    .all()
    .map((r) => rowToContractor(r as Record<string, unknown>));
}

export function getContractor(id: string): Contractor {
  const row = getDb().prepare("SELECT * FROM contractors WHERE id = ?").get(id);
  if (!row) throw new ApiError(404, "Contractor not found");
  return rowToContractor(row as Record<string, unknown>);
}

const INSERT_SQL = `INSERT INTO contractors (id, ${COLUMNS.join(", ")}, created_at, updated_at)
  VALUES (?, ${COLUMNS.map(() => "?").join(", ")}, ?, ?)`;
const UPDATE_SQL = `UPDATE contractors SET ${COLUMNS.map((c) => `${c} = ?`).join(", ")}, updated_at = ?
  WHERE id = ?`;

type Column = (typeof COLUMNS)[number];

const values = (r: ContractorInput) =>
  COLUMNS.map((c) => r[c] ?? null) as (string | number | null)[];

export function createContractor(input: ContractorInput): Contractor {
  const id = randomUUID();
  const t = now();
  getDb()
    .prepare(INSERT_SQL)
    .run(id, ...values(input), t, t);
  return getContractor(id);
}

export function updateContractor(id: string, input: ContractorInput): Contractor {
  const res = getDb()
    .prepare(UPDATE_SQL)
    .run(...values(input), now(), id);
  if (res.changes === 0) throw new ApiError(404, "Contractor not found");
  return getContractor(id);
}

export function deleteContractor(id: string): void {
  const res = getDb().prepare("DELETE FROM contractors WHERE id = ?").run(id);
  if (res.changes === 0) throw new ApiError(404, "Contractor not found");
}

export type ImportResult = { inserted: number; updated: number; deleted: number };

/**
 * Imports a spreadsheet in one transaction — either every row lands or none.
 *
 * replace: deletes everything, then inserts the rows.
 * merge:   matches by email (case-insensitive). A match is updated, and counts
 *          as a renewal when the new SoW end date is later than the stored one.
 *          Only the columns that were mapped in the upload (`fields`) are
 *          overwritten, so a file with just name/email/end date doesn't wipe
 *          everyone's rate, vendor, notes, etc. Rows without a match (or
 *          without an email) are inserted.
 */
export function importContractors(
  mode: "replace" | "merge",
  rows: ContractorInput[],
  fields?: readonly string[],
): ImportResult {
  return transaction((db) => {
    const insert = db.prepare(INSERT_SQL);
    const t = now();
    const result: ImportResult = { inserted: 0, updated: 0, deleted: 0 };

    if (mode === "replace") {
      result.deleted = Number(db.prepare("DELETE FROM contractors").run().changes);
      for (const r of rows) {
        insert.run(randomUUID(), ...values(r), t, t);
        result.inserted++;
      }
      return result;
    }

    // renewal_count is always recomputed below, never taken from the file.
    const mapped = new Set(fields ?? COLUMNS);
    const updateCols: Column[] = [
      ...COLUMNS.filter((c) => c !== "renewal_count" && mapped.has(c)),
      "renewal_count",
    ];
    const update = db.prepare(
      `UPDATE contractors SET ${updateCols.map((c) => `${c} = ?`).join(", ")}, updated_at = ? WHERE id = ?`,
    );

    type Existing = { id: string; sow_end_date: string | null; renewal_count: number };
    const byEmail = new Map<string, Existing>();
    for (const e of db
      .prepare(
        "SELECT id, email, sow_end_date, renewal_count FROM contractors WHERE email IS NOT NULL",
      )
      .all() as (Existing & { email: string })[]) {
      byEmail.set(e.email.toLowerCase(), e);
    }

    for (const r of rows) {
      const key = r.email?.toLowerCase();
      const found = key ? byEmail.get(key) : undefined;
      if (found) {
        const renewed =
          found.renewal_count +
          (r.sow_end_date && found.sow_end_date && r.sow_end_date > found.sow_end_date ? 1 : 0);
        const next = { ...r, renewal_count: renewed };
        update.run(...updateCols.map((c) => next[c] ?? null), t, found.id);
        // A second row with the same email in this file merges into the same record.
        if (mapped.has("sow_end_date"))
          found.sow_end_date = next.sow_end_date ?? found.sow_end_date;
        found.renewal_count = renewed;
        result.updated++;
      } else {
        const id = randomUUID();
        insert.run(id, ...values(r), t, t);
        if (key)
          byEmail.set(key, { id, sow_end_date: r.sow_end_date, renewal_count: r.renewal_count });
        result.inserted++;
      }
    }
    return result;
  });
}

export function countContractors(): number {
  const row = getDb().prepare("SELECT count(*) AS n FROM contractors").get() as { n: number };
  return row.n;
}
