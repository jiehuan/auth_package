/**
 * Browser-side client for the app's own /api routes.
 *
 * The API is served by the same Node server as the pages, so every call is a
 * same-origin request to a relative URL: no CORS and no API host baked into
 * the bundle.
 */
import type { Contractor, ContractorInput } from "@/lib/contractors";

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { accept: "application/json" };
  if (method !== "GET") headers["x-requested-with"] = "fetch";
  if (body !== undefined) headers["content-type"] = "application/json";

  const res = await fetch(path, {
    method,
    headers,
    ...(body !== undefined && { body: JSON.stringify(body) }),
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = (await res.json()) as { error?: string };
      if (data.error) message = data.error;
    } catch {
      /* not JSON */
    }
    throw new Error(message);
  }
  return (res.status === 204 ? undefined : await res.json()) as T;
}

export type ImportResult = { inserted: number; updated: number; deleted: number };

export const api = {
  listContractors: () => request<Contractor[]>("GET", "/api/contractors"),
  createContractor: (input: ContractorInput) =>
    request<Contractor>("POST", "/api/contractors", input),
  updateContractor: (id: string, input: ContractorInput) =>
    request<Contractor>("PUT", `/api/contractors/${encodeURIComponent(id)}`, input),
  deleteContractor: (id: string) =>
    request<void>("DELETE", `/api/contractors/${encodeURIComponent(id)}`),
  /** `fields`: the columns mapped in the upload — merge only overwrites these. */
  importContractors: (mode: "replace" | "merge", rows: ContractorInput[], fields: string[]) =>
    request<ImportResult>("POST", "/api/contractors/import", { mode, rows, fields }),
};
