# Contractor Hub

HR 用的外包人员 SoW 看板：上传 Excel/CSV，查看谁快到期、谁还在系统里，行内编辑，导出 Excel。

技术栈：TanStack Start（React 19，SSR）+ Tailwind v4 + shadcn/ui + recharts + SheetJS，Nitro `node-server` 构建。
**前端页面和 API 在同一个 Node 服务里**，不需要单独的后端。数据库是 Node 内置的 `node:sqlite`，文件放在 PVC 上。

## 结构

```
src/routes/_app/index.tsx          Dashboard 页面（KPI、图表、表格、筛选）
src/components/contractors/        上传对话框、编辑侧栏
src/lib/contractors.ts             类型、状态计算、Excel 解析和导出（浏览器端）
src/lib/api.ts                     浏览器调用 /api 的客户端
src/routes/api/                    API 路由（只在服务端运行）
src/server/db.server.ts            SQLite 连接和表结构迁移（PRAGMA user_version）
src/server/contractors.server.ts   数据读写、校验、导入逻辑
src/server/http.server.ts          JSON 响应、写请求 header 校验、错误处理
```

`*.server.ts` 文件不会打进浏览器 bundle。

## API

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/health` | 探针，会打开数据库，返回记录数 |
| GET | `/api/contractors` | 全部记录，按 SoW 结束日期排序 |
| POST | `/api/contractors` | 新增一条 |
| GET / PUT / DELETE | `/api/contractors/:id` | 读取、整条更新、删除 |
| POST | `/api/contractors/import` | `{ mode: "replace" \| "merge", rows, fields }`，在一个事务里完成 |

POST / PUT / DELETE 必须带 `X-Requested-With: fetch` header，前端已经统一加上。

导入规则：

- **replace**：删除全部记录，再插入文件里的行。
- **merge**：按邮箱匹配（不区分大小写）。匹配到的记录只覆盖上传时映射了的列，没映射的列保留原值。新的 SoW 结束日期比原来晚时，续约次数加 1。没匹配到、或没有邮箱的行直接新增。

状态由日期计算，不存库：已过终止日期为 Terminated，SoW 已结束为 Expired，180 天内结束为 Expiring，其余为 Active。

## 本地开发

```bash
npm ci
npm run dev          # http://localhost:3000，数据写到 ./data/contractor-hub.db
```

其他命令：`npm run typecheck`、`npm run lint`、`npm run build`、`npm start`（运行构建产物）。

需要 Node ≥ 22.13（`node:sqlite`）。更新依赖请用 **npm ≥ 12** 生成 `package-lock.json`，npm 10 生成的 lockfile 会让 `npm ci` 报 EUSAGE。

## 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| `PORT` / `HOST` | `3000` / `localhost`（镜像里是 `8080` / `0.0.0.0`） | |
| `DATA_DIR` | `./data`（镜像里是 `/data`） | SQLite 所在目录 |
| `DB_PATH` | `$DATA_DIR/contractor-hub.db` | 需要时单独指定 |

## 部署

| 文件 | 作用 |
|---|---|
| `harness/build-stage.yaml` | CI stage：`npm ci` → typecheck → build → `cp -r .output dist` → buildah 打包 |
| `Dockerfile` | 只 `COPY dist`，没有 RUN，运行时不需要 npm 和 `node_modules` |
| `openshift/deployment.yaml` | ConfigMap + PVC + Deployment + Service + Route（Harness Go 模板） |
| `openshift/values-dev.yaml` | DEV 环境值 |

要点：

- **单副本 + Recreate**：SQLite 单写，RWO 卷不能被两个 pod 同时挂载，滚动更新会卡住。
- **PVC** 带 `harness.io/skip-versioning`，否则每次部署都会换成一个新的空卷。
- **探针**：startup / readiness 打 `/api/health`（会访问数据库，卷没挂上时 pod 不会接流量）；liveness 打静态文件 `/healthz.json`。
- **备份**：数据只有 PVC 上的一个 SQLite 文件。可以定期 `oc rsync <pod>:/data ./backup`，或者请平台团队给卷做快照。
- 本地模拟镜像：`npm run build && rm -rf dist && cp -r .output dist && docker build -t contractor-hub:dev .`

## 登录（尚未实现）

目前没有登录，所有能访问 Route 的人都能查看和编辑。以后加登录要改两处：

- `src/routes/_app/route.tsx`：在 `beforeLoad` 里做页面的登录检查。
- `src/server/http.server.ts`：给 API 加身份校验。`handle()` 包住了所有 API handler，是统一加检查的位置。
