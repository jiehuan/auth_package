// Contractor data access and validation. Only server route handlers import
// this file (the `.server.ts` suffix keeps it out of the browser bundle).
import { randomUUID } from "node:crypto";

import type { Contractor, ContractorInput } from "@/lib/contractors";
import { getDb, transaction } from "./db.server";

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

const TEXT_FIELDS = [
  "name",
  "email",
  "work_type",
  "department",
  "function",
  "role",
  "country",
  "vendor",
  "currency",
  "sow_name",
  "contract_type",
  "addis_status",
  "manager",
  "notes",
] as const;
const DATE_FIELDS = ["sow_start_date", "sow_end_date", "termination_date"] as const;
const NUMBER_FIELDS = ["monthly_rate", "renewal_count"] as const;
const COLUMNS = [...TEXT_FIELDS, ...DATE_FIELDS, ...NUMBER_FIELDS] as const;
type Column = (typeof COLUMNS)[number];

const MAX_TEXT = 500;
const MAX_NOTES = 5000;
export const MAX_IMPORT_ROWS = 20000;
export const DEFAULT_WORK_TYPE = "Contractor";

function text(value: unknown, field: string): string | null {
  if (value === null || value === undefined) return null;
  if (typeof value !== "string" && typeof value !== "number") {
    throw new ApiError(400, `${field} must be text`);
  }
  const s = String(value).trim();
  if (!s) return null;
  const max = field === "notes" ? MAX_NOTES : MAX_TEXT;
  if (s.length > max) throw new ApiError(400, `${field} is longer than ${max} characters`);
  return s;
}

function date(value: unknown, field: string): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new ApiError(400, `${field} must be a date (YYYY-MM-DD)`);
  }
  const d = new Date(`${value}T00:00:00Z`);
  if (isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== value) {
    throw new ApiError(400, `${field} is not a valid date`);
  }
  return value;
}

function num(value: unknown, field: string): number | null {
  if (value === null || value === undefined || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n) || n < 0) {
    throw new ApiError(400, `${field} must be a non-negative number`);
  }
  return n;
}

function parseField(key: Column, value: unknown): string | number | null {
  if ((DATE_FIELDS as readonly string[]).includes(key)) return date(value, key);
  if (key === "monthly_rate") {
    const rate = num(value, key);
    return rate === null ? null : Math.round(rate * 100) / 100;
  }
  if (key === "renewal_count") return Math.floor(num(value, key) ?? 0);
  const t = text(value, key);
  if (key === "work_type") return t ?? DEFAULT_WORK_TYPE;
  return t;
}

/** Validates a full record (create / edit / new rows in an import). Unknown keys are ignored. */
export function parseInput(body: unknown): ContractorInput {
  if (!body || typeof body !== "object") throw new ApiError(400, "Expected a JSON object");
  const b = body as Record<string, unknown>;
  const out = {} as Record<string, unknown>;
  for (const key of COLUMNS) out[key] = parseField(key, b[key]);
  if (!out["name"]) throw new ApiError(400, "Name is required");
  return out as ContractorInput;
}

/** Validates a partial update: only the keys that are present are checked and returned. */
export function parseChanges(body: unknown): Partial<ContractorInput> {
  if (!body || typeof body !== "object") throw new ApiError(400, "Expected a JSON object");
  const b = body as Record<string, unknown>;
  const out = {} as Record<string, unknown>;
  for (const key of COLUMNS) {
    if (key in b) out[key] = parseField(key, b[key]);
  }
  if ("name" in out && !out["name"]) throw new ApiError(400, "Name cannot be empty");
  return out as Partial<ContractorInput>;
}

const now = () => new Date().toISOString();

export function listContractors(): Contractor[] {
  return getDb()
    .prepare(
      // Soonest SoW end first, records without an end date last.
      "SELECT * FROM contractors ORDER BY sow_end_date IS NULL, sow_end_date, lower(name)",
    )
    .all() as unknown as Contractor[];
}

export function getContractor(id: string): Contractor {
  const row = getDb().prepare("SELECT * FROM contractors WHERE id = ?").get(id);
  if (!row) throw new ApiError(404, "Contractor not found");
  return row as unknown as Contractor;
}

const INSERT_SQL = `INSERT INTO contractors (id, ${COLUMNS.join(", ")}, created_at, updated_at)
  VALUES (?, ${COLUMNS.map(() => "?").join(", ")}, ?, ?)`;

const values = (r: Partial<ContractorInput>, cols: readonly Column[] = COLUMNS) =>
  cols.map((c) => r[c] ?? null) as (string | number | null)[];

function updateSql(cols: readonly Column[]) {
  return `UPDATE contractors SET ${cols.map((c) => `${c} = ?`).join(", ")}, updated_at = ? WHERE id = ?`;
}

export function createContractor(input: ContractorInput): Contractor {
  const id = randomUUID();
  const t = now();
  getDb()
    .prepare(INSERT_SQL)
    .run(id, ...values(input), t, t);
  return getContractor(id);
}

export function updateContractor(id: string, input: ContractorInput): Contractor {
  const res = getDb()
    .prepare(updateSql(COLUMNS))
    .run(...values(input), now(), id);
  if (res.changes === 0) throw new ApiError(404, "Contractor not found");
  return getContractor(id);
}

export function deleteContractor(id: string): void {
  const res = getDb().prepare("DELETE FROM contractors WHERE id = ?").run(id);
  if (res.changes === 0) throw new ApiError(404, "Contractor not found");
}

export function countContractors(): number {
  const row = getDb().prepare("SELECT count(*) AS n FROM contractors").get() as { n: number };
  return row.n;
}

/* --------------------------------- import -------------------------------- */

export type ImportUpdate = { id: string; changes: Partial<ContractorInput> };

export type UploadLog = {
  file_name: string;
  work_type: string;
  row_count: number;
  conflict_count: number;
  overrides: unknown[];
  rows: unknown[];
};

export type ImportResult = { inserted: number; updated: number; upload_id: string };

/**
 * Applies an upload in one transaction: either every change lands (plus the
 * upload-history entry) or nothing does.
 *
 * The browser works out what to do — matching people by email (or name),
 * the conflict choices, renewal counting — and sends the result:
 *   inserts: new people (full records)
 *   updates: { id, changes } with only the fields that change
 */
export function applyImport(
  inserts: ContractorInput[],
  updates: ImportUpdate[],
  log: UploadLog,
  createdBy: string | null,
): ImportResult {
  return transaction((db) => {
    const t = now();
    const insert = db.prepare(INSERT_SQL);
    for (const r of inserts) insert.run(randomUUID(), ...values(r), t, t);

    let updated = 0;
    const seen = new Set<string>();
    for (const u of updates) {
      if (seen.has(u.id)) throw new ApiError(400, `Record ${u.id} is updated twice`);
      seen.add(u.id);
      const cols = COLUMNS.filter((c) => c in u.changes);
      if (!cols.length) continue;
      const res = db.prepare(updateSql(cols)).run(...values(u.changes, cols), t, u.id);
      if (res.changes === 0) {
        throw new ApiError(409, "A record changed while you were importing. Please upload again.");
      }
      updated++;
    }

    const uploadId = randomUUID();
    db.prepare(
      `INSERT INTO upload_history (id, file_name, work_type, row_count, inserted_count, updated_count,
         conflict_count, overrides, rows, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      uploadId,
      log.file_name,
      log.work_type,
      log.row_count,
      inserts.length,
      updated,
      log.conflict_count,
      JSON.stringify(log.overrides),
      JSON.stringify(log.rows),
      createdBy,
      t,
    );
    return { inserted: inserts.length, updated, upload_id: uploadId };
  });
}
