// Upload history and saved reports.
import { randomUUID } from "node:crypto";

import { ApiError } from "./contractors.server";
import { getDb } from "./db.server";

const HISTORY_LIMIT = 50;

export type UploadSummary = {
  id: string;
  file_name: string;
  work_type: string;
  row_count: number;
  inserted_count: number;
  updated_count: number;
  conflict_count: number;
  created_by: string | null;
  created_at: string;
};

/** Latest uploads, without the stored rows (those are fetched one upload at a time). */
export function listUploads(): UploadSummary[] {
  return getDb()
    .prepare(
      `SELECT id, file_name, work_type, row_count, inserted_count, updated_count, conflict_count,
              created_by, created_at
       FROM upload_history ORDER BY created_at DESC LIMIT ?`,
    )
    .all(HISTORY_LIMIT) as unknown as UploadSummary[];
}

export function getUpload(id: string) {
  const row = getDb().prepare("SELECT * FROM upload_history WHERE id = ?").get(id) as
    (UploadSummary & { rows: string; overrides: string }) | undefined;
  if (!row) throw new ApiError(404, "Upload not found");
  return {
    ...row,
    rows: JSON.parse(row.rows) as unknown[],
    overrides: JSON.parse(row.overrides) as unknown[],
  };
}

/* ----------------------------- saved reports ----------------------------- */

export type SavedReport = {
  id: string;
  name: string;
  filters: Record<string, unknown>;
  columns: string[];
  created_by: string | null;
  created_at: string;
};

type ReportRow = Omit<SavedReport, "filters" | "columns"> & { filters: string; columns: string };

const MAX_REPORT_JSON = 20_000;

export function listReports(): SavedReport[] {
  const rows = getDb()
    .prepare(
      "SELECT id, name, filters, columns, created_by, created_at FROM saved_reports ORDER BY created_at DESC",
    )
    .all() as unknown as ReportRow[];
  return rows.map((r) => ({
    ...r,
    filters: JSON.parse(r.filters) as Record<string, unknown>,
    columns: JSON.parse(r.columns) as string[],
  }));
}

export function parseReport(body: unknown) {
  if (!body || typeof body !== "object") throw new ApiError(400, "Expected a JSON object");
  const b = body as Record<string, unknown>;
  const name = typeof b["name"] === "string" ? b["name"].trim() : "";
  if (!name || name.length > 100) throw new ApiError(400, "Name is required (max 100 characters)");
  const filters = b["filters"] ?? {};
  if (typeof filters !== "object" || filters === null || Array.isArray(filters)) {
    throw new ApiError(400, "filters must be an object");
  }
  const columns = b["columns"] ?? [];
  if (!Array.isArray(columns) || !columns.every((c) => typeof c === "string")) {
    throw new ApiError(400, "columns must be a list of column keys");
  }
  const f = JSON.stringify(filters);
  const c = JSON.stringify(columns);
  if (f.length + c.length > MAX_REPORT_JSON) throw new ApiError(400, "Report is too large");
  return { name, filters: f, columns: c };
}

export function createReport(
  input: ReturnType<typeof parseReport>,
  createdBy: string | null,
): SavedReport {
  const id = randomUUID();
  const t = new Date().toISOString();
  getDb()
    .prepare(
      "INSERT INTO saved_reports (id, name, filters, columns, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
    )
    .run(id, input.name, input.filters, input.columns, createdBy, t, t);
  return listReports().find((r) => r.id === id)!;
}

/**
 * Deletes a report. Once sign-in exists, only its creator may delete it
 * (the same rule the UI applies when it shows the delete button).
 */
export function deleteReport(id: string, userId: string | null): void {
  const row = getDb().prepare("SELECT created_by FROM saved_reports WHERE id = ?").get(id) as
    { created_by: string | null } | undefined;
  if (!row) throw new ApiError(404, "Report not found");
  if (row.created_by !== null && row.created_by !== userId) {
    throw new ApiError(403, "Only the person who saved this report can delete it");
  }
  getDb().prepare("DELETE FROM saved_reports WHERE id = ?").run(id);
}
