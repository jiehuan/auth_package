/**
 * Browser-side client for the app's own /api routes.
 *
 * The API is served by the same Node server as the pages, so every call is a
 * same-origin request to a relative URL: no CORS and no API host baked into
 * the bundle.
 */
import type { Contractor, ContractorInput } from "@/lib/contractors";

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { accept: "application/json" };
  if (method !== "GET") headers["x-requested-with"] = "fetch";
  if (body !== undefined) headers["content-type"] = "application/json";

  const res = await fetch(path, {
    method,
    headers,
    ...(body !== undefined && { body: JSON.stringify(body) }),
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = (await res.json()) as { error?: string };
      if (data.error) message = data.error;
    } catch {
      /* not JSON */
    }
    throw new Error(message);
  }
  return (res.status === 204 ? undefined : await res.json()) as T;
}

export type ImportPayload = {
  inserts: ContractorInput[];
  updates: { id: string; changes: Partial<ContractorInput> }[];
  log: {
    file_name: string;
    work_type: string;
    row_count: number;
    conflict_count: number;
    overrides: Record<string, unknown>[];
    rows: Record<string, unknown>[];
  };
};
export type ImportResult = { inserted: number; updated: number; upload_id: string };

export type UploadSummary = {
  id: string;
  file_name: string;
  work_type: string;
  row_count: number;
  inserted_count: number;
  updated_count: number;
  conflict_count: number;
  created_by: string | null;
  created_at: string;
};
export type UploadDetail = UploadSummary & {
  rows: Record<string, unknown>[];
  overrides: Record<string, unknown>[];
};

export type SavedReportDto = {
  id: string;
  name: string;
  filters: Record<string, unknown>;
  columns: string[];
  created_by: string | null;
  created_at: string;
};

const enc = encodeURIComponent;

export const api = {
  me: () => request<{ id: string | null }>("GET", "/api/me"),

  listContractors: () => request<Contractor[]>("GET", "/api/contractors"),
  createContractor: (input: ContractorInput) =>
    request<Contractor>("POST", "/api/contractors", input),
  updateContractor: (id: string, input: ContractorInput) =>
    request<Contractor>("PUT", `/api/contractors/${enc(id)}`, input),
  deleteContractor: (id: string) => request<void>("DELETE", `/api/contractors/${enc(id)}`),
  /** Applies an upload (new rows + changed fields + history entry) in one transaction. */
  importContractors: (payload: ImportPayload) =>
    request<ImportResult>("POST", "/api/contractors/import", payload),

  listUploads: () => request<UploadSummary[]>("GET", "/api/uploads"),
  getUpload: (id: string) => request<UploadDetail>("GET", `/api/uploads/${enc(id)}`),

  listReports: () => request<SavedReportDto[]>("GET", "/api/reports"),
  createReport: (input: { name: string; filters: unknown; columns: string[] }) =>
    request<SavedReportDto>("POST", "/api/reports", input),
  deleteReport: (id: string) => request<void>("DELETE", `/api/reports/${enc(id)}`),
};
