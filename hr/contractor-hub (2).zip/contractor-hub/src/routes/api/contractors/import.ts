import { createFileRoute } from "@tanstack/react-router";

import {
  ApiError,
  DEFAULT_WORK_TYPE,
  MAX_IMPORT_ROWS,
  applyImport,
  parseChanges,
  parseInput,
  type ImportUpdate,
  type UploadLog,
} from "@/server/contractors.server";
import { currentUserId, handle, json, readJson } from "@/server/http.server";

// Body:
// {
//   inserts: ContractorInput[],                       new people
//   updates: { id, changes: Partial<ContractorInput> }[],  only the changed fields
//   log: { file_name, work_type, row_count, conflict_count, overrides[], rows[] }
// }
// The spreadsheet is parsed, matched and conflict-resolved in the browser;
// this endpoint validates everything and writes it in a single transaction,
// together with the upload-history entry.

function rowError(label: string, i: number, err: unknown): never {
  if (err instanceof ApiError) throw new ApiError(400, `${label} ${i + 1}: ${err.message}`);
  throw err;
}

function int(v: unknown, field: string): number {
  if (typeof v !== "number" || !Number.isInteger(v) || v < 0) {
    throw new ApiError(400, `log.${field} must be a non-negative integer`);
  }
  return v;
}

function parseLog(v: unknown): UploadLog {
  if (!v || typeof v !== "object") throw new ApiError(400, "log is required");
  const l = v as Record<string, unknown>;
  const fileName = typeof l["file_name"] === "string" ? l["file_name"].trim().slice(0, 255) : "";
  if (!fileName) throw new ApiError(400, "log.file_name is required");
  const workType =
    typeof l["work_type"] === "string" && l["work_type"].trim()
      ? l["work_type"].trim().slice(0, 50)
      : DEFAULT_WORK_TYPE;
  const overrides = l["overrides"] ?? [];
  const rows = l["rows"] ?? [];
  if (!Array.isArray(overrides) || !Array.isArray(rows)) {
    throw new ApiError(400, "log.overrides and log.rows must be lists");
  }
  if (rows.length > MAX_IMPORT_ROWS)
    throw new ApiError(400, `At most ${MAX_IMPORT_ROWS} rows per upload`);
  return {
    file_name: fileName,
    work_type: workType,
    row_count: int(l["row_count"], "row_count"),
    conflict_count: int(l["conflict_count"], "conflict_count"),
    overrides,
    rows,
  };
}

export const Route = createFileRoute("/api/contractors/import")({
  server: {
    handlers: {
      POST: handle(async ({ request }: { request: Request }) => {
        const body = (await readJson(request)) as {
          inserts?: unknown;
          updates?: unknown;
          log?: unknown;
        };
        const rawInserts = body.inserts ?? [];
        const rawUpdates = body.updates ?? [];
        if (!Array.isArray(rawInserts) || !Array.isArray(rawUpdates)) {
          throw new ApiError(400, "inserts and updates must be lists");
        }
        if (rawInserts.length + rawUpdates.length > MAX_IMPORT_ROWS) {
          throw new ApiError(400, `At most ${MAX_IMPORT_ROWS} rows per upload`);
        }

        const inserts = rawInserts.map((row, i) => {
          try {
            return parseInput(row);
          } catch (err) {
            return rowError("New row", i, err);
          }
        });
        const updates: ImportUpdate[] = rawUpdates.map((u, i) => {
          try {
            const { id, changes } = (u ?? {}) as { id?: unknown; changes?: unknown };
            if (typeof id !== "string" || !id) throw new ApiError(400, "id is required");
            return { id, changes: parseChanges(changes) };
          } catch (err) {
            return rowError("Update", i, err);
          }
        });

        return json(applyImport(inserts, updates, parseLog(body.log), currentUserId(request)));
      }),
    },
  },
});
