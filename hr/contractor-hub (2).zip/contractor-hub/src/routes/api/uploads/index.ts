import { createFileRoute } from "@tanstack/react-router";

import { handle, json } from "@/server/http.server";
import { listUploads } from "@/server/history.server";

// Latest 50 uploads, without the stored file rows.
export const Route = createFileRoute("/api/uploads/")({
  server: {
    handlers: {
      GET: handle(() => json(listUploads())),
    },
  },
});
