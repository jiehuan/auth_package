import { createFileRoute } from "@tanstack/react-router";

import { handle, json } from "@/server/http.server";
import { getUpload } from "@/server/history.server";

// One upload including the original rows and the conflict choices (for download).
export const Route = createFileRoute("/api/uploads/$id")({
  server: {
    handlers: {
      GET: handle(({ params }: { params: { id: string } }) => json(getUpload(params.id))),
    },
  },
});
