import { createFileRoute } from "@tanstack/react-router";

import { currentUserId, handle, json, readJson } from "@/server/http.server";
import { createReport, listReports, parseReport } from "@/server/history.server";

// Saved reports are shared: everyone sees every report.
export const Route = createFileRoute("/api/reports/")({
  server: {
    handlers: {
      GET: handle(() => json(listReports())),
      POST: handle(async ({ request }: { request: Request }) =>
        json(createReport(parseReport(await readJson(request)), currentUserId(request)), 201),
      ),
    },
  },
});
