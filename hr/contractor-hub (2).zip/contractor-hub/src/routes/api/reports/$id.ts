import { createFileRoute } from "@tanstack/react-router";

import { assertSameSiteWrite, currentUserId, handle } from "@/server/http.server";
import { deleteReport } from "@/server/history.server";

export const Route = createFileRoute("/api/reports/$id")({
  server: {
    handlers: {
      DELETE: handle(({ request, params }: { request: Request; params: { id: string } }) => {
        assertSameSiteWrite(request);
        deleteReport(params.id, currentUserId(request));
        return new Response(null, { status: 204 });
      }),
    },
  },
});
