import { createFileRoute } from "@tanstack/react-router";

import { currentUserId, handle, json } from "@/server/http.server";

// The signed-in user. Always { id: null } until authentication is added.
export const Route = createFileRoute("/api/me")({
  server: {
    handlers: {
      GET: handle(({ request }: { request: Request }) => json({ id: currentUserId(request) })),
    },
  },
});
