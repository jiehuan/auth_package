# Team Pulse — 前端 OpenShift 部署说明

> 后端 (SQLite) 部分见 **BACKEND.md**。前端现在依赖 `/api`,两者需要一起部署。

## 0. 这个项目的关键特性(先读这段)

`vite.config.ts` 使用 `@lovable.dev/vite-tanstack-config`,底层是 **TanStack Start + Nitro**,
不是普通的 Vite SPA:

- `npm run build` 产出的不是 `dist/`,而是 **`.output/`**(Nitro server bundle)。
- Lovable 的默认 Nitro preset 是 **`cloudflare-module`**,直接 build 会产出 Cloudflare Worker 格式,在 OpenShift 上跑不了。
- 解决办法:build 时设 **`NITRO_PRESET=node-server`**(Dockerfile 里已经设好)。
- 产物完全自包含(约 3 MB),**运行时不需要 `node_modules`**,所以 runtime 镜像非常小。

### 为什么不用 nginx 托静态文件

这套模板是 SSR 的 —— server entry 在 `src/server.ts`,`src/start.ts` 还注册了 CSRF middleware。
虽然目前业务数据全在 `localStorage`(`src/lib/capacity-store.tsx`),理论上可以改成纯 SPA,
但那要动 TanStack Start 的 SPA mode + prerender 配置,属于改代码,风险比换个 preset 大得多。
现在这条 Node 路线我已经实际跑通验证过。

---

## 1. 需要加到仓库里的文件

```
Dockerfile                    # 根目录
.dockerignore                 # 根目录
public/healthz.json           # 新增,给 k8s 探针用
openshift/deployment.yaml
openshift/service.yaml
openshift/route.yaml
```

`public/healthz.json` 必须在 **build 之前**存在 —— Nitro 在构建期把 `public/` 烘进静态资源清单,
运行时再往 `.output/public/` 丢文件是**不会被 serve 的**(这点我实测过,会返回 404)。

---

## 2. 本地验证

```bash
docker build -t team-pulse:1.0.0 .
docker run --rm -p 8080:8080 team-pulse:1.0.0

curl -i http://localhost:8080/healthz.json   # 200 application/json
curl -i http://localhost:8080/               # 200 SSR HTML
curl -o /dev/null -w '%{http_code}\n' http://localhost:8080/nope   # 404(探针语义正确)
```

用内部 Artifactory 的话:

```bash
docker build \
  --build-arg NODE_IMAGE=<artifactory-host>/docker-remote/node:22-alpine \
  --build-arg NPM_REGISTRY=https://<artifactory-host>/artifactory/api/npm/npm-virtual/ \
  -t team-pulse:1.0.0 .
```

---

## 3. 推镜像 + 部署

```bash
oc project <your-namespace>

# 推到集群内部 registry(或你们的 Artifactory)
docker tag team-pulse:1.0.0 <registry>/<namespace>/team-pulse:1.0.0
docker push <registry>/<namespace>/team-pulse:1.0.0

# 改掉 deployment.yaml 里的 image 占位符 REGISTRY_HOST/PROJECT/...
oc apply -f openshift/service.yaml
oc apply -f openshift/deployment.yaml
oc apply -f openshift/route.yaml

oc rollout status deploy/team-pulse
oc get route team-pulse -o jsonpath='{.spec.host}{"\n"}'
```

---

## 4. OpenShift 相关的设计点

| 项目 | 处理方式 |
|---|---|
| 任意 UID | 镜像文件 `chown 1001:0` + `chmod -R g=u`;manifest 里**不写** `runAsUser`,交给 SCC 分配 |
| 端口 | 8080(非 root 无法绑 <1024) |
| `restricted-v2` SCC | `allowPrivilegeEscalation: false`、`capabilities.drop: [ALL]`、`seccompProfile: RuntimeDefault`、`runAsNonRoot: true` |
| 只读根文件系统 | `readOnlyRootFilesystem: true` + `/tmp` 挂 emptyDir(Node 偶尔要写 /tmp) |
| 优雅退出 | `CMD` 用 exec form,node 是 PID 1 直接收 SIGTERM;Nitro 的 srvx 会优雅关闭 |
| 探针 | 打 `/healthz.json` 静态文件,不触发 SSR 渲染,开销极低 |

---

## 5. Harness Pipeline 要点

沿用你之前 GDI GLR 那套结构,几处不同:

- **Build stage**:`NITRO_PRESET=node-server` 必须传进去。如果你们的 Harness step 不方便设环境变量,
  也可以改 `vite.config.ts` 显式钉死:
  ```ts
  export default defineConfig({
    nitro: { preset: "node-server" },
    tanstackStart: { server: { entry: "server" } },
  });
  ```
  但注意这是 Lovable 托管的文件,Lovable 侧改动可能覆盖它 —— 所以更推荐用环境变量。
- **不需要**前端那套 nginx-unprivileged 配置了,这次是 Node 进程直接监听。
- **不需要** Vite `VITE_*` 构建期变量注入 —— 代码里没有任何 `import.meta.env` 或后端 API 调用,
  全是纯前端 + localStorage。以后接后端时再加。
- 镜像 tag 建议用 commit SHA 或语义化版本,别用 `latest`(manifest 里 `imagePullPolicy: IfNotPresent`)。

---

## 6. 两个建议

1. **补一个 `package-lock.json`**。现在仓库只有 `bun.lock`,Dockerfile 只能用 `npm install`,
   每次构建的依赖树可能漂移。本地跑一次 `npm install` 把 lock 文件提交上去,
   然后把 Dockerfile 里那行换成 `npm ci --no-audit --no-fund`。
2. **注意数据持久化**。当前所有 capacity 数据存在浏览器 `localStorage` 里,
   换电脑/换浏览器/清缓存就没了,也无法多人共享。如果 Team Pulse 是要给团队用的,
   这个迟早要接后端 —— 到时候 Deployment 里加 `ConfigMap` 注入 API base URL 就行。
