# Team Pulse — 后端 (SQLite)

## 架构

```
                    ┌─────────────────────────────┐
   浏览器 ──HTTPS──► │  OpenShift Route            │
                    │  同一个 host,按 path 分流   │
                    └──────┬───────────────┬──────┘
                       /api│               │/
                           ▼               ▼
                  ┌────────────────┐  ┌──────────────────┐
                  │ team-pulse-api │  │ team-pulse       │
                  │ Node + sqlite  │  │ TanStack SSR     │
                  │ replicas: 1    │  │ replicas: 2      │
                  └───────┬────────┘  └──────────────────┘
                          │
                    ┌─────▼─────┐
                    │ PVC 1Gi   │
                    │ RWO       │
                    └───────────┘
```

**为什么分成两个服务:** SQLite 只能有一个写入端,PVC 是 ReadWriteOnce,
所以后端必须锁死 `replicas: 1` + `strategy: Recreate`。如果把 API 塞进 SSR 服务里,
前端也会被一起锁死在单副本。拆开之后前端可以随便扩。

**为什么用 path 分流而不是两个域名:** 浏览器始终在同一个 origin,
所以不需要 CORS,也不需要在构建期把 API 地址烤进 bundle(改地址不用重新 build)。

## 技术选型

后端用 **Node 22 内置的 `node:sqlite`**,`package.json` 的 `dependencies` 是**空的**:

- 镜像构建没有 `npm install` 这一步 —— 不依赖 Artifactory,不会有 peer dependency 冲突
- 没有 `better-sqlite3` 那种原生模块编译(在 alpine / OpenShift builder 上经常出问题)
- 供应链攻击面基本为零

代价:`node:sqlite` 上游标注为 experimental。我们只用 `DatabaseSync`,
自 Node 22.5 起 API 稳定。Dockerfile 里把基础镜像**钉到了 `node:22.22-alpine`**,
升级大版本前先在测试环境验证。

---

## 文件清单

```
backend/
  package.json        # type: module,零依赖
  server.mjs          # HTTP 路由 + 校验 + 业务规则
  db.mjs              # schema / 迁移 / 数据访问
  seed.mjs            # 初始数据(从原 capacity-seed.ts 移植)
  Dockerfile

src/lib/capacity-store.tsx   # 替换原文件(改成调 API)

openshift/
  backend.yaml        # PVC + Deployment + Service
  deployment.yaml     # 前端 Deployment + PDB
  service.yaml        # 前端 Service
  route.yaml          # 两个 Route,同 host,按 path 分流
```

---

## 数据库 Schema

```
meta(key, value)                     -- 存 asOf
people(id, name, role, employment_type, capacity, is_floating)
projects(id, name, description, icon, priority, impact_if_delayed, impact_level)
project_role_needs(project_id → projects, role, fte)     PK(project_id, role)
allocations(id, person_id → people, project_id → projects, fte, kind)
```

- 外键全部 `ON DELETE CASCADE`:删人自动清掉他的 allocation,删项目自动清掉需求和 allocation
- CHECK 约束保证 `employmentType ∈ {FTE,FTC}`、`kind ∈ {fixed,floating}`、`capacity > 0`
- WAL 模式 + `busy_timeout = 5000`,并发读不阻塞

---

## API

Base path `/api`(`API_BASE_PATH` 可改)。**所有写操作都返回完整的 `CapacityData` 快照**,
前端直接整体替换 state,不会出现局部更新导致的状态漂移。

| Method | Path | 说明 |
|---|---|---|
| GET | `/api/health` | 探针 |
| GET | `/api/capacity` | 完整快照 |
| PUT | `/api/capacity` | 整体替换(Excel 导入走这里) |
| POST | `/api/capacity/reset` | 重置为 seed 数据 |
| POST | `/api/people` | 新增 |
| PATCH | `/api/people/:id` | 部分更新 |
| DELETE | `/api/people/:id` | 删除(级联) |
| POST/PATCH/DELETE | `/api/projects[/:id]` | 同上 |
| POST/PATCH/DELETE | `/api/allocations[/:id]` | 同上 |

错误统一返回 `{ "error": "..." }`,状态码 400 / 404 / 405 / 413 / 500。

### 服务端强制的业务规则

这两条**必须**放在服务端,否则两个人同时编辑就能把同一个人超配:

1. **不能超出个人 capacity** —— `POST/PATCH /allocations` 时校验
   `fte <= capacity - 已分配`(PATCH 时会排除自己这条记录,避免原地保存报错)
2. **capacity 不能改到低于已分配量** —— `PATCH /people/:id` 时校验,
   否则仪表盘会出现负的剩余量

所有写操作都包在事务里,校验失败整体回滚(已验证:失败的 PUT 不会留下半个状态)。

---

## 前端改动

只替换了 `src/lib/capacity-store.tsx` 一个文件。`Store` 接口**完全没变**,
所以 `index.tsx`、`admin.tsx`、`DataTransfer.tsx` **一行都不用改**。

几个刻意的设计:

- **`addAllocation` 保持同步返回 `string | null`** —— `admin.tsx` 里是
  `const error = addAllocation(...)` 这样用的,改成 async 会让 `if (error)`
  永远为真(Promise 是 truthy)。所以保留客户端同步预校验做即时反馈,
  服务端再校验一次作为真正的权威。
- **不做乐观更新** —— 服务端持有 capacity 规则,被拒绝的写入不应该在界面上
  留下一条幽灵记录。失败时 toast 报错 + 重新拉取服务端状态。
- **首次加载前 Provider 渲染 loading 态** —— 因为 `admin.tsx` 里有
  `useState(data.people[0]?.id ?? "")` 这种在 mount 时从 data 取初值的写法,
  如果初始是空数组,下拉框会永远空着。等数据到位再渲染 children 就绕过了这个问题,
  也不用改组件。

---

## 本地开发

```bash
# 终端 1:后端
cd backend && DB_PATH=./data/dev.db npm run dev

# 终端 2:前端(需要加 vite proxy)
npm run dev
```

`vite.config.ts` 加一段 proxy,让 dev server 的 `/api` 转发到后端:

```ts
export default defineConfig({
  vite: {
    server: { proxy: { "/api": "http://localhost:8080" } },
  },
  tanstackStart: { server: { entry: "server" } },
});
```

不想改 vite config 的话,也可以给后端设 `CORS_ORIGIN=http://localhost:5173`。

---

## 部署

```bash
oc project <namespace>

# 1. 构建推送两个镜像
docker build -t <registry>/<ns>/team-pulse:1.0.0 .
docker build -t <registry>/<ns>/team-pulse-api:1.0.0 ./backend
docker push <registry>/<ns>/team-pulse:1.0.0
docker push <registry>/<ns>/team-pulse-api:1.0.0

# 2. 改占位符:
#    openshift/backend.yaml    -> REGISTRY_HOST/PROJECT
#    openshift/deployment.yaml -> REGISTRY_HOST/PROJECT
#    openshift/route.yaml      -> CLUSTER_DOMAIN(两处必须一致!)

# 3. 后端先起,确保 PVC 绑上了再上前端
oc apply -f openshift/backend.yaml
oc rollout status deploy/team-pulse-api
oc get pvc team-pulse-data          # 应该是 Bound

oc apply -f openshift/service.yaml
oc apply -f openshift/deployment.yaml
oc apply -f openshift/route.yaml
oc rollout status deploy/team-pulse

# 4. 验证
HOST=$(oc get route team-pulse -o jsonpath='{.spec.host}')
curl -s https://$HOST/api/health
curl -s https://$HOST/api/capacity | head -c 200
```

首次启动时数据库为空,后端会自动灌入 seed 数据。**之后重启不会覆盖已有数据**
(`seedIfEmpty` 只在 people 表为空时才写)。

---

## 运维

**备份。** PVC 里就一个 SQLite 文件,备份很简单:

```bash
POD=$(oc get pod -l app=team-pulse-api -o name | head -1)
oc exec $POD -- sh -c 'ls /data'
oc cp ${POD#pod/}:/data/team-pulse.db ./backup-$(date +%F).db
```

注意 WAL 模式下还有 `-wal` / `-shm` 文件。要拿到一致的快照,更稳妥的做法是
在应用里加一个导出接口,或者用 `sqlite3 .backup`(镜像里没装 sqlite3 CLI,
需要的话可以直接调 `GET /api/capacity` 存成 JSON —— 那就是完整数据)。

**建议加个定时任务**,每天把 `GET /api/capacity` 的结果存一份 JSON 到对象存储。

---

## 后续要注意的

1. **没有认证。** 现在任何能访问这个 Route 的人都能改数据。
   如果是内网自用可以先这样;要收紧的话,OpenShift 上最省事的是加
   `oauth-proxy` sidecar 走集群 SSO,或者你们内部的 Azure AD 网关。
2. **SQLite 的天花板。** 这个规模(几十人、几十个项目)完全够用,
   而且团队容量数据本来就是低频写入。真到了需要多副本写入的时候,
   `db.mjs` 是唯一需要改的文件 —— 换成 Postgres 的话把里面的 SQL 挪过去就行,
   `server.mjs` 的路由和校验逻辑不用动。
3. **没有审计日志。** 容量规划这种数据,谁在什么时候把谁从哪个项目挪走了,
   过两个月一定会有人问。加一张 `audit_log` 表成本很低,建议早点加。
