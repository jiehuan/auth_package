# Alpha Vantage — APIM Onboarding

Artifacts:

| File | Purpose |
|---|---|
| `alphavantage-openapi.yaml` | OpenAPI 3.0.1 spec, 116 operations under `x-ms-paths`. Validates against the 3.0.1 schema. |
| `apim-policy.xml` | API-scope policy. Key injection, quota, cache, error normalisation. |
| `generate_spec.py` | Generator. Edit the operation tables here, not the YAML. |

## What changed and why (v2)

The first cut promoted each `function` to its own path (`/ETF_PROFILE`) and rewrote back
to `/query` in policy. Anshika flagged that imported operations came out as
`/ETF_PROFILE?symbol=QQQ` rather than `/query?function=ETF_PROFILE&symbol=QQQ`. That is
two separate problems, and both are now fixed in the spec itself.

**1. `/query?function=` now lives in the path key, via `x-ms-paths`.**
Plain OpenAPI cannot express 116 operations on one path + method, which is why the first
version sidestepped it with a rewrite. The correct answer for APIM specifically is the
`x-ms-paths` extension: it permits path keys that differ only by query string, and it is
one of only two extensions APIM honours on import (the other is `x-servers`). Operations
are now declared as:

```yaml
paths: {}          # required by the 3.0.1 schema, intentionally empty
x-ms-paths:
  /query?function=ETF_PROFILE:
    get:
      operationId: getEtfProfile
      parameters:
        - $ref: '#/components/parameters/symbol'
        - $ref: '#/components/parameters/datatype'
```

Imported operations now carry `/query?function=ETF_PROFILE` in their URL template, which
is the shape Anshika asked for. **The path-rewrite policy is gone** — the gateway no
longer touches the URI at all, so there is one less thing between a request and the vendor
when debugging.

**2. The trailing `?symbol=QQQ` in the template is a separate, settable behaviour.**
By default APIM folds *required* query parameters into the operation URL template. That is
what put `symbol` there. Turn it off at import time, or `symbol` gets baked into the
template alongside `function` and stops being editable in the test console:

- Portal: uncheck **Include query parameters in operation templates** when creating the API.
- REST/ARM: set the API's `translateRequiredQueryParameters` property to `query`.

With that setting only `function` stays in the template; `symbol`, `interval`,
`outputsize` and the rest appear as proper query parameters in the developer portal.

> Worth a test import of two or three operations before running the full 116 —
> `x-ms-paths` support is documented, but its interaction with
> `translateRequiredQueryParameters` is not something I could verify against a live
> instance from here.

## Import

```bash
RG=your-rg
APIM=your-apim-instance

# 1. Vendor key as a secret named value (Key Vault reference preferred)
az apim nv create -g $RG --service-name $APIM \
  --named-value-id alphavantage-apikey \
  --display-name alphavantage-apikey \
  --secret true --value "<YOUR_ALPHA_VANTAGE_KEY>"

# 2. Import the spec
az apim api import -g $RG --service-name $APIM \
  --api-id alphavantage \
  --path alphavantage/v1 \
  --specification-format OpenApi \
  --specification-path ./alphavantage-openapi.yaml \
  --service-url https://www.alphavantage.co \
  --protocols https \
  --subscription-required true

# 3. Apply the policy at API scope
az apim api policy create -g $RG --service-name $APIM \
  --api-id alphavantage \
  --policy-format xml \
  --value "$(cat apim-policy.xml)"
```

Check `translateRequiredQueryParameters` after import — the CLI may not expose it as a
flag, in which case set it via the ARM API or the portal checkbox before importing.

Smoke test:

```bash
curl -s "https://$APIM.azure-api.net/alphavantage/v1/query?function=ETF_PROFILE&symbol=QQQ" \
     -H "Ocp-Apim-Subscription-Key: $SUB_KEY"
```

## Three things that will bite you if skipped

**1. The vendor returns HTTP 200 for failures.** Rate limiting, missing entitlement, and
bad parameters all come back as `200 OK` with an `Error Message`, `Note`, or `Information`
field in the body. Downstream retry logic and circuit breakers see a healthy response and
do the wrong thing — a throttled client will hammer the endpoint and burn the daily quota
in minutes. The outbound policy parses the body and re-maps onto 400 / 403 / 429. Verify
this works before you publish; it is the highest-value part of the policy.

**2. Quota is per-account, not per-consumer.** Every consumer draws on one upstream key.
The free tier is 25 calls/day; paid tiers are priced per requests-per-minute. Set
`rate-limit-by-key` and `quota-by-key` below your contracted tier so the gateway rejects
overage instead of the vendor doing it unpredictably across all your consumers. The
caching block matters here too — daily and monthly series are effectively static within a
session, and caching them is the difference between a 75/min plan working and not.

**3. Premium operations fail confusingly on a free key.** Roughly 20 operations
(`TIME_SERIES_INTRADAY`, `TIME_SERIES_DAILY_ADJUSTED`, all `INDEX_DATA`, `REALTIME_*`,
`FX_INTRADAY`, `CRYPTO_INTRADAY`, `VWAP`, `MACD`) require a paid upstream plan and are
flagged in the spec descriptions. Until a premium key is in place, put them in a separate
APIM product so entitlement is enforced at the gateway rather than surfacing as an opaque
vendor message halfway through someone's integration. See the section below for what
changes once the premium key lands.

## When the premium key arrives

A premium upstream key is planned for this product. Three things change, and one gets
more important rather than less.

**Plan limits move, so they are named values now.** The free tier is 25 calls/day; premium
plans are priced per requests-per-minute (75, 150, 300, 600, 1200). On premium the daily
quota stops being the binding constraint and the per-minute rate does. `rate-limit-by-key`
and `quota-by-key` read `{{alphavantage-rate-calls}}` and `{{alphavantage-quota-calls}}`,
so retuning is a named-value edit rather than a policy change. Keep both set below the
contracted plan — one key still serves every consumer, so without a per-subscription
counter a single badly written client exhausts the plan for everyone.

**Splitting products by premium-vs-free capability stops being necessary.** That split
existed to stop consumers hitting operations the free key cannot serve. Once the premium
key is live, the ~20 flagged operations simply work, and the `Premium` markers in the spec
become documentation rather than a gating rule. Cost is now the reason to keep products
separate, if you keep them at all: every call is billable, so a product boundary is still
a reasonable place to put differentiated rate limits.

**Cutting over without a flag day.** Add a second named value
`alphavantage-apikey-premium` and switch to the product-aware key block commented into the
inbound policy. Cutover then means moving a subscription between products, and rollback
means moving it back — no policy edit, no redeploy, and you can validate premium behaviour
with one subscription before moving everyone.

**Realtime gets *more* attention, not less.** `entitlement=realtime` and
`entitlement=delayed` become reachable the moment the premium key is in place. Capability
arriving is not the same as permission arriving: that data is regulated by the exchanges,
FINRA, and the SEC, and a personal-use or single-seat licence generally does not cover
onward internal distribution through a shared gateway. There is a commented-out gate in
the inbound policy that rejects `entitlement` requests outside a named product — turn it
on before the premium key goes live, and remove it deliberately once someone has confirmed
the licence scope in writing. It is much easier to open this up later than to explain
after the fact why an unlicensed feed was redistributed internally.

Also worth knowing: caching gets more valuable, not less, since calls are now billable.
The cache gate deliberately excludes intraday, realtime, and quote traffic — review those
exclusions against your actual traffic mix once premium volume is real.

## Compliance note

Realtime and 15-minute delayed US market data is regulated by the exchanges, FINRA, and
the SEC, and Alpha Vantage's terms distinguish personal from commercial use. Onboarding
to a shared internal gateway is a redistribution question, not just a technical one — get
the licence scope confirmed before opening `entitlement=realtime` operations to a wide
internal audience, and consider gating those operations behind a named product with an
approval workflow.

## Regenerating

`generate_spec.py` holds the operation tables. To add or change an endpoint, edit the
relevant table and re-run — the response wiring, error responses, security scheme, and
shared parameters are applied uniformly, so hand-edits to the YAML will be lost. Validate
after any change:

```bash
python3 -m openapi_spec_validator alphavantage-openapi.yaml
```

Note that standard validators only check `paths` — they will not catch a malformed entry
under `x-ms-paths`, since extensions are unvalidated by design. A structural typo there
surfaces at import time, not at validation time.

## Known gaps

The vendor documentation page is long and a few newer endpoints are stubbed with base
parameters only, pending a pass against the live docs:

- `REALTIME_OPTIONS` / `HISTORICAL_OPTIONS` — `date`, `require_greeks`, `contract` not modelled
- `NEWS_SENTIMENT` — `tickers`, `topics`, `time_from`, `time_to`, `sort`, `limit` not modelled
- `EARNINGS_CALL_TRANSCRIPT` — `quarter` not modelled
- `LISTING_STATUS` / `EARNINGS_CALENDAR` — `date`, `state`, `horizon` not modelled
- Analytics (fixed/sliding window), congress trades, institutional holdings, politician
  metadata, company logo, and gold/silver spot are not yet included

Unmodelled query parameters are not blocked, so these operations still work; they are
just under-documented in the developer portal.
